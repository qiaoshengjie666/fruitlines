
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Game/Scripts/ui/PauseDialog.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '83fb9osUoVEppfk8B6mkJYV', 'PauseDialog');
// Game/Scripts/ui/PauseDialog.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Platform_1 = require("../../../framework/Platform");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var PauseDialog = /** @class */ (function (_super) {
    __extends(PauseDialog, _super);
    function PauseDialog() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    PauseDialog.prototype.onLoad = function () { };
    PauseDialog.prototype.start = function () {
        appGame.banner.playBanner(1);
    };
    PauseDialog.prototype.click_share = function () {
        Platform_1.default.share();
    };
    PauseDialog.prototype.click_home = function () {
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, { title: '游戏界面', content: '点击返回主界面' }, function () { });
        cc.director.loadScene("Main");
    };
    PauseDialog.prototype.click_restart = function () {
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, { title: '返回界面', content: '重新开始' }, function () { });
        if (appGame.gameServerRoom.gameConfigData && appGame.gameServerRoom.gameConfigData.PauseDialogRestart) {
            appGame.videoBanner.playVideoAd(4, 0, function () {
                cc.director.loadScene("Game");
            });
        }
        else {
            cc.director.loadScene("Game");
        }
    };
    PauseDialog = __decorate([
        ccclass
    ], PauseDialog);
    return PauseDialog;
}(cc.Component));
exports.default = PauseDialog;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcR2FtZVxcU2NyaXB0c1xcdWlcXFBhdXNlRGlhbG9nLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSx3REFBbUQ7QUFHN0MsSUFBQSxLQUFzQixFQUFFLENBQUMsVUFBVSxFQUFsQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWlCLENBQUM7QUFHMUM7SUFBeUMsK0JBQVk7SUFBckQ7O0lBa0NBLENBQUM7SUFoQ0csNEJBQU0sR0FBTixjQUFXLENBQUM7SUFDWiwyQkFBSyxHQUFMO1FBRUksT0FBTyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDakMsQ0FBQztJQUdELGlDQUFXLEdBQVg7UUFFSSxrQkFBUSxDQUFDLEtBQUssRUFBRSxDQUFDO0lBRXJCLENBQUM7SUFFRCxnQ0FBVSxHQUFWO1FBRUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLEVBQUMsRUFBQyxLQUFLLEVBQUMsTUFBTSxFQUFDLE9BQU8sRUFBQyxTQUFTLEVBQUMsRUFBQyxjQUFXLENBQUMsQ0FBQyxDQUFDO1FBQzVGLEVBQUUsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQ2pDLENBQUM7SUFHRCxtQ0FBYSxHQUFiO1FBRUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsa0JBQWtCLEVBQUMsRUFBQyxLQUFLLEVBQUMsTUFBTSxFQUFDLE9BQU8sRUFBQyxNQUFNLEVBQUMsRUFBQyxjQUFXLENBQUMsQ0FBQyxDQUFDO1FBQ3pGLElBQUcsT0FBTyxDQUFDLGNBQWMsQ0FBQyxjQUFjLElBQUcsT0FBTyxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsa0JBQWtCLEVBQUM7WUFDaEcsT0FBTyxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztnQkFDaEMsRUFBRSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUE7WUFDakMsQ0FBQyxDQUFDLENBQUE7U0FDTDthQUFJO1lBQ0QsRUFBRSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLENBQUE7U0FDaEM7SUFFTCxDQUFDO0lBakNnQixXQUFXO1FBRC9CLE9BQU87T0FDYSxXQUFXLENBa0MvQjtJQUFELGtCQUFDO0NBbENELEFBa0NDLENBbEN3QyxFQUFFLENBQUMsU0FBUyxHQWtDcEQ7a0JBbENvQixXQUFXIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFBsYXRmb3JtIGZyb20gXCIuLi8uLi8uLi9mcmFtZXdvcmsvUGxhdGZvcm1cIjtcblxuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFBhdXNlRGlhbG9nIGV4dGVuZHMgY2MuQ29tcG9uZW50IHtcblxuICAgIG9uTG9hZCAoKSB7fVxuICAgIHN0YXJ0ICgpIHtcblxuICAgICAgICBhcHBHYW1lLmJhbm5lci5wbGF5QmFubmVyKDEpO1xuICAgIH1cblxuXG4gICAgY2xpY2tfc2hhcmUoKVxuICAgIHtcbiAgICAgICAgUGxhdGZvcm0uc2hhcmUoKTtcbiAgICAgICAgXG4gICAgfVxuXG4gICAgY2xpY2tfaG9tZSgpXG4gICAge1xuICAgICAgICBodHRwVXRpbHMuaHR0cFBvc3QoY29uc3RzLkhUVFBfUkVDT1JEX1NFUlZFUix7dGl0bGU6J+a4uOaIj+eVjOmdoicsY29udGVudDon54K55Ye76L+U5Zue5Li755WM6Z2iJ30sZnVuY3Rpb24oKXt9KTtcbiAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiTWFpblwiKVxuICAgIH1cblxuXG4gICAgY2xpY2tfcmVzdGFydCgpXG4gICAge1xuICAgICAgICBodHRwVXRpbHMuaHR0cFBvc3QoY29uc3RzLkhUVFBfUkVDT1JEX1NFUlZFUix7dGl0bGU6J+i/lOWbnueVjOmdoicsY29udGVudDon6YeN5paw5byA5aeLJ30sZnVuY3Rpb24oKXt9KTtcbiAgICAgICAgaWYoYXBwR2FtZS5nYW1lU2VydmVyUm9vbS5nYW1lQ29uZmlnRGF0YSAmJmFwcEdhbWUuZ2FtZVNlcnZlclJvb20uZ2FtZUNvbmZpZ0RhdGEuUGF1c2VEaWFsb2dSZXN0YXJ0KXtcbiAgICAgICAgICAgIGFwcEdhbWUudmlkZW9CYW5uZXIucGxheVZpZGVvQWQoNCwwLGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiR2FtZVwiKVxuICAgICAgICAgICAgfSlcbiAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJHYW1lXCIpXG4gICAgICAgIH1cbiAgICAgICBcbiAgICB9XG59Il19
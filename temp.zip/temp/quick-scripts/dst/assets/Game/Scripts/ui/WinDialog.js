
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Game/Scripts/ui/WinDialog.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7d78f0lU+VOW7rncsSfgC5s', 'WinDialog');
// Game/Scripts/ui/WinDialog.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Info_1 = require("../Info");
var Platform_1 = require("../../../framework/Platform");
var ViewManager_1 = require("../../../framework/plugin_boosts/ui/ViewManager");
var Consts_1 = require("../hex-lines-game/Consts");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var WinDialog = /** @class */ (function (_super) {
    __extends(WinDialog, _super);
    function WinDialog() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ps = null;
        _this.levelLabel = null;
        return _this;
    }
    WinDialog.prototype.onLoad = function () { };
    WinDialog.prototype.start = function () { };
    WinDialog.prototype.decreaseFomula = function (max, min, t, d) {
        return max - (t / (t + d) * (max - min));
    };
    ;
    WinDialog.prototype.onShown = function () {
        this.ps.resetSystem();
        Platform_1.default.showSmallRank();
        this.levelLabel.string = cc.js.formatStr("关卡 " + Info_1.UserInfo.currentLevel);
        var p = this.decreaseFomula(0.99, 0.3, Info_1.UserInfo.timePassed + Info_1.UserInfo.stepUsed, Info_1.UserInfo.currentLevel + 50);
        if (Info_1.UserInfo.level == Info_1.UserInfo.currentLevel) {
            var lv = Info_1.UserInfo.level;
            var choise_1 = Info_1.UserInfo.getChoice(Info_1.ChoiceType.Levelup);
            // if(choise > 0 && Math.random() > 0.5 && lv >= 3)
            // {
            //     this.scheduleOnce(_=>{
            //         ViewManager.instance.show("Game/LevelupDialog",lv,p)
            //     },1)
            // }else{
            //     p = Math.min(p,1);
            //     let diamond = Math.floor(Math.max(30 * p,10))
            //     UserInfo.addDiamond(diamond);
            // }
            Info_1.UserInfo.level = lv + 1;
            Platform_1.default.uploadScore(Info_1.UserInfo.level);
            Info_1.UserInfo.save();
        }
        var choise = Info_1.UserInfo.getChoice(Info_1.ChoiceType.HB);
        if (choise == 1) {
            if (Info_1.UserInfo.level >= 3) {
                if (!Info_1.UserInfo.isUnlock(Consts_1.default.FreeSkinId)) {
                    ViewManager_1.default.instance.show("Game/HbDialog");
                }
            }
        }
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, { title: '结算界面', content: '第' + Info_1.UserInfo.level + "关" }, function () { });
        appGame.banner.playBanner(1);
    };
    WinDialog.prototype.click_rank = function () {
        ViewManager_1.default.instance.show("wechat/WxRankDialog");
    };
    //修改成开始当前游戏
    WinDialog.prototype.click_shop = function () {
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, { title: '结算界面', content: '点击重玩' }, function () { });
        if (appGame.gameServerRoom.gameConfigData && appGame.gameServerRoom.gameConfigData.winAgain) {
            appGame.videoBanner.playVideoAd(3, 0, function () {
                //  UserInfo.currentLevel = UserInfo.currentLevel ;
                cc.director.loadScene("Game");
            });
        }
        else {
            // UserInfo.currentLevel = UserInfo.currentLevel ;
            cc.director.loadScene("Game");
        }
        //ViewManager.instance.show("Game/ShopDialog");
    };
    WinDialog.prototype.click_next = function () {
        var btn3 = this.node.getChildByName("btn3").getComponent(cc.Button);
        btn3.enabled = false;
        this.scheduleOnce(function () {
            btn3.enabled = true;
        }.bind(this), 2);
        Info_1.UserInfo.currentLevel = Info_1.UserInfo.currentLevel + 1;
        cc.director.loadScene("Game");
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, { title: '结算界面', content: '点击下一关' }, function () { });
        if (appGame.gameServerRoom.gameConfigData && appGame.gameServerRoom.gameConfigData.winNextLevel) {
            appGame.videoBanner.playVideoAd(2, 0, function () {
                cc.log("win1");
                btn3.enabled = true;
            }.bind(this));
        }
    };
    WinDialog.prototype.click_home = function () {
        cc.director.loadScene("Main");
    };
    WinDialog.prototype.click_share = function () {
        Platform_1.default.share();
    };
    __decorate([
        property(cc.ParticleSystem)
    ], WinDialog.prototype, "ps", void 0);
    __decorate([
        property(cc.Label)
    ], WinDialog.prototype, "levelLabel", void 0);
    WinDialog = __decorate([
        ccclass
    ], WinDialog);
    return WinDialog;
}(cc.Component));
exports.default = WinDialog;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcR2FtZVxcU2NyaXB0c1xcdWlcXFdpbkRpYWxvZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsZ0NBQStDO0FBQy9DLHdEQUFtRDtBQUNuRCwrRUFBMEU7QUFDMUUsbURBQThDO0FBR3hDLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBRzFDO0lBQXVDLDZCQUFZO0lBQW5EO1FBQUEscUVBaUhDO1FBN0dHLFFBQUUsR0FBcUIsSUFBSSxDQUFDO1FBRzVCLGdCQUFVLEdBQVksSUFBSSxDQUFDOztJQTBHL0IsQ0FBQztJQXRHRywwQkFBTSxHQUFOLGNBQVcsQ0FBQztJQUNaLHlCQUFLLEdBQUwsY0FBVSxDQUFDO0lBQ1gsa0NBQWMsR0FBZCxVQUFnQixHQUFHLEVBQUMsR0FBRyxFQUFDLENBQUMsRUFBQyxDQUFDO1FBRXZCLE9BQU8sR0FBRyxHQUFHLENBQUMsQ0FBQyxHQUFFLENBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxHQUFHLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxDQUFFLENBQUE7SUFDN0MsQ0FBQztJQUFBLENBQUM7SUFDRiwyQkFBTyxHQUFQO1FBRUksSUFBSSxDQUFDLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUN0QixrQkFBUSxDQUFDLGFBQWEsRUFBRSxDQUFDO1FBRXpCLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBQyxlQUFRLENBQUMsWUFBWSxDQUFDLENBQUE7UUFFckUsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUMsR0FBRyxFQUFDLGVBQVEsQ0FBQyxVQUFVLEdBQUcsZUFBUSxDQUFDLFFBQVEsRUFBQyxlQUFRLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBRSxDQUFBO1FBR3pHLElBQUcsZUFBUSxDQUFDLEtBQUssSUFBSSxlQUFRLENBQUMsWUFBWSxFQUMxQztZQUNJLElBQUksRUFBRSxHQUFHLGVBQVEsQ0FBQyxLQUFLLENBQUE7WUFDdkIsSUFBSSxRQUFNLEdBQUcsZUFBUSxDQUFDLFNBQVMsQ0FBQyxpQkFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ3BELG1EQUFtRDtZQUNuRCxJQUFJO1lBQ0osNkJBQTZCO1lBQzdCLCtEQUErRDtZQUMvRCxXQUFXO1lBRVgsU0FBUztZQUVULHlCQUF5QjtZQUN6QixvREFBb0Q7WUFFcEQsb0NBQW9DO1lBQ3BDLElBQUk7WUFDSixlQUFRLENBQUMsS0FBSyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUE7WUFDdkIsa0JBQVEsQ0FBQyxXQUFXLENBQUMsZUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFDO1lBQ3JDLGVBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztTQUVuQjtRQUNELElBQUksTUFBTSxHQUFHLGVBQVEsQ0FBQyxTQUFTLENBQUMsaUJBQVUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUMvQyxJQUFHLE1BQU0sSUFBSSxDQUFDLEVBQ2Q7WUFDSSxJQUFHLGVBQVEsQ0FBQyxLQUFLLElBQUksQ0FBQyxFQUN0QjtnQkFDSSxJQUFHLENBQUMsZUFBUSxDQUFDLFFBQVEsQ0FBQyxnQkFBTSxDQUFDLFVBQVUsQ0FBQyxFQUN4QztvQkFDSSxxQkFBVyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUE7aUJBQzdDO2FBQ0o7U0FDSjtRQUNELFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGtCQUFrQixFQUFDLEVBQUMsS0FBSyxFQUFDLE1BQU0sRUFBQyxPQUFPLEVBQUMsR0FBRyxHQUFDLGVBQVEsQ0FBQyxLQUFLLEdBQUMsR0FBRyxFQUFDLEVBQUMsY0FBVyxDQUFDLENBQUMsQ0FBQztRQUN6RyxPQUFPLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBRUQsOEJBQVUsR0FBVjtRQUVJLHFCQUFXLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxDQUFBO0lBQ3BELENBQUM7SUFDRCxXQUFXO0lBQ1gsOEJBQVUsR0FBVjtRQUVJLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGtCQUFrQixFQUFDLEVBQUMsS0FBSyxFQUFDLE1BQU0sRUFBQyxPQUFPLEVBQUMsTUFBTSxFQUFDLEVBQUMsY0FBVyxDQUFDLENBQUMsQ0FBQztRQUN6RixJQUFHLE9BQU8sQ0FBQyxjQUFjLENBQUMsY0FBYyxJQUFHLE9BQU8sQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLFFBQVEsRUFBQztZQUN0RixPQUFPLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxFQUFDO2dCQUNsQyxtREFBbUQ7Z0JBQ2pELEVBQUUsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFBO1lBQ2pDLENBQUMsQ0FBQyxDQUFBO1NBQ0w7YUFBSTtZQUNGLGtEQUFrRDtZQUNqRCxFQUFFLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQTtTQUNoQztRQUVELCtDQUErQztJQUNuRCxDQUFDO0lBRUQsOEJBQVUsR0FBVjtRQUVJLElBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDcEUsSUFBSSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7UUFDckIsSUFBSSxDQUFDLFlBQVksQ0FBQztZQUNkLElBQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDO1FBQ3hCLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUM7UUFDaEIsZUFBUSxDQUFDLFlBQVksR0FBRyxlQUFRLENBQUMsWUFBWSxHQUFFLENBQUMsQ0FBQztRQUNqRCxFQUFFLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUM3QixTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsRUFBQyxFQUFDLEtBQUssRUFBQyxNQUFNLEVBQUMsT0FBTyxFQUFDLE9BQU8sRUFBQyxFQUFDLGNBQVcsQ0FBQyxDQUFDLENBQUM7UUFDMUYsSUFBRyxPQUFPLENBQUMsY0FBYyxDQUFDLGNBQWMsSUFBRyxPQUFPLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxZQUFZLEVBQUM7WUFDMUYsT0FBTyxDQUFDLFdBQVcsQ0FBQyxXQUFXLENBQUMsQ0FBQyxFQUFDLENBQUMsRUFBQztnQkFDaEMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztnQkFDZixJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztZQUN4QixDQUFDLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUE7U0FDaEI7SUFFTCxDQUFDO0lBRUQsOEJBQVUsR0FBVjtRQUVJLEVBQUUsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQ2pDLENBQUM7SUFFRCwrQkFBVyxHQUFYO1FBRUksa0JBQVEsQ0FBQyxLQUFLLEVBQUUsQ0FBQztJQUNyQixDQUFDO0lBNUdEO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxjQUFjLENBQUM7eUNBQ0E7SUFHNUI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQztpREFDUTtJQVBWLFNBQVM7UUFEN0IsT0FBTztPQUNhLFNBQVMsQ0FpSDdCO0lBQUQsZ0JBQUM7Q0FqSEQsQUFpSEMsQ0FqSHNDLEVBQUUsQ0FBQyxTQUFTLEdBaUhsRDtrQkFqSG9CLFNBQVMiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBVc2VySW5mbywgQ2hvaWNlVHlwZSB9IGZyb20gXCIuLi9JbmZvXCI7XG5pbXBvcnQgUGxhdGZvcm0gZnJvbSBcIi4uLy4uLy4uL2ZyYW1ld29yay9QbGF0Zm9ybVwiO1xuaW1wb3J0IFZpZXdNYW5hZ2VyIGZyb20gXCIuLi8uLi8uLi9mcmFtZXdvcmsvcGx1Z2luX2Jvb3N0cy91aS9WaWV3TWFuYWdlclwiO1xuaW1wb3J0IENvbnN0cyBmcm9tIFwiLi4vaGV4LWxpbmVzLWdhbWUvQ29uc3RzXCI7XG5cblxuY29uc3Qge2NjY2xhc3MsIHByb3BlcnR5fSA9IGNjLl9kZWNvcmF0b3I7XG5cbkBjY2NsYXNzXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBXaW5EaWFsb2cgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuXG5cbiAgICBAcHJvcGVydHkoY2MuUGFydGljbGVTeXN0ZW0pXG4gICAgcHM6Y2MuUGFydGljbGVTeXN0ZW0gPSBudWxsO1xuXG4gICAgQHByb3BlcnR5KGNjLkxhYmVsKVxuICAgIGxldmVsTGFiZWw6Y2MuTGFiZWwgPSBudWxsO1xuXG5cblxuICAgIG9uTG9hZCAoKSB7fVxuICAgIHN0YXJ0ICgpIHt9XG4gICAgZGVjcmVhc2VGb211bGEgKG1heCxtaW4sdCxkKVxuICAgIHtcbiAgICAgICAgcmV0dXJuIG1heCAtICh0LyAoIHQgKyBkKSAqIChtYXggLSBtaW4pIClcbiAgICB9O1xuICAgIG9uU2hvd24oKVxuICAgIHtcbiAgICAgICAgdGhpcy5wcy5yZXNldFN5c3RlbSgpO1xuICAgICAgICBQbGF0Zm9ybS5zaG93U21hbGxSYW5rKCk7XG5cbiAgICAgICAgdGhpcy5sZXZlbExhYmVsLnN0cmluZyA9IGNjLmpzLmZvcm1hdFN0cihcIuWFs+WNoSBcIitVc2VySW5mby5jdXJyZW50TGV2ZWwpXG5cbiAgICAgICAgbGV0IHAgPSB0aGlzLmRlY3JlYXNlRm9tdWxhKDAuOTksMC4zLFVzZXJJbmZvLnRpbWVQYXNzZWQgKyBVc2VySW5mby5zdGVwVXNlZCxVc2VySW5mby5jdXJyZW50TGV2ZWwgKyA1MCApXG5cbiAgICAgICAgXG4gICAgICAgIGlmKFVzZXJJbmZvLmxldmVsID09IFVzZXJJbmZvLmN1cnJlbnRMZXZlbClcbiAgICAgICAge1xuICAgICAgICAgICAgbGV0IGx2ID0gVXNlckluZm8ubGV2ZWxcbiAgICAgICAgICAgIGxldCBjaG9pc2UgPSBVc2VySW5mby5nZXRDaG9pY2UoQ2hvaWNlVHlwZS5MZXZlbHVwKTtcbiAgICAgICAgICAgIC8vIGlmKGNob2lzZSA+IDAgJiYgTWF0aC5yYW5kb20oKSA+IDAuNSAmJiBsdiA+PSAzKVxuICAgICAgICAgICAgLy8ge1xuICAgICAgICAgICAgLy8gICAgIHRoaXMuc2NoZWR1bGVPbmNlKF89PntcbiAgICAgICAgICAgIC8vICAgICAgICAgVmlld01hbmFnZXIuaW5zdGFuY2Uuc2hvdyhcIkdhbWUvTGV2ZWx1cERpYWxvZ1wiLGx2LHApXG4gICAgICAgICAgICAvLyAgICAgfSwxKVxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgLy8gfWVsc2V7XG4gICAgICAgICAgICAgICBcbiAgICAgICAgICAgIC8vICAgICBwID0gTWF0aC5taW4ocCwxKTtcbiAgICAgICAgICAgIC8vICAgICBsZXQgZGlhbW9uZCA9IE1hdGguZmxvb3IoTWF0aC5tYXgoMzAgKiBwLDEwKSlcbiAgICAgICAgICBcbiAgICAgICAgICAgIC8vICAgICBVc2VySW5mby5hZGREaWFtb25kKGRpYW1vbmQpO1xuICAgICAgICAgICAgLy8gfVxuICAgICAgICAgICAgVXNlckluZm8ubGV2ZWwgPSBsdiArIDFcbiAgICAgICAgICAgIFBsYXRmb3JtLnVwbG9hZFNjb3JlKFVzZXJJbmZvLmxldmVsKTtcbiAgICAgICAgICAgIFVzZXJJbmZvLnNhdmUoKTtcbiBcbiAgICAgICAgfVxuICAgICAgICBsZXQgY2hvaXNlID0gVXNlckluZm8uZ2V0Q2hvaWNlKENob2ljZVR5cGUuSEIpO1xuICAgICAgICBpZihjaG9pc2UgPT0gMSlcbiAgICAgICAge1xuICAgICAgICAgICAgaWYoVXNlckluZm8ubGV2ZWwgPj0gMylcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBpZighVXNlckluZm8uaXNVbmxvY2soQ29uc3RzLkZyZWVTa2luSWQpKVxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgVmlld01hbmFnZXIuaW5zdGFuY2Uuc2hvdyhcIkdhbWUvSGJEaWFsb2dcIilcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaHR0cFV0aWxzLmh0dHBQb3N0KGNvbnN0cy5IVFRQX1JFQ09SRF9TRVJWRVIse3RpdGxlOifnu5PnrpfnlYzpnaInLGNvbnRlbnQ6J+esrCcrVXNlckluZm8ubGV2ZWwrXCLlhbNcIn0sZnVuY3Rpb24oKXt9KTtcbiAgICAgICAgYXBwR2FtZS5iYW5uZXIucGxheUJhbm5lcigxKTtcbiAgICB9XG5cbiAgICBjbGlja19yYW5rKClcbiAgICB7XG4gICAgICAgIFZpZXdNYW5hZ2VyLmluc3RhbmNlLnNob3coXCJ3ZWNoYXQvV3hSYW5rRGlhbG9nXCIpXG4gICAgfVxuICAgIC8v5L+u5pS55oiQ5byA5aeL5b2T5YmN5ri45oiPXG4gICAgY2xpY2tfc2hvcCgpXG4gICAge1xuICAgICAgICBodHRwVXRpbHMuaHR0cFBvc3QoY29uc3RzLkhUVFBfUkVDT1JEX1NFUlZFUix7dGl0bGU6J+e7k+eul+eVjOmdoicsY29udGVudDon54K55Ye76YeN546pJ30sZnVuY3Rpb24oKXt9KTtcbiAgICAgICAgaWYoYXBwR2FtZS5nYW1lU2VydmVyUm9vbS5nYW1lQ29uZmlnRGF0YSAmJmFwcEdhbWUuZ2FtZVNlcnZlclJvb20uZ2FtZUNvbmZpZ0RhdGEud2luQWdhaW4pe1xuICAgICAgICAgICAgYXBwR2FtZS52aWRlb0Jhbm5lci5wbGF5VmlkZW9BZCgzLDAsZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgLy8gIFVzZXJJbmZvLmN1cnJlbnRMZXZlbCA9IFVzZXJJbmZvLmN1cnJlbnRMZXZlbCA7XG4gICAgICAgICAgICAgICAgY2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiR2FtZVwiKVxuICAgICAgICAgICAgfSlcbiAgICAgICAgfWVsc2V7XG4gICAgICAgICAgIC8vIFVzZXJJbmZvLmN1cnJlbnRMZXZlbCA9IFVzZXJJbmZvLmN1cnJlbnRMZXZlbCA7XG4gICAgICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJHYW1lXCIpXG4gICAgICAgIH1cblxuICAgICAgICAvL1ZpZXdNYW5hZ2VyLmluc3RhbmNlLnNob3coXCJHYW1lL1Nob3BEaWFsb2dcIik7XG4gICAgfVxuXG4gICAgY2xpY2tfbmV4dCgpXG4gICAge1xuICAgICAgICB2YXIgYnRuMyA9IHRoaXMubm9kZS5nZXRDaGlsZEJ5TmFtZShcImJ0bjNcIikuZ2V0Q29tcG9uZW50KGNjLkJ1dHRvbik7XG4gICAgICAgIGJ0bjMuZW5hYmxlZCA9IGZhbHNlO1xuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZShmdW5jdGlvbigpe1xuICAgICAgICAgICAgYnRuMy5lbmFibGVkID0gdHJ1ZTtcbiAgICAgICAgfS5iaW5kKHRoaXMpLDIpO1xuICAgICAgICBVc2VySW5mby5jdXJyZW50TGV2ZWwgPSBVc2VySW5mby5jdXJyZW50TGV2ZWwgKzE7XG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcIkdhbWVcIilcbiAgICAgICAgaHR0cFV0aWxzLmh0dHBQb3N0KGNvbnN0cy5IVFRQX1JFQ09SRF9TRVJWRVIse3RpdGxlOifnu5PnrpfnlYzpnaInLGNvbnRlbnQ6J+eCueWHu+S4i+S4gOWFsyd9LGZ1bmN0aW9uKCl7fSk7XG4gICAgICAgIGlmKGFwcEdhbWUuZ2FtZVNlcnZlclJvb20uZ2FtZUNvbmZpZ0RhdGEgJiZhcHBHYW1lLmdhbWVTZXJ2ZXJSb29tLmdhbWVDb25maWdEYXRhLndpbk5leHRMZXZlbCl7XG4gICAgICAgICAgICBhcHBHYW1lLnZpZGVvQmFubmVyLnBsYXlWaWRlb0FkKDIsMCxmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgIGNjLmxvZyhcIndpbjFcIik7XG4gICAgICAgICAgICAgICAgYnRuMy5lbmFibGVkID0gdHJ1ZTtcbiAgICAgICAgICAgIH0uYmluZCh0aGlzKSlcbiAgICAgICAgfVxuICAgICAgXG4gICAgfVxuXG4gICAgY2xpY2tfaG9tZSgpXG4gICAge1xuICAgICAgICBjYy5kaXJlY3Rvci5sb2FkU2NlbmUoXCJNYWluXCIpXG4gICAgfVxuXG4gICAgY2xpY2tfc2hhcmUoKVxuICAgIHtcbiAgICAgICAgUGxhdGZvcm0uc2hhcmUoKTtcbiAgICB9XG59Il19
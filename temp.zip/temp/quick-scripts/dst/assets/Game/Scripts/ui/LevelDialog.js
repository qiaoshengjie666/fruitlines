
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Game/Scripts/ui/LevelDialog.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4c94fc8PDtI1o3JM9m3WRKN', 'LevelDialog');
// Game/Scripts/ui/LevelDialog.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Info_1 = require("../Info");
var LevelSelector_1 = require("../../../framework/plugin_boosts/ui/game/LevelSelector");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var LevelDialog = /** @class */ (function (_super) {
    __extends(LevelDialog, _super);
    function LevelDialog() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LevelDialog.prototype.onLoad = function () { };
    LevelDialog.prototype.start = function () { };
    LevelDialog.prototype.onShown = function () {
        this.selector.currentLevel = Info_1.UserInfo.level;
        this.selector.refresh();
        this.scheduleOnce(this.refreshLevels, 0.1);
        appGame.banner.playBanner(1);
    };
    LevelDialog.prototype.refreshLevels = function () {
        this.selector.scrollToCurrentLevel();
    };
    LevelDialog.prototype.select_level = function (lvnode) {
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, { title: '选择关卡界面', content: '点击关卡' + lvnode.name }, function () { });
        this.gotoLevel(lvnode.name);
    };
    LevelDialog.prototype.refreshLevelItem = function (data) {
    };
    LevelDialog.prototype.gotoLevel = function (lv) {
        lv = parseInt(lv);
        console.log("enter level", lv);
        Info_1.UserInfo.currentLevel = lv;
        cc.director.loadScene("Game");
    };
    LevelDialog.prototype.click_continue = function () {
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, { title: '选择关卡界面', content: '点击继续游戏' }, function () { });
        if (appGame.gameServerRoom.gameConfigData && appGame.gameServerRoom.gameConfigData.LevelDialogContinue) {
            appGame.videoBanner.playVideoAd(1, 0, function () {
                this.gotoLevel(Info_1.UserInfo.level);
            }.bind(this));
        }
        else {
            this.gotoLevel(Info_1.UserInfo.level);
        }
    };
    __decorate([
        property(LevelSelector_1.default)
    ], LevelDialog.prototype, "selector", void 0);
    LevelDialog = __decorate([
        ccclass
    ], LevelDialog);
    return LevelDialog;
}(cc.Component));
exports.default = LevelDialog;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcR2FtZVxcU2NyaXB0c1xcdWlcXExldmVsRGlhbG9nLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxnQ0FBbUM7QUFDbkMsd0ZBQW1GO0FBRzdFLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBRzFDO0lBQXlDLCtCQUFZO0lBQXJEOztJQW9EQSxDQUFDO0lBbERHLDRCQUFNLEdBQU4sY0FBVyxDQUFDO0lBQ1osMkJBQUssR0FBTCxjQUFVLENBQUM7SUFJWCw2QkFBTyxHQUFQO1FBRUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxZQUFZLEdBQUcsZUFBUSxDQUFDLEtBQUssQ0FBQztRQUM1QyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sRUFBRSxDQUFBO1FBRXZCLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLGFBQWEsRUFBRSxHQUFHLENBQUMsQ0FBQTtRQUMxQyxPQUFPLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBRUQsbUNBQWEsR0FBYjtRQUVJLElBQUksQ0FBQyxRQUFRLENBQUMsb0JBQW9CLEVBQUUsQ0FBQztJQUN6QyxDQUFDO0lBRUQsa0NBQVksR0FBWixVQUFhLE1BQU07UUFFZixTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsRUFBQyxFQUFDLEtBQUssRUFBQyxRQUFRLEVBQUMsT0FBTyxFQUFDLE1BQU0sR0FBQyxNQUFNLENBQUMsSUFBSSxFQUFDLEVBQUMsY0FBVyxDQUFDLENBQUMsQ0FBQztRQUN2RyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQTtJQUMvQixDQUFDO0lBRUQsc0NBQWdCLEdBQWhCLFVBQWlCLElBQUk7SUFFckIsQ0FBQztJQUVELCtCQUFTLEdBQVQsVUFBVSxFQUFFO1FBRVIsRUFBRSxHQUFJLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUNsQixPQUFPLENBQUMsR0FBRyxDQUFDLGFBQWEsRUFBSSxFQUFFLENBQUMsQ0FBQztRQUNqQyxlQUFRLENBQUMsWUFBWSxHQUFHLEVBQUUsQ0FBQztRQUMzQixFQUFFLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUNqQyxDQUFDO0lBRUQsb0NBQWMsR0FBZDtRQUdJLFNBQVMsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLGtCQUFrQixFQUFDLEVBQUMsS0FBSyxFQUFDLFFBQVEsRUFBQyxPQUFPLEVBQUMsUUFBUSxFQUFDLEVBQUMsY0FBVyxDQUFDLENBQUMsQ0FBQztRQUM3RixJQUFHLE9BQU8sQ0FBQyxjQUFjLENBQUMsY0FBYyxJQUFHLE9BQU8sQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLG1CQUFtQixFQUFDO1lBQ2pHLE9BQU8sQ0FBQyxXQUFXLENBQUMsV0FBVyxDQUFDLENBQUMsRUFBQyxDQUFDLEVBQUM7Z0JBQ2hDLElBQUksQ0FBQyxTQUFTLENBQUMsZUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFBO1lBQ2xDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQTtTQUNoQjthQUFJO1lBQ0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFRLENBQUMsS0FBSyxDQUFDLENBQUE7U0FDakM7SUFFTCxDQUFDO0lBOUNEO1FBREMsUUFBUSxDQUFDLHVCQUFhLENBQUM7aURBQ0Q7SUFMTixXQUFXO1FBRC9CLE9BQU87T0FDYSxXQUFXLENBb0QvQjtJQUFELGtCQUFDO0NBcERELEFBb0RDLENBcER3QyxFQUFFLENBQUMsU0FBUyxHQW9EcEQ7a0JBcERvQixXQUFXIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgVXNlckluZm8gfSBmcm9tIFwiLi4vSW5mb1wiO1xuaW1wb3J0IExldmVsU2VsZWN0b3IgZnJvbSBcIi4uLy4uLy4uL2ZyYW1ld29yay9wbHVnaW5fYm9vc3RzL3VpL2dhbWUvTGV2ZWxTZWxlY3RvclwiO1xuXG5cbmNvbnN0IHtjY2NsYXNzLCBwcm9wZXJ0eX0gPSBjYy5fZGVjb3JhdG9yO1xuXG5AY2NjbGFzc1xuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTGV2ZWxEaWFsb2cgZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuXG4gICAgb25Mb2FkICgpIHt9XG4gICAgc3RhcnQgKCkge31cbiAgICBAcHJvcGVydHkoTGV2ZWxTZWxlY3RvcilcbiAgICBzZWxlY3RvcjpMZXZlbFNlbGVjdG9yO1xuXG4gICAgb25TaG93bigpXG4gICAge1xuICAgICAgICB0aGlzLnNlbGVjdG9yLmN1cnJlbnRMZXZlbCA9IFVzZXJJbmZvLmxldmVsO1xuICAgICAgICB0aGlzLnNlbGVjdG9yLnJlZnJlc2goKVxuXG4gICAgICAgIHRoaXMuc2NoZWR1bGVPbmNlKHRoaXMucmVmcmVzaExldmVscywgMC4xKVxuICAgICAgICBhcHBHYW1lLmJhbm5lci5wbGF5QmFubmVyKDEpO1xuICAgIH1cblxuICAgIHJlZnJlc2hMZXZlbHMoKVxuICAgIHtcbiAgICAgICAgdGhpcy5zZWxlY3Rvci5zY3JvbGxUb0N1cnJlbnRMZXZlbCgpO1xuICAgIH1cblxuICAgIHNlbGVjdF9sZXZlbChsdm5vZGUpXG4gICAge1xuICAgICAgICBodHRwVXRpbHMuaHR0cFBvc3QoY29uc3RzLkhUVFBfUkVDT1JEX1NFUlZFUix7dGl0bGU6J+mAieaLqeWFs+WNoeeVjOmdoicsY29udGVudDon54K55Ye75YWz5Y2hJytsdm5vZGUubmFtZX0sZnVuY3Rpb24oKXt9KTtcbiAgICAgICAgdGhpcy5nb3RvTGV2ZWwobHZub2RlLm5hbWUpXG4gICAgfVxuXG4gICAgcmVmcmVzaExldmVsSXRlbShkYXRhKVxuICAgIHtcbiAgICB9XG5cbiAgICBnb3RvTGV2ZWwobHYpXG4gICAge1xuICAgICAgICBsdiA9ICBwYXJzZUludChsdilcbiAgICAgICAgY29uc29sZS5sb2coXCJlbnRlciBsZXZlbFwiICAsIGx2KTtcbiAgICAgICAgVXNlckluZm8uY3VycmVudExldmVsID0gbHY7XG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcIkdhbWVcIilcbiAgICB9XG5cbiAgICBjbGlja19jb250aW51ZSgpXG4gICAge1xuICAgXG4gICAgICAgIGh0dHBVdGlscy5odHRwUG9zdChjb25zdHMuSFRUUF9SRUNPUkRfU0VSVkVSLHt0aXRsZTon6YCJ5oup5YWz5Y2h55WM6Z2iJyxjb250ZW50Oifngrnlh7vnu6fnu63muLjmiI8nfSxmdW5jdGlvbigpe30pO1xuICAgICAgICBpZihhcHBHYW1lLmdhbWVTZXJ2ZXJSb29tLmdhbWVDb25maWdEYXRhICYmYXBwR2FtZS5nYW1lU2VydmVyUm9vbS5nYW1lQ29uZmlnRGF0YS5MZXZlbERpYWxvZ0NvbnRpbnVlKXtcbiAgICAgICAgICAgIGFwcEdhbWUudmlkZW9CYW5uZXIucGxheVZpZGVvQWQoMSwwLGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgdGhpcy5nb3RvTGV2ZWwoVXNlckluZm8ubGV2ZWwpXG4gICAgICAgICAgICB9LmJpbmQodGhpcykpXG4gICAgICAgIH1lbHNle1xuICAgICAgICAgICAgdGhpcy5nb3RvTGV2ZWwoVXNlckluZm8ubGV2ZWwpXG4gICAgICAgIH1cbiAgICAgICAgXG4gICAgfVxufSJdfQ==

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Game/Scripts/Main.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '979d2m9WlRN0519FkcUBa5E', 'Main');
// Game/Scripts/Main.ts

Object.defineProperty(exports, "__esModule", { value: true });
var ViewManager_1 = require("../../framework/plugin_boosts/ui/ViewManager");
var Info_1 = require("./Info");
var Platform_1 = require("../../framework/Platform");
var Device_1 = require("../../framework/plugin_boosts/gamesys/Device");
var Res_1 = require("./hex-lines-game/Res");
var ToastManager_1 = require("../../framework/plugin_boosts/ui/ToastManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Main = /** @class */ (function (_super) {
    __extends(Main, _super);
    function Main() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Main_1 = Main;
    Main.prototype.onLoad = function () {
        Main_1.instance = this;
        Platform_1.default.login();
        Info_1.UserInfo.init();
        Device_1.default.playMusic(Res_1.R.audio_bgm);
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, { title: '游戏大厅', content: '游戏大厅onload' }, function () {
        });
    };
    Main.prototype.isNextDay = function (timeSec) {
        return this.isGreaterDate(new Date(), new Date(timeSec));
    };
    ;
    Main.prototype.isGreaterDate = function (now, before) {
        var diff = now.getTime() - before.getTime();
        if (diff > 86400000) // 24*60*60*1000
         {
            return true;
        }
        else {
            if (diff > 0)
                return now.getDate() != before.getDate();
            else
                return false;
        }
    };
    ;
    Main.prototype.start = function () {
        appGame.gameServerRoom.emit(consts.CLIENT_GAME_START, function () {
            appGame.banner.playBanner(2);
        });
    };
    Main.prototype.click_play = function () {
        ViewManager_1.default.instance.show("Game/LevelDialog");
    };
    Main.prototype.toggle_sfx = function (t) {
        Device_1.default.setSoundsEnable(!t.isChecked);
    };
    Main.prototype.click_skin = function () {
        ViewManager_1.default.instance.show("Game/ShopDialog");
    };
    Main.prototype.click_rank = function () {
        ViewManager_1.default.instance.show("wechat/WxRankDialog");
    };
    Main.prototype.onShare = function () {
    };
    Main.prototype.click_share = function () {
        Platform_1.default.share(this.onShare);
    };
    Main.prototype.click_luck = function () {
        ViewManager_1.default.instance.show("Game/LuckyDialog");
    };
    Main.prototype.click_more = function () {
        ToastManager_1.Toast.make("敬请期待");
    };
    var Main_1;
    Main.instance = null;
    Main = Main_1 = __decorate([
        ccclass
    ], Main);
    return Main;
}(cc.Component));
exports.default = Main;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcR2FtZVxcU2NyaXB0c1xcTWFpbi50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsNEVBQXVFO0FBQ3ZFLCtCQUFrQztBQUNsQyxxREFBZ0Q7QUFDaEQsdUVBQWtFO0FBQ2xFLDRDQUF5QztBQUN6Qyw4RUFBc0U7QUFFaEUsSUFBQSxLQUF3QixFQUFFLENBQUMsVUFBVSxFQUFuQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWtCLENBQUM7QUFHNUM7SUFBa0Msd0JBQVk7SUFBOUM7O0lBeUVBLENBQUM7YUF6RW9CLElBQUk7SUFLckIscUJBQU0sR0FBTjtRQUNJLE1BQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDO1FBQ3JCLGtCQUFRLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDakIsZUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO1FBQ2hCLGdCQUFNLENBQUMsU0FBUyxDQUFDLE9BQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUM5QixTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsRUFBQyxFQUFDLEtBQUssRUFBQyxNQUFNLEVBQUMsT0FBTyxFQUFDLFlBQVksRUFBQyxFQUFDO1FBQ2pGLENBQUMsQ0FBQyxDQUFDO0lBQ1AsQ0FBQztJQUNELHdCQUFTLEdBQVQsVUFBVSxPQUFPO1FBRWIsT0FBTyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksSUFBSSxFQUFFLEVBQUMsSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQTtJQUMzRCxDQUFDO0lBQUEsQ0FBQztJQUNGLDRCQUFhLEdBQWIsVUFBYyxHQUFHLEVBQUMsTUFBTTtRQUVwQixJQUFJLElBQUksR0FBRyxHQUFHLENBQUMsT0FBTyxFQUFFLEdBQUcsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFBO1FBQzNDLElBQUcsSUFBSSxHQUFHLFFBQVEsRUFBRSxnQkFBZ0I7U0FDcEM7WUFDSSxPQUFPLElBQUksQ0FBQztTQUNmO2FBQUk7WUFDRCxJQUFJLElBQUksR0FBRyxDQUFDO2dCQUNSLE9BQU8sR0FBRyxDQUFDLE9BQU8sRUFBRSxJQUFJLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQTs7Z0JBRXhDLE9BQU8sS0FBSyxDQUFDO1NBQ3BCO0lBQ0wsQ0FBQztJQUFBLENBQUM7SUFHRixvQkFBSyxHQUFMO1FBQ0ksT0FBTyxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixFQUFDO1lBQ2pELE9BQU8sQ0FBQyxNQUFNLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2pDLENBQUMsQ0FBQyxDQUFDO0lBRVAsQ0FBQztJQUVELHlCQUFVLEdBQVY7UUFDSSxxQkFBVyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsQ0FBQTtJQUNqRCxDQUFDO0lBRUQseUJBQVUsR0FBVixVQUFXLENBQUM7UUFDUixnQkFBTSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQTtJQUN4QyxDQUFDO0lBRUQseUJBQVUsR0FBVjtRQUNJLHFCQUFXLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxDQUFBO0lBQ2hELENBQUM7SUFFRCx5QkFBVSxHQUFWO1FBQ0kscUJBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLHFCQUFxQixDQUFDLENBQUE7SUFDcEQsQ0FBQztJQUVELHNCQUFPLEdBQVA7SUFFQSxDQUFDO0lBRUQsMEJBQVcsR0FBWDtRQUNJLGtCQUFRLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBRUQseUJBQVUsR0FBVjtRQUNJLHFCQUFXLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxDQUFBO0lBQ2pELENBQUM7SUFHRCx5QkFBVSxHQUFWO1FBQ0ksb0JBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDdEIsQ0FBQzs7SUFwRU0sYUFBUSxHQUFTLElBQUksQ0FBQztJQUZaLElBQUk7UUFEeEIsT0FBTztPQUNhLElBQUksQ0F5RXhCO0lBQUQsV0FBQztDQXpFRCxBQXlFQyxDQXpFaUMsRUFBRSxDQUFDLFNBQVMsR0F5RTdDO2tCQXpFb0IsSUFBSSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBWaWV3TWFuYWdlciBmcm9tIFwiLi4vLi4vZnJhbWV3b3JrL3BsdWdpbl9ib29zdHMvdWkvVmlld01hbmFnZXJcIjtcbmltcG9ydCB7IFVzZXJJbmZvIH0gZnJvbSBcIi4vSW5mb1wiO1xuaW1wb3J0IFBsYXRmb3JtIGZyb20gXCIuLi8uLi9mcmFtZXdvcmsvUGxhdGZvcm1cIjtcbmltcG9ydCBEZXZpY2UgZnJvbSBcIi4uLy4uL2ZyYW1ld29yay9wbHVnaW5fYm9vc3RzL2dhbWVzeXMvRGV2aWNlXCI7XG5pbXBvcnQgeyBSIH0gZnJvbSBcIi4vaGV4LWxpbmVzLWdhbWUvUmVzXCI7XG5pbXBvcnQgeyBUb2FzdCB9IGZyb20gXCIuLi8uLi9mcmFtZXdvcmsvcGx1Z2luX2Jvb3N0cy91aS9Ub2FzdE1hbmFnZXJcIjtcblxuY29uc3QgeyBjY2NsYXNzLCBwcm9wZXJ0eSB9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE1haW4gZXh0ZW5kcyBjYy5Db21wb25lbnQge1xuXG4gICAgc3RhdGljIGluc3RhbmNlOiBNYWluID0gbnVsbDtcblxuXG4gICAgb25Mb2FkKCkge1xuICAgICAgICBNYWluLmluc3RhbmNlID0gdGhpcztcbiAgICAgICAgUGxhdGZvcm0ubG9naW4oKTtcbiAgICAgICAgVXNlckluZm8uaW5pdCgpO1xuICAgICAgICBEZXZpY2UucGxheU11c2ljKFIuYXVkaW9fYmdtKTtcbiAgICAgICAgaHR0cFV0aWxzLmh0dHBQb3N0KGNvbnN0cy5IVFRQX1JFQ09SRF9TRVJWRVIse3RpdGxlOifmuLjmiI/lpKfljoUnLGNvbnRlbnQ6J+a4uOaIj+Wkp+WOhW9ubG9hZCd9LGZ1bmN0aW9uKCl7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBpc05leHREYXkodGltZVNlYylcbiAgICB7XG4gICAgICAgIHJldHVybiB0aGlzLmlzR3JlYXRlckRhdGUobmV3IERhdGUoKSxuZXcgRGF0ZSh0aW1lU2VjKSlcbiAgICB9O1xuICAgIGlzR3JlYXRlckRhdGUobm93LGJlZm9yZSlcbiAgICB7XG4gICAgICAgIHZhciBkaWZmID0gbm93LmdldFRpbWUoKSAtIGJlZm9yZS5nZXRUaW1lKCkgXG4gICAgICAgIGlmKGRpZmYgPiA4NjQwMDAwMCkgLy8gMjQqNjAqNjAqMTAwMFxuICAgICAgICB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICBpZiAoZGlmZiA+IDAgKVxuICAgICAgICAgICAgICAgIHJldHVybiBub3cuZ2V0RGF0ZSgpICE9IGJlZm9yZS5nZXREYXRlKClcbiAgICAgICAgICAgIGVsc2UgXG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlOyBcbiAgICAgICAgfVxuICAgIH07XG4gIFxuXG4gICAgc3RhcnQoKSB7IFxuICAgICAgICBhcHBHYW1lLmdhbWVTZXJ2ZXJSb29tLmVtaXQoY29uc3RzLkNMSUVOVF9HQU1FX1NUQVJULGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICBhcHBHYW1lLmJhbm5lci5wbGF5QmFubmVyKDIpO1xuICAgICAgICB9KTtcbiAgICAgICAgXG4gICAgfVxuXG4gICAgY2xpY2tfcGxheSgpIHtcbiAgICAgICAgVmlld01hbmFnZXIuaW5zdGFuY2Uuc2hvdyhcIkdhbWUvTGV2ZWxEaWFsb2dcIilcbiAgICB9XG5cbiAgICB0b2dnbGVfc2Z4KHQpIHtcbiAgICAgICAgRGV2aWNlLnNldFNvdW5kc0VuYWJsZSghdC5pc0NoZWNrZWQpXG4gICAgfVxuXG4gICAgY2xpY2tfc2tpbigpIHtcbiAgICAgICAgVmlld01hbmFnZXIuaW5zdGFuY2Uuc2hvdyhcIkdhbWUvU2hvcERpYWxvZ1wiKVxuICAgIH1cblxuICAgIGNsaWNrX3JhbmsoKSB7XG4gICAgICAgIFZpZXdNYW5hZ2VyLmluc3RhbmNlLnNob3coXCJ3ZWNoYXQvV3hSYW5rRGlhbG9nXCIpXG4gICAgfVxuXG4gICAgb25TaGFyZSgpIHtcblxuICAgIH1cblxuICAgIGNsaWNrX3NoYXJlKCkge1xuICAgICAgICBQbGF0Zm9ybS5zaGFyZSh0aGlzLm9uU2hhcmUpO1xuICAgIH1cblxuICAgIGNsaWNrX2x1Y2soKSB7XG4gICAgICAgIFZpZXdNYW5hZ2VyLmluc3RhbmNlLnNob3coXCJHYW1lL0x1Y2t5RGlhbG9nXCIpXG4gICAgfVxuXG5cbiAgICBjbGlja19tb3JlKCkge1xuICAgICAgICBUb2FzdC5tYWtlKFwi5pWs6K+35pyf5b6FXCIpXG4gICAgfVxuXG4gICAgLy8gdXBkYXRlIChkdCkge31cbn1cbiJdfQ==
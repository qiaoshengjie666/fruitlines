
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Game/Scripts/hex-lines-game/Game.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4c9b5SEXlhDAqXGat0NcWmI', 'Game');
// Game/Scripts/hex-lines-game/Game.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Res_1 = require("./Res");
var HexonTile_1 = require("./HexonTile");
var GridManager_1 = require("./GridManager");
var InputSystem_1 = require("../../../framework/plugin_boosts/misc/InputSystem");
var Info_1 = require("../Info");
var Animal_1 = require("./Animal");
var ViewManager_1 = require("../../../framework/plugin_boosts/ui/ViewManager");
var Platform_1 = require("../../../framework/Platform");
var ToastManager_1 = require("../../../framework/plugin_boosts/ui/ToastManager");
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var LineGame = /** @class */ (function (_super) {
    __extends(LineGame, _super);
    function LineGame() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._isGameOver = false;
        _this._moveCount = 0;
        _this._playTime = 0;
        _this._colCount = 6;
        _this._rowCount = 7;
        _this._pickedTile = null;
        _this.tileLayer = null;
        _this.levelLabel = null;
        _this.timeLabel = null;
        _this.stepLabel = null;
        _this.focusNode = null;
        _this._figureList = [];
        _this.perfectMoveCount = 0;
        return _this;
    }
    LineGame_1 = LineGame;
    LineGame.prototype.get_isGameOver = function () {
        return this._isGameOver;
    };
    LineGame.prototype.get_minCol = function () {
        return this._levelData.mincol;
    };
    LineGame.prototype.get_moveCount = function () {
        return this._moveCount;
    };
    LineGame.prototype.loadLevel = function (t) {
        //test :
        t = Math.min(t, Res_1.R.levelJson.json.levels.length - 1);
        this._levelData = Res_1.R.levelJson.json.levels[t];
        this.levelLabel.string = t + "";
        if (t == 1) {
            this.scheduleOnce(this.openGuide, 0.1);
        }
    };
    LineGame.prototype.openGuide = function () {
        ViewManager_1.default.instance.show("Game/OpenGuide");
    };
    LineGame.prototype.onLoad = function () {
        var _this = this;
        var t = this;
        LineGame_1.instance = this;
        this.loadLevel(Info_1.UserInfo.currentLevel);
        //this.loadLevel(75)
        this.hideFocus();
        this._tileList = [];
        this._rowCount = this._levelData.size;
        this._colCount -= 1;
        for (var e = 0, n = this._rowCount; n > e;) {
            var i, s = e++;
            var tmplist = [];
            i = s <= this._rowCount / 2 ? this._levelData.mincol + s : this._levelData.mincol - 1 + this._rowCount - s;
            for (var r = 0; i > r;) {
                var o = r++;
                var node = cc.instantiate(Res_1.R.TilePrefab);
                var tile = node.getComponent(HexonTile_1.default);
                node.parent = this.tileLayer;
                node.zIndex = this._rowCount - s;
                // this._tileLayer.addChild((new g).add(node))
                tile.set_row(s);
                tile.set_col(o);
                //------------------------------------------------------------------------------//
                var shadowNode = cc.instantiate(Res_1.R.TileShadow);
                var shadow = shadowNode.getComponent(HexonTile_1.default);
                shadow.set_row(s);
                shadow.set_col(o);
                shadowNode.y -= 3;
                shadowNode.parent = this.tileLayer;
                shadowNode.zIndex = 0;
                //------------------------------------------------------------------------------//
                tmplist.push(tile);
            }
            this._tileList.push(tmplist);
            appGame.gameServerRoom.emit(consts.CLIENT_GAME_START, {});
            appGame.banner.playBanner(2);
            //插屏广告
            this.schedule(function () {
                console.log("插屏广告==");
                if (appGame.interstitialAd) {
                    appGame.interstitialAd.playAd("插屏");
                }
            }, 60);
            //积木广告
            this.schedule(function () {
                console.log("积木广告==");
                if (appGame.qqblockad) {
                    appGame.qqblockad.playBlockad(true);
                }
            }, 30);
        }
        this._gridManager = this.tileLayer.addComponent(GridManager_1.default);
        this._gridManager.init(this._levelData.mincol);
        // this._lineLayer = (new g).add(this._gridManager),
        // this.owner.addChild(this._lineLayer),
        this.setFigure();
        this.addComponent(InputSystem_1.InputSystem);
        // this._uiLayer = new g,
        // this._uiManager = new ni(this._stageIndex + 1),
        // this.owner.addChild(this._uiLayer.add(this._uiManager))
        Info_1.UserInfo.timePassed = 0;
        Info_1.UserInfo.stepUsed = 0;
        this.schedule(function (_) {
            Info_1.UserInfo.timePassed += 1;
            _this.timeLabel.string = Info_1.UserInfo.timePassed + "s";
            _this.stepLabel.string = Info_1.UserInfo.stepUsed + "步";
        }, 1);
    };
    LineGame.prototype.onTouchBegan = function (e) {
        var t = this;
        if (!t._isGameOver) {
            // var n = t.touchXtoScreenX(e.viewX)
            // var e = t.touchYtoScreenY(e.viewY)
            // var i = t.findTileByPos(n, e)
            var p = e.currentTouch.getLocation();
            p = this.node.convertToNodeSpaceAR(p);
            var i = t.findTileByPos(p.x, p.y);
            if (null != i && 0 != i.get_animal()) {
                cc.audioEngine.playEffect(Res_1.R.audio_down, false);
                // jn.playSound(0)
                t._pickedTile = i;
                t.removeGridFromTile(t._pickedTile);
                t._pickedTile.connect(null);
                if (null != t._pickedTile.targetTile) {
                    t.removeGridFromTile(t._pickedTile.targetTile);
                    t._pickedTile.targetTile.connect(null);
                    t._pickedTile.targetTile.set_isConnecting(false);
                }
                t._pickedTile.set_isConnecting(!0);
                i = t._pickedTile.getHead();
                for (; null != i;)
                    i.set_isConnecting(!0),
                        i = i.connectedTile;
                // t._uiManager.showFocus(t._pickedTile.get_animal()),
                this.showFocus(t._pickedTile.get_animal());
                // t._uiManager.moveFocus(n, e)
                this.moveFocus(p);
            }
            this.checkCompelete();
            // 1 ==  ? 1 == t.checkFillAll() ? t._uiManager.hideFillAllPopup() : t._uiManager.showFillAllPopup() : t._uiManager.hideFillAllPopup()
        }
    };
    LineGame.prototype.checkCompelete = function () {
        if (this.checkConnectedAll()) {
            if (this.checkFillAll()) {
                // t._uiManager.hideFillAllPopup()
            }
            else {
                //  t._uiManager.showFillAllPopup()
            }
        }
        else {
            // _uiManager.hideFillAllPopup()
        }
    };
    LineGame.prototype.isTileConnected = function (t, e) {
        var n, i = t._row;
        n = t._col + (i <= this._rowCount / 2 ? 0 : t._row - (this._rowCount / 2 | 0));
        var s, a = e._row;
        return s = e._col + (a <= this._rowCount / 2 ? 0 : e._row - (this._rowCount / 2 | 0)),
            i - 1 == a && n - 1 == s || i - 1 == a && n == s || i == a && n - 1 == s || i == a && n + 1 == s || i + 1 == a && n == s || i + 1 == a && n + 1 == s ? true : false;
    };
    LineGame.prototype.onTouchMoved = function (e) {
        var t = this;
        if (!t._isGameOver) {
            var p = e.currentTouch.getLocation();
            p = this.node.convertToNodeSpaceAR(p);
            var i = t.findTileByPos(p.x, p.y);
            if (null != t._pickedTile && null != i)
                if (t.isTileConnected(t._pickedTile, i)) {
                    if (0 == i.get_animal())
                        (null == t._pickedTile.targetTile || null == t._pickedTile.reverseConnectedTile) && (t._gridManager.setState(t._pickedTile.get_row(), t._pickedTile.get_col(), i.get_row(), i.get_col(), !0), t._pickedTile.connect(i), t._pickedTile = i, t._pickedTile.set_isConnecting(!0));
                    else if (i.get_animal() == t._pickedTile.get_animal())
                        if (false == i.isChangable && !i.equals(t._pickedTile.getHead()))
                            null == i.reverseConnectedTile && (t._gridManager.setState(t._pickedTile.get_row(), t._pickedTile.get_col(), i.get_row(), i.get_col(), !0), t._pickedTile.connect(i), t._pickedTile = i);
                        else {
                            for (t._pickedTile = i, i = t._pickedTile; null != i && null != i.connectedTile;)
                                t._gridManager.setState(i.get_row(), i.get_col(), i.connectedTile.get_row(), i.connectedTile.get_col(), !1),
                                    i = i.connectedTile;
                            t._pickedTile.connect(null);
                        }
                }
                else if (i.get_animal() == t._pickedTile.get_animal() && !i.equals(t._pickedTile) && null != i.connectedTile) {
                    for (t._pickedTile = i, i = t._pickedTile; null != i && null != i.connectedTile;)
                        t._gridManager.setState(i.get_row(), i.get_col(), i.connectedTile.get_row(), i.connectedTile.get_col(), !1),
                            i = i.connectedTile;
                    t._pickedTile.connect(null);
                }
            this.moveFocus(p);
            // t._uiManager.moveFocus(n, e),
            //this.checkCompelete()
        }
    };
    LineGame.prototype.onTouchEnded = function () {
        var t = this;
        var e = false;
        if (!t._isGameOver) {
            if (null != t._pickedTile) {
                var n = t._pickedTile.getHead();
                for (null != t._pickedTile.animalSprite && null != n && null != n.animalSprite && (e = true, t._pickedTile.animalSprite.connected(), n.animalSprite.connected()); null != n;)
                    n.set_isConnecting(false),
                        n = n.connectedTile;
                t._moveCount++;
                Info_1.UserInfo.stepUsed++;
            }
            t._pickedTile = null;
            // t._uiManager.hideFocus(),
            this.hideFocus();
            if (t.checkConnectedAll()) {
                if (t.checkFillAll()) {
                    // t._uiManager.hideFillAllPopup()
                    t._isGameOver = true;
                    // t._uiManager.showClearPopup(t._moveCount, t.perfectMoveCount)
                    t.danceAll();
                }
                else {
                    //  t._uiManager.showFillAllPopup()
                    ToastManager_1.Toast.make("必须填满所有格子");
                }
            }
            else {
                // _uiManager.hideFillAllPopup()
            }
            if (e == true && !t._isGameOver) {
                // jn.playSound(1)
                cc.audioEngine.playEffect(Res_1.R.audio_link, false);
            }
            // 1 == e && 0 == t._isGameOver && jn.playSound(1)
        }
    };
    LineGame.prototype.showFocus = function (animal) {
        console.log(animal);
        this.focusNode.active = true;
        this.focusNode.zIndex = 100;
        this.focusNode.color = Res_1.R.colors[animal].clone();
    };
    LineGame.prototype.moveFocus = function (p) {
        this.focusNode.position = p;
    };
    LineGame.prototype.hideFocus = function () {
        this.focusNode.active = false;
    };
    LineGame.prototype.danceAll = function () {
        // jn.playSound(3);
        cc.audioEngine.playEffect(Res_1.R.audio_win, false);
        for (var t = 0, e = this._tileList; t < e.length;) {
            var n = e[t];
            ++t;
            for (var i = 0; i < n.length;) {
                var s = n[i];
                ++i,
                    null != s.animalSprite && s.animalSprite.loopJump(1);
            }
        }
        this.scheduleOnce(this.showWinDialog, 1);
    };
    LineGame.prototype.showWinDialog = function () {
        ViewManager_1.default.instance.show("Game/WinDialog");
    };
    LineGame.prototype.click_pause = function () {
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, { title: '游戏界面', content: '点击返回' }, function () { });
        ViewManager_1.default.instance.show("Game/PauseDialog");
    };
    LineGame.prototype.click_share = function () {
        Platform_1.default.share();
    };
    LineGame.prototype.setFigure = function () {
        // this._figureLayer = new g,
        this._figureList = [];
        // this.owner.addChild(this._figureLayer);
        for (var t = [], e = 0; 10 > e;)
            e++, t.push(null);
        for (var e = 0, n = this._levelData.figure; e < n.length;) {
            var i = n[e];
            ++e;
            var s = this._tileList[i[0]][i[1]];
            var a = s.get_borderPosition();
            // s.animalSprite = new $n(i[2], a.get_x(), a.get_y())
            // this.owner.addChild((new g).add(s.animalSprite))
            var type = i[2];
            var node = cc.instantiate(Res_1.R.animalPrefabs[type - 1]);
            s.animalSprite = node.getComponent(Animal_1.default);
            // s.animalSprite.type = type;
            node.setPosition(a.x, a.y);
            node.parent = this.tileLayer;
            node.zIndex = 110;
            // animal.type = type; 
            // animal.tx = a.x ; 
            s.set_animal(i[2]);
            s.isChangable = false;
            this._figureList.push(s);
            null == t[i[2]] ? t[i[2]] = s : (s.targetTile = t[i[2]], t[i[2]].targetTile = s);
        }
        this.perfectMoveCount = this._figureList.length / 2 | 0;
    };
    LineGame.prototype.findTileByPos = function (x, y) {
        var n = null;
        var i = 1e6;
        var s = cc.v2(x, y);
        var r = this._tileList;
        for (var a = 0; a < r.length; ++a) {
            var o = r[a];
            for (var _ = 0; _ < o.length; ++_) {
                var l = o[_];
                var tp = o[_].node.position;
                var h = s.sub(tp).mag();
                if (h < 50 && h < i) {
                    i = h;
                    n = l;
                }
                // 40 > h && i > h && (i = h, n = l)
            }
        }
        return n;
    };
    LineGame.prototype.removeGridFromTile = function (t) {
        for (; null != t && null != t.connectedTile;)
            this._gridManager.setState(t.get_row(), t.get_col(), t.connectedTile.get_row(), t.connectedTile.get_col(), !1), t = t.connectedTile;
    };
    LineGame.prototype.checkFillAll = function () {
        for (var t = 0, e = this._tileList; t < e.length;) {
            var n = e[t];
            ++t;
            for (var i = 0; i < n.length;) {
                var s = n[i];
                if (++i, 0 == s.get_animal())
                    return !1;
            }
        }
        return !0;
    };
    LineGame.prototype.checkConnectedAll = function () {
        for (var t = 0, e = this._tileList; t < e.length;) {
            var n = e[t];
            ++t;
            for (var i = 0; i < n.length;) {
                var s = n[i];
                if (++i, null != s.targetTile) {
                    var a = s.getHead(), r = s.getTail();
                    if (0 == s.targetTile.equals(a) && 0 == s.targetTile.equals(r))
                        return !1;
                }
            }
        }
        return !0;
    };
    var LineGame_1;
    LineGame.instance = null;
    __decorate([
        property(cc.Node)
    ], LineGame.prototype, "tileLayer", void 0);
    __decorate([
        property(cc.Label)
    ], LineGame.prototype, "levelLabel", void 0);
    __decorate([
        property(cc.Label)
    ], LineGame.prototype, "timeLabel", void 0);
    __decorate([
        property(cc.Label)
    ], LineGame.prototype, "stepLabel", void 0);
    __decorate([
        property(cc.Node)
    ], LineGame.prototype, "focusNode", void 0);
    LineGame = LineGame_1 = __decorate([
        ccclass
    ], LineGame);
    return LineGame;
}(cc.Component));
exports.default = LineGame;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcR2FtZVxcU2NyaXB0c1xcaGV4LWxpbmVzLWdhbWVcXEdhbWUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDZCQUEwQjtBQUMxQix5Q0FBb0M7QUFDcEMsNkNBQXdDO0FBQ3hDLGlGQUF1RjtBQUN2RixnQ0FBbUM7QUFDbkMsbUNBQThCO0FBQzlCLCtFQUEwRTtBQUMxRSx3REFBbUQ7QUFDbkQsaUZBQXlFO0FBR25FLElBQUEsS0FBc0IsRUFBRSxDQUFDLFVBQVUsRUFBbEMsT0FBTyxhQUFBLEVBQUUsUUFBUSxjQUFpQixDQUFDO0FBRzFDO0lBQXNDLDRCQUFZO0lBQWxEO1FBQUEscUVBb1pDO1FBL1lHLGlCQUFXLEdBQVcsS0FBSyxDQUFDO1FBQzVCLGdCQUFVLEdBQVUsQ0FBQyxDQUFDO1FBRXRCLGVBQVMsR0FBRyxDQUFDLENBQUM7UUFDZCxlQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ2QsZUFBUyxHQUFHLENBQUMsQ0FBQztRQUVkLGlCQUFXLEdBQWEsSUFBSSxDQUFDO1FBSzdCLGVBQVMsR0FBVyxJQUFJLENBQUM7UUFHekIsZ0JBQVUsR0FBWSxJQUFJLENBQUM7UUFHM0IsZUFBUyxHQUFZLElBQUksQ0FBQztRQUcxQixlQUFTLEdBQVksSUFBSSxDQUFDO1FBRzFCLGVBQVMsR0FBVyxJQUFJLENBQUM7UUFFekIsaUJBQVcsR0FBRyxFQUFFLENBQUE7UUFFaEIsc0JBQWdCLEdBQUcsQ0FBQyxDQUFDOztJQW1YekIsQ0FBQztpQkFwWm9CLFFBQVE7SUFxQ3pCLGlDQUFjLEdBQWQ7UUFDSSxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUE7SUFDM0IsQ0FBQztJQUNELDZCQUFVLEdBQVY7UUFDSSxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFBO0lBQ2pDLENBQUM7SUFDRCxnQ0FBYSxHQUFiO1FBQ0ksT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFBO0lBQzFCLENBQUM7SUFFRCw0QkFBUyxHQUFULFVBQVUsQ0FBQztRQUNQLFFBQVE7UUFDUixDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsT0FBQyxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sR0FBQyxDQUFDLENBQUMsQ0FBQTtRQUNqRCxJQUFJLENBQUMsVUFBVSxHQUFHLE9BQUMsQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUM3QyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUUsRUFBRSxDQUFBO1FBQzlCLElBQUcsQ0FBQyxJQUFJLENBQUMsRUFDVDtZQUNJLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBQyxHQUFHLENBQUMsQ0FBQTtTQUN4QztJQUNMLENBQUM7SUFFRCw0QkFBUyxHQUFUO1FBRUkscUJBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUE7SUFDL0MsQ0FBQztJQUVELHlCQUFNLEdBQU47UUFBQSxpQkE4RUM7UUE3RUcsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO1FBQ2IsVUFBUSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUM7UUFDekIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxlQUFRLENBQUMsWUFBWSxDQUFDLENBQUE7UUFDckMsb0JBQW9CO1FBQ3BCLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQztRQUNqQixJQUFJLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQTtRQUNuQixJQUFJLENBQUMsU0FBUyxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFBO1FBQ3JDLElBQUksQ0FBQyxTQUFTLElBQUksQ0FBQyxDQUFDO1FBRXBCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUc7WUFDeEMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFBO1lBQ2QsSUFBSSxPQUFPLEdBQUcsRUFBRSxDQUFDO1lBQ2pCLENBQUMsR0FBRyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO1lBQzNHLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLEdBQUc7Z0JBQ3BCLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRyxDQUFBO2dCQUNaLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsT0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFBO2dCQUN2QyxJQUFJLElBQUksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLG1CQUFTLENBQUMsQ0FBQztnQkFDeEMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDO2dCQUM3QixJQUFJLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxDQUFDO2dCQUNqQyw4Q0FBOEM7Z0JBQzlDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUE7Z0JBQ2YsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQTtnQkFFZixrRkFBa0Y7Z0JBQ2xGLElBQUksVUFBVSxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsT0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFBO2dCQUM3QyxJQUFJLE1BQU0sR0FBRyxVQUFVLENBQUMsWUFBWSxDQUFDLG1CQUFTLENBQUMsQ0FBQztnQkFDaEQsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQTtnQkFDakIsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQTtnQkFDakIsVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7Z0JBQ2xCLFVBQVUsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztnQkFDbkMsVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7Z0JBQ3RCLGtGQUFrRjtnQkFHbEYsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTthQUNyQjtZQUNELElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO1lBRTVCLE9BQU8sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxpQkFBaUIsRUFBQyxFQUFFLENBQUMsQ0FBQztZQUN6RCxPQUFPLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUU3QixNQUFNO1lBQ04sSUFBSSxDQUFDLFFBQVEsQ0FBQztnQkFDVixPQUFPLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2dCQUN0QixJQUFHLE9BQU8sQ0FBQyxjQUFjLEVBQUM7b0JBQ3RCLE9BQU8sQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDO2lCQUN2QztZQUNMLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztZQUNQLE1BQU07WUFDTixJQUFJLENBQUMsUUFBUSxDQUFDO2dCQUNWLE9BQU8sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUM7Z0JBQ3RCLElBQUcsT0FBTyxDQUFDLFNBQVMsRUFBQztvQkFDakIsT0FBTyxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUM7aUJBQ3ZDO1lBQ0wsQ0FBQyxFQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQ1Q7UUFFRCxJQUFJLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLHFCQUFXLENBQUMsQ0FBQTtRQUM1RCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO1FBQy9DLG9EQUFvRDtRQUNwRCx3Q0FBd0M7UUFDeEMsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFBO1FBRWhCLElBQUksQ0FBQyxZQUFZLENBQUMseUJBQVcsQ0FBQyxDQUFDO1FBRy9CLHlCQUF5QjtRQUN6QixrREFBa0Q7UUFDbEQsMERBQTBEO1FBRTFELGVBQVEsQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO1FBQ3hCLGVBQVEsQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDO1FBQ3RCLElBQUksQ0FBQyxRQUFRLENBQUMsVUFBQSxDQUFDO1lBQ1gsZUFBUSxDQUFDLFVBQVUsSUFBSSxDQUFDLENBQUE7WUFDeEIsS0FBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsZUFBUSxDQUFDLFVBQVUsR0FBRyxHQUFHLENBQUM7WUFDbEQsS0FBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsZUFBUSxDQUFDLFFBQVEsR0FBRSxHQUFHLENBQUE7UUFDbEQsQ0FBQyxFQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ1IsQ0FBQztJQUdELCtCQUFZLEdBQVosVUFBYSxDQUFDO1FBRVYsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO1FBQ2IsSUFBSSxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDaEIscUNBQXFDO1lBQ3JDLHFDQUFxQztZQUNyQyxnQ0FBZ0M7WUFDaEMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNyQyxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN0QyxJQUFJLENBQUMsR0FBYSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRTNDLElBQUksSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDLFVBQVUsRUFBRSxFQUFFO2dCQUNsQyxFQUFFLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxPQUFDLENBQUMsVUFBVSxFQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUM5QyxrQkFBa0I7Z0JBQ2xCLENBQUMsQ0FBQyxXQUFXLEdBQUcsQ0FBQyxDQUFBO2dCQUNqQixDQUFDLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxDQUFBO2dCQUNuQyxDQUFDLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQTtnQkFDM0IsSUFBRyxJQUFJLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQ25DO29CQUNJLENBQUMsQ0FBQyxrQkFBa0IsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFBO29CQUM5QyxDQUFDLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUE7b0JBQ3RDLENBQUMsQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLGdCQUFnQixDQUFDLEtBQUssQ0FBQyxDQUFBO2lCQUNuRDtnQkFDRCxDQUFDLENBQUMsV0FBVyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7Z0JBQ2xDLENBQUMsR0FBRyxDQUFDLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxDQUFDO2dCQUM1QixPQUFPLElBQUksSUFBSSxDQUFDO29CQUFHLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQzt3QkFDekMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxhQUFhLENBQUM7Z0JBQ3BCLHNEQUFzRDtnQkFDdEQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUM7Z0JBQzNDLCtCQUErQjtnQkFDL0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUNyQjtZQUNELElBQUksQ0FBQyxjQUFjLEVBQUUsQ0FBQTtZQUNyQixzSUFBc0k7U0FDekk7SUFDTCxDQUFDO0lBRUQsaUNBQWMsR0FBZDtRQUVJLElBQUksSUFBSSxDQUFDLGlCQUFpQixFQUFFLEVBQzVCO1lBQ0ksSUFBRyxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQ3RCO2dCQUNJLGtDQUFrQzthQUNyQztpQkFBSTtnQkFDRCxtQ0FBbUM7YUFFdEM7U0FDSjthQUFJO1lBQ0QsZ0NBQWdDO1NBQ25DO0lBQ0wsQ0FBQztJQUVELGtDQUFlLEdBQWYsVUFBZ0IsQ0FBQyxFQUFFLENBQUM7UUFDaEIsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDbEIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUksSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDL0UsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDbEIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDckYsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFBLENBQUMsQ0FBQSxLQUFLLENBQUE7SUFDckssQ0FBQztJQUdELCtCQUFZLEdBQVosVUFBYSxDQUFDO1FBRVYsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDO1FBQ2IsSUFBSSxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUU7WUFDaEIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUNyQyxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN0QyxJQUFJLENBQUMsR0FBYSxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRTNDLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQyxXQUFXLElBQUksSUFBSSxJQUFJLENBQUM7Z0JBQUUsSUFBSSxDQUFDLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDLEVBQUU7b0JBQzdFLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLEVBQUU7d0JBQUMsQ0FBQyxJQUFJLElBQUksQ0FBQyxDQUFDLFdBQVcsQ0FBQyxVQUFVLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQyxXQUFXLENBQUMsb0JBQW9CLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFdBQVcsR0FBRyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7eUJBQ2xTLElBQUksQ0FBQyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQyxXQUFXLENBQUMsVUFBVSxFQUFFO3dCQUFFLElBQUksS0FBSyxJQUFJLENBQUMsQ0FBQyxXQUFXLElBQUksQ0FBRSxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLENBQUM7NEJBQUUsSUFBSSxJQUFJLENBQUMsQ0FBQyxvQkFBb0IsSUFBSSxDQUFDLENBQUMsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFdBQVcsR0FBRyxDQUFDLENBQUMsQ0FBQzs2QkFDOVM7NEJBQ0QsS0FBSyxDQUFDLENBQUMsV0FBVyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFdBQVcsRUFBRSxJQUFJLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLENBQUMsYUFBYTtnQ0FBRyxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztvQ0FDN0wsQ0FBQyxHQUFHLENBQUMsQ0FBQyxhQUFhLENBQUM7NEJBQ3BCLENBQUMsQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFBO3lCQUM5QjtpQkFDSjtxQkFBTSxJQUFJLENBQUMsQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUMsV0FBVyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQyxhQUFhLEVBQUU7b0JBQzVHLEtBQUssQ0FBQyxDQUFDLFdBQVcsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXLEVBQUUsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLGFBQWE7d0JBQUcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUM7NEJBQzdMLENBQUMsR0FBRyxDQUFDLENBQUMsYUFBYSxDQUFDO29CQUNwQixDQUFDLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQTtpQkFDOUI7WUFDRCxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFBO1lBQ2pCLGdDQUFnQztZQUNoQyx1QkFBdUI7U0FDMUI7SUFDTCxDQUFDO0lBRUQsK0JBQVksR0FBWjtRQUVJLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQztRQUNiLElBQUksQ0FBQyxHQUFHLEtBQUssQ0FBQztRQUNkLElBQUksQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFO1lBQ2hCLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQyxXQUFXLEVBQUU7Z0JBQ3ZCLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ2hDLEtBQUssSUFBSSxJQUFJLENBQUMsQ0FBQyxXQUFXLENBQUMsWUFBWSxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksSUFBSSxJQUFJLENBQUMsQ0FBQyxZQUFZLElBQUksQ0FBQyxDQUFDLEdBQUcsSUFBSSxFQUFFLENBQUMsQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUMsQ0FBQyxZQUFZLENBQUMsU0FBUyxFQUFFLENBQUMsRUFBRSxJQUFJLElBQUksQ0FBQztvQkFBRyxDQUFDLENBQUMsZ0JBQWdCLENBQUMsS0FBSyxDQUFDO3dCQUN2TSxDQUFDLEdBQUcsQ0FBQyxDQUFDLGFBQWEsQ0FBQztnQkFDcEIsQ0FBQyxDQUFDLFVBQVUsRUFBRSxDQUFBO2dCQUNkLGVBQVEsQ0FBQyxRQUFRLEVBQUcsQ0FBQzthQUN4QjtZQUNELENBQUMsQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFBO1lBQ3BCLDRCQUE0QjtZQUM1QixJQUFJLENBQUMsU0FBUyxFQUFFLENBQUM7WUFDakIsSUFBSSxDQUFDLENBQUMsaUJBQWlCLEVBQUUsRUFDekI7Z0JBQ0ksSUFBRyxDQUFDLENBQUMsWUFBWSxFQUFFLEVBQ25CO29CQUNJLGtDQUFrQztvQkFDbEMsQ0FBQyxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUM7b0JBQ3JCLGdFQUFnRTtvQkFDaEUsQ0FBQyxDQUFDLFFBQVEsRUFBRSxDQUFDO2lCQUVoQjtxQkFBSTtvQkFDRCxtQ0FBbUM7b0JBQ25DLG9CQUFLLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFBO2lCQUN6QjthQUNKO2lCQUFJO2dCQUNELGdDQUFnQzthQUNuQztZQUNELElBQUcsQ0FBQyxJQUFHLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQzdCO2dCQUNJLGtCQUFrQjtnQkFDbEIsRUFBRSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsT0FBQyxDQUFDLFVBQVUsRUFBQyxLQUFLLENBQUMsQ0FBQzthQUNqRDtZQUNELGtEQUFrRDtTQUNyRDtJQUNMLENBQUM7SUFFRCw0QkFBUyxHQUFULFVBQVUsTUFBTTtRQUVaLE9BQU8sQ0FBQyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDcEIsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFBO1FBQzVCLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQztRQUM1QixJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssR0FBRyxPQUFDLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDO0lBQ3BELENBQUM7SUFFRCw0QkFBUyxHQUFULFVBQVUsQ0FBQztRQUVQLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQztJQUNoQyxDQUFDO0lBRUQsNEJBQVMsR0FBVDtRQUVJLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQTtJQUNqQyxDQUFDO0lBRUQsMkJBQVEsR0FBUjtRQUNJLG1CQUFtQjtRQUNuQixFQUFFLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxPQUFDLENBQUMsU0FBUyxFQUFDLEtBQUssQ0FBQyxDQUFDO1FBQzdDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxHQUFHO1lBQzlDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUFDLEVBQUUsQ0FBQyxDQUFDO1lBQ2xCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxHQUFHO2dCQUMzQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQUMsRUFBRSxDQUFDO29CQUNqQixJQUFJLElBQUksQ0FBQyxDQUFDLFlBQVksSUFBSSxDQUFDLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQTthQUN2RDtTQUNKO1FBR0QsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFDLENBQUMsQ0FBQyxDQUFBO0lBQzNDLENBQUM7SUFFRCxnQ0FBYSxHQUFiO1FBRUkscUJBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLENBQUE7SUFDL0MsQ0FBQztJQUVELDhCQUFXLEdBQVg7UUFFSSxTQUFTLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0IsRUFBQyxFQUFDLEtBQUssRUFBQyxNQUFNLEVBQUMsT0FBTyxFQUFDLE1BQU0sRUFBQyxFQUFDLGNBQVcsQ0FBQyxDQUFDLENBQUM7UUFDekYscUJBQVcsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUE7SUFDakQsQ0FBQztJQUVELDhCQUFXLEdBQVg7UUFFSSxrQkFBUSxDQUFDLEtBQUssRUFBRSxDQUFDO0lBQ3JCLENBQUM7SUFFRCw0QkFBUyxHQUFUO1FBQ0ksNkJBQTZCO1FBQzdCLElBQUksQ0FBQyxXQUFXLEdBQUcsRUFBRSxDQUFBO1FBQ3JCLDBDQUEwQztRQUMxQyxLQUFLLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLEVBQUUsR0FBRyxDQUFDO1lBQUcsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUVuRCxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEdBQUc7WUFDdkQsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2IsRUFBRSxDQUFDLENBQUM7WUFDSixJQUFJLENBQUMsR0FBYSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO1lBQzVDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1lBRS9CLHNEQUFzRDtZQUN0RCxtREFBbUQ7WUFDbkQsSUFBSSxJQUFJLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2hCLElBQUksSUFBSSxHQUFHLEVBQUUsQ0FBQyxXQUFXLENBQUMsT0FBQyxDQUFDLGFBQWEsQ0FBQyxJQUFJLEdBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUNsRCxDQUFDLENBQUMsWUFBWSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUMsZ0JBQU0sQ0FBQyxDQUFDO1lBQzNDLDhCQUE4QjtZQUM5QixJQUFJLENBQUMsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQzFCLElBQUksQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQztZQUM3QixJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQztZQUVsQix1QkFBdUI7WUFDdkIscUJBQXFCO1lBRXJCLENBQUMsQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7WUFDbEIsQ0FBQyxDQUFDLFdBQVcsR0FBRyxLQUFLLENBQUE7WUFDckIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUE7WUFDeEIsSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxDQUFBO1NBQ25GO1FBQ0QsSUFBSSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUE7SUFDM0QsQ0FBQztJQUVELGdDQUFhLEdBQWIsVUFBYyxDQUFDLEVBQUUsQ0FBQztRQUNkLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQTtRQUNaLElBQUksQ0FBQyxHQUFHLEdBQUcsQ0FBQTtRQUNYLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFBO1FBQ25CLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUE7UUFDdEIsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUMsRUFBRSxDQUFDLEVBQUU7WUFDOUIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2IsS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEVBQUMsRUFBRSxDQUFDLEVBQUU7Z0JBQzlCLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtnQkFDWixJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztnQkFDNUIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQTtnQkFDdkIsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUU7b0JBQ2pCLENBQUMsR0FBRyxDQUFDLENBQUM7b0JBQ04sQ0FBQyxHQUFHLENBQUMsQ0FBQztpQkFDVDtnQkFDRCxvQ0FBb0M7YUFDdkM7U0FDSjtRQUNELE9BQU8sQ0FBQyxDQUFBO0lBQ1osQ0FBQztJQUNELHFDQUFrQixHQUFsQixVQUFtQixDQUFDO1FBQ2hCLE9BQU8sSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxDQUFDLGFBQWE7WUFBRyxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQyxhQUFhLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsYUFBYSxDQUFBO0lBQ3JMLENBQUM7SUFDRCwrQkFBWSxHQUFaO1FBQ0ksS0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxNQUFNLEdBQUc7WUFDL0MsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBQ2IsRUFBRSxDQUFDLENBQUM7WUFDSixLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sR0FBRztnQkFDM0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2dCQUNiLElBQUksRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLEVBQUU7b0JBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQTthQUMxQztTQUNKO1FBQ0QsT0FBTyxDQUFDLENBQUMsQ0FBQTtJQUNiLENBQUM7SUFDRCxvQ0FBaUIsR0FBakI7UUFDSSxLQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLFNBQVMsRUFBRSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE1BQU0sR0FBRztZQUMvQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDYixFQUFFLENBQUMsQ0FBQztZQUNKLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsTUFBTSxHQUFHO2dCQUMzQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ2IsSUFBSSxFQUFFLENBQUMsRUFBRSxJQUFJLElBQUksQ0FBQyxDQUFDLFVBQVUsRUFBRTtvQkFDM0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUNmLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUM7b0JBQ3BCLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7d0JBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQTtpQkFDNUU7YUFDSjtTQUNKO1FBQ0QsT0FBTyxDQUFDLENBQUMsQ0FBQTtJQUNiLENBQUM7O0lBcllNLGlCQUFRLEdBQVksSUFBSSxDQUFDO0lBR2hDO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUM7K0NBQ087SUFHekI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQztnREFDUTtJQUczQjtRQURDLFFBQVEsQ0FBQyxFQUFFLENBQUMsS0FBSyxDQUFDOytDQUNPO0lBRzFCO1FBREMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUM7K0NBQ087SUFHMUI7UUFEQyxRQUFRLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQzsrQ0FDTztJQTdCUixRQUFRO1FBRDVCLE9BQU87T0FDYSxRQUFRLENBb1o1QjtJQUFELGVBQUM7Q0FwWkQsQUFvWkMsQ0FwWnFDLEVBQUUsQ0FBQyxTQUFTLEdBb1pqRDtrQkFwWm9CLFFBQVEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBSIH0gZnJvbSBcIi4vUmVzXCI7XG5pbXBvcnQgSGV4b25UaWxlIGZyb20gXCIuL0hleG9uVGlsZVwiO1xuaW1wb3J0IEdyaWRNYW5hZ2VyIGZyb20gXCIuL0dyaWRNYW5hZ2VyXCI7XG5pbXBvcnQgeyBJbnB1dCwgSW5wdXRTeXN0ZW0gfSBmcm9tIFwiLi4vLi4vLi4vZnJhbWV3b3JrL3BsdWdpbl9ib29zdHMvbWlzYy9JbnB1dFN5c3RlbVwiO1xuaW1wb3J0IHsgVXNlckluZm8gfSBmcm9tIFwiLi4vSW5mb1wiO1xuaW1wb3J0IEFuaW1hbCBmcm9tIFwiLi9BbmltYWxcIjtcbmltcG9ydCBWaWV3TWFuYWdlciBmcm9tIFwiLi4vLi4vLi4vZnJhbWV3b3JrL3BsdWdpbl9ib29zdHMvdWkvVmlld01hbmFnZXJcIjtcbmltcG9ydCBQbGF0Zm9ybSBmcm9tIFwiLi4vLi4vLi4vZnJhbWV3b3JrL1BsYXRmb3JtXCI7XG5pbXBvcnQgeyBUb2FzdCB9IGZyb20gXCIuLi8uLi8uLi9mcmFtZXdvcmsvcGx1Z2luX2Jvb3N0cy91aS9Ub2FzdE1hbmFnZXJcIjtcblxuXG5jb25zdCB7Y2NjbGFzcywgcHJvcGVydHl9ID0gY2MuX2RlY29yYXRvcjtcblxuQGNjY2xhc3NcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIExpbmVHYW1lIGV4dGVuZHMgY2MuQ29tcG9uZW50XG57XG4gICAgX2xldmVsRGF0YTphbnk7XG4gICAgX3RpbGVMaXN0OmFueTtcblxuICAgIF9pc0dhbWVPdmVyOmJvb2xlYW4gPSBmYWxzZTsgXG4gICAgX21vdmVDb3VudDpudW1iZXIgPSAwO1xuXG4gICAgX3BsYXlUaW1lID0gMDtcbiAgICBfY29sQ291bnQgPSA2O1xuICAgIF9yb3dDb3VudCA9IDc7XG5cbiAgICBfcGlja2VkVGlsZTpIZXhvblRpbGUgPSBudWxsO1xuICAgIFxuICAgIHN0YXRpYyBpbnN0YW5jZTpMaW5lR2FtZSA9IG51bGw7XG5cbiAgICBAcHJvcGVydHkoY2MuTm9kZSlcbiAgICB0aWxlTGF5ZXI6Y2MuTm9kZSA9IG51bGw7XG5cbiAgICBAcHJvcGVydHkoY2MuTGFiZWwpXG4gICAgbGV2ZWxMYWJlbDpjYy5MYWJlbCA9IG51bGw7XG5cbiAgICBAcHJvcGVydHkoY2MuTGFiZWwpXG4gICAgdGltZUxhYmVsOmNjLkxhYmVsID0gbnVsbDtcblxuICAgIEBwcm9wZXJ0eShjYy5MYWJlbClcbiAgICBzdGVwTGFiZWw6Y2MuTGFiZWwgPSBudWxsO1xuXG4gICAgQHByb3BlcnR5KGNjLk5vZGUpXG4gICAgZm9jdXNOb2RlOmNjLk5vZGUgPSBudWxsO1xuXG4gICAgX2ZpZ3VyZUxpc3QgPSBbXVxuXG4gICAgcGVyZmVjdE1vdmVDb3VudCA9IDA7XG5cbiAgICBfZ3JpZE1hbmFnZXI6R3JpZE1hbmFnZXI7XG5cbiAgICBnZXRfaXNHYW1lT3ZlcigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2lzR2FtZU92ZXJcbiAgICB9XG4gICAgZ2V0X21pbkNvbCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2xldmVsRGF0YS5taW5jb2xcbiAgICB9XG4gICAgZ2V0X21vdmVDb3VudCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX21vdmVDb3VudFxuICAgIH1cblxuICAgIGxvYWRMZXZlbCh0KSB7XG4gICAgICAgIC8vdGVzdCA6XG4gICAgICAgIHQgPSBNYXRoLm1pbih0LCBSLmxldmVsSnNvbi5qc29uLmxldmVscy5sZW5ndGgtMSlcbiAgICAgICAgdGhpcy5fbGV2ZWxEYXRhID0gUi5sZXZlbEpzb24uanNvbi5sZXZlbHNbdF07XG4gICAgICAgIHRoaXMubGV2ZWxMYWJlbC5zdHJpbmcgPSB0ICtcIlwiXG4gICAgICAgIGlmKHQgPT0gMSlcbiAgICAgICAge1xuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZU9uY2UodGhpcy5vcGVuR3VpZGUsMC4xKVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgb3Blbkd1aWRlKClcbiAgICB7XG4gICAgICAgIFZpZXdNYW5hZ2VyLmluc3RhbmNlLnNob3coXCJHYW1lL09wZW5HdWlkZVwiKVxuICAgIH1cblxuICAgIG9uTG9hZCgpIHtcbiAgICAgICAgdmFyIHQgPSB0aGlzO1xuICAgICAgICBMaW5lR2FtZS5pbnN0YW5jZSA9IHRoaXM7XG4gICAgICAgIHRoaXMubG9hZExldmVsKFVzZXJJbmZvLmN1cnJlbnRMZXZlbClcbiAgICAgICAgLy90aGlzLmxvYWRMZXZlbCg3NSlcbiAgICAgICAgdGhpcy5oaWRlRm9jdXMoKTtcbiAgICAgICAgdGhpcy5fdGlsZUxpc3QgPSBbXVxuICAgICAgICB0aGlzLl9yb3dDb3VudCA9IHRoaXMuX2xldmVsRGF0YS5zaXplXG4gICAgICAgIHRoaXMuX2NvbENvdW50IC09IDE7XG5cbiAgICAgICAgZm9yICh2YXIgZSA9IDAsIG4gPSB0aGlzLl9yb3dDb3VudDsgbiA+IGU7KSB7XG4gICAgICAgICAgICB2YXIgaSwgcyA9IGUrKyBcbiAgICAgICAgICAgIGxldCB0bXBsaXN0ID0gW107XG4gICAgICAgICAgICBpID0gcyA8PSB0aGlzLl9yb3dDb3VudCAvIDIgPyB0aGlzLl9sZXZlbERhdGEubWluY29sICsgcyA6IHRoaXMuX2xldmVsRGF0YS5taW5jb2wgLSAxICsgdGhpcy5fcm93Q291bnQgLSBzO1xuICAgICAgICAgICAgZm9yICh2YXIgciA9IDA7IGkgPiByOykge1xuICAgICAgICAgICAgICAgIHZhciBvID0gciArK1xuICAgICAgICAgICAgICAgIGxldCBub2RlID0gY2MuaW5zdGFudGlhdGUoUi5UaWxlUHJlZmFiKVxuICAgICAgICAgICAgICAgIGxldCB0aWxlID0gbm9kZS5nZXRDb21wb25lbnQoSGV4b25UaWxlKTtcbiAgICAgICAgICAgICAgICBub2RlLnBhcmVudCA9IHRoaXMudGlsZUxheWVyO1xuICAgICAgICAgICAgICAgIG5vZGUuekluZGV4ID0gdGhpcy5fcm93Q291bnQgLSBzO1xuICAgICAgICAgICAgICAgIC8vIHRoaXMuX3RpbGVMYXllci5hZGRDaGlsZCgobmV3IGcpLmFkZChub2RlKSlcbiAgICAgICAgICAgICAgICB0aWxlLnNldF9yb3cocylcbiAgICAgICAgICAgICAgICB0aWxlLnNldF9jb2wobylcblxuICAgICAgICAgICAgICAgIC8vLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLy9cbiAgICAgICAgICAgICAgICBsZXQgc2hhZG93Tm9kZSA9IGNjLmluc3RhbnRpYXRlKFIuVGlsZVNoYWRvdylcbiAgICAgICAgICAgICAgICBsZXQgc2hhZG93ID0gc2hhZG93Tm9kZS5nZXRDb21wb25lbnQoSGV4b25UaWxlKTtcbiAgICAgICAgICAgICAgICBzaGFkb3cuc2V0X3JvdyhzKVxuICAgICAgICAgICAgICAgIHNoYWRvdy5zZXRfY29sKG8pXG4gICAgICAgICAgICAgICAgc2hhZG93Tm9kZS55IC09IDM7XG4gICAgICAgICAgICAgICAgc2hhZG93Tm9kZS5wYXJlbnQgPSB0aGlzLnRpbGVMYXllcjtcbiAgICAgICAgICAgICAgICBzaGFkb3dOb2RlLnpJbmRleCA9IDA7XG4gICAgICAgICAgICAgICAgLy8tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0vL1xuXG5cbiAgICAgICAgICAgICAgICB0bXBsaXN0LnB1c2godGlsZSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuX3RpbGVMaXN0LnB1c2godG1wbGlzdClcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgYXBwR2FtZS5nYW1lU2VydmVyUm9vbS5lbWl0KGNvbnN0cy5DTElFTlRfR0FNRV9TVEFSVCx7fSk7XG4gICAgICAgICAgICBhcHBHYW1lLmJhbm5lci5wbGF5QmFubmVyKDIpO1xuXG4gICAgICAgICAgICAvL+aPkuWxj+W5v+WRilxuICAgICAgICAgICAgdGhpcy5zY2hlZHVsZSgoKSA9PiB7XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLmj5LlsY/lub/lkYo9PVwiKTtcbiAgICAgICAgICAgICAgICBpZihhcHBHYW1lLmludGVyc3RpdGlhbEFkKXtcbiAgICAgICAgICAgICAgICAgICAgYXBwR2FtZS5pbnRlcnN0aXRpYWxBZC5wbGF5QWQoXCLmj5LlsY9cIik7XG4gICAgICAgICAgICAgICAgfSAgIFxuICAgICAgICAgICAgfSwgNjApOyBcbiAgICAgICAgICAgIC8v56ev5pyo5bm/5ZGKXG4gICAgICAgICAgICB0aGlzLnNjaGVkdWxlKCgpPT57XG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLnp6/mnKjlub/lkYo9PVwiKTtcbiAgICAgICAgICAgICAgICBpZihhcHBHYW1lLnFxYmxvY2thZCl7XG4gICAgICAgICAgICAgICAgICAgIGFwcEdhbWUucXFibG9ja2FkLnBsYXlCbG9ja2FkKHRydWUpO1xuICAgICAgICAgICAgICAgIH0gXG4gICAgICAgICAgICB9LDMwKTtcbiAgICAgICAgfVxuICAgICAgICBcbiAgICAgICAgdGhpcy5fZ3JpZE1hbmFnZXIgPSB0aGlzLnRpbGVMYXllci5hZGRDb21wb25lbnQoR3JpZE1hbmFnZXIpXG4gICAgICAgIHRoaXMuX2dyaWRNYW5hZ2VyLmluaXQodGhpcy5fbGV2ZWxEYXRhLm1pbmNvbCk7XG4gICAgICAgIC8vIHRoaXMuX2xpbmVMYXllciA9IChuZXcgZykuYWRkKHRoaXMuX2dyaWRNYW5hZ2VyKSxcbiAgICAgICAgLy8gdGhpcy5vd25lci5hZGRDaGlsZCh0aGlzLl9saW5lTGF5ZXIpLFxuICAgICAgICB0aGlzLnNldEZpZ3VyZSgpXG5cbiAgICAgICAgdGhpcy5hZGRDb21wb25lbnQoSW5wdXRTeXN0ZW0pO1xuXG5cbiAgICAgICAgLy8gdGhpcy5fdWlMYXllciA9IG5ldyBnLFxuICAgICAgICAvLyB0aGlzLl91aU1hbmFnZXIgPSBuZXcgbmkodGhpcy5fc3RhZ2VJbmRleCArIDEpLFxuICAgICAgICAvLyB0aGlzLm93bmVyLmFkZENoaWxkKHRoaXMuX3VpTGF5ZXIuYWRkKHRoaXMuX3VpTWFuYWdlcikpXG5cbiAgICAgICAgVXNlckluZm8udGltZVBhc3NlZCA9IDA7XG4gICAgICAgIFVzZXJJbmZvLnN0ZXBVc2VkID0gMDtcbiAgICAgICAgdGhpcy5zY2hlZHVsZShfPT57XG4gICAgICAgICAgICBVc2VySW5mby50aW1lUGFzc2VkICs9IDFcbiAgICAgICAgICAgIHRoaXMudGltZUxhYmVsLnN0cmluZyA9IFVzZXJJbmZvLnRpbWVQYXNzZWQgKyBcInNcIjtcbiAgICAgICAgICAgIHRoaXMuc3RlcExhYmVsLnN0cmluZyA9IFVzZXJJbmZvLnN0ZXBVc2VkICtcIuatpVwiXG4gICAgICAgIH0sMSlcbiAgICB9XG5cblxuICAgIG9uVG91Y2hCZWdhbihlKVxuICAgIHtcbiAgICAgICAgbGV0IHQgPSB0aGlzO1xuICAgICAgICBpZiAoIXQuX2lzR2FtZU92ZXIpIHtcbiAgICAgICAgICAgIC8vIHZhciBuID0gdC50b3VjaFh0b1NjcmVlblgoZS52aWV3WClcbiAgICAgICAgICAgIC8vIHZhciBlID0gdC50b3VjaFl0b1NjcmVlblkoZS52aWV3WSlcbiAgICAgICAgICAgIC8vIHZhciBpID0gdC5maW5kVGlsZUJ5UG9zKG4sIGUpXG4gICAgICAgICAgICB2YXIgcCA9IGUuY3VycmVudFRvdWNoLmdldExvY2F0aW9uKCk7XG4gICAgICAgICAgICBwID0gdGhpcy5ub2RlLmNvbnZlcnRUb05vZGVTcGFjZUFSKHApO1xuICAgICAgICAgICAgdmFyIGk6SGV4b25UaWxlID0gdC5maW5kVGlsZUJ5UG9zKHAueCxwLnkpO1xuICAgICAgICAgICAgXG4gICAgICAgICAgICBpZiAobnVsbCAhPSBpICYmIDAgIT0gaS5nZXRfYW5pbWFsKCkpIHtcbiAgICAgICAgICAgICAgICBjYy5hdWRpb0VuZ2luZS5wbGF5RWZmZWN0KFIuYXVkaW9fZG93bixmYWxzZSk7XG4gICAgICAgICAgICAgICAgLy8gam4ucGxheVNvdW5kKDApXG4gICAgICAgICAgICAgICAgdC5fcGlja2VkVGlsZSA9IGlcbiAgICAgICAgICAgICAgICB0LnJlbW92ZUdyaWRGcm9tVGlsZSh0Ll9waWNrZWRUaWxlKVxuICAgICAgICAgICAgICAgIHQuX3BpY2tlZFRpbGUuY29ubmVjdChudWxsKVxuICAgICAgICAgICAgICAgIGlmKG51bGwgIT0gdC5fcGlja2VkVGlsZS50YXJnZXRUaWxlKVxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgdC5yZW1vdmVHcmlkRnJvbVRpbGUodC5fcGlja2VkVGlsZS50YXJnZXRUaWxlKVxuICAgICAgICAgICAgICAgICAgICB0Ll9waWNrZWRUaWxlLnRhcmdldFRpbGUuY29ubmVjdChudWxsKVxuICAgICAgICAgICAgICAgICAgICB0Ll9waWNrZWRUaWxlLnRhcmdldFRpbGUuc2V0X2lzQ29ubmVjdGluZyhmYWxzZSlcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdC5fcGlja2VkVGlsZS5zZXRfaXNDb25uZWN0aW5nKCEwKVxuICAgICAgICAgICAgICAgIGkgPSB0Ll9waWNrZWRUaWxlLmdldEhlYWQoKTsgXG4gICAgICAgICAgICAgICAgZm9yICggO251bGwgIT0gaTspIGkuc2V0X2lzQ29ubmVjdGluZyghMCksXG4gICAgICAgICAgICAgICAgaSA9IGkuY29ubmVjdGVkVGlsZTtcbiAgICAgICAgICAgICAgICAvLyB0Ll91aU1hbmFnZXIuc2hvd0ZvY3VzKHQuX3BpY2tlZFRpbGUuZ2V0X2FuaW1hbCgpKSxcbiAgICAgICAgICAgICAgICB0aGlzLnNob3dGb2N1cyh0Ll9waWNrZWRUaWxlLmdldF9hbmltYWwoKSk7XG4gICAgICAgICAgICAgICAgLy8gdC5fdWlNYW5hZ2VyLm1vdmVGb2N1cyhuLCBlKVxuICAgICAgICAgICAgICAgIHRoaXMubW92ZUZvY3VzKHApO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5jaGVja0NvbXBlbGV0ZSgpXG4gICAgICAgICAgICAvLyAxID09ICA/IDEgPT0gdC5jaGVja0ZpbGxBbGwoKSA/IHQuX3VpTWFuYWdlci5oaWRlRmlsbEFsbFBvcHVwKCkgOiB0Ll91aU1hbmFnZXIuc2hvd0ZpbGxBbGxQb3B1cCgpIDogdC5fdWlNYW5hZ2VyLmhpZGVGaWxsQWxsUG9wdXAoKVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgY2hlY2tDb21wZWxldGUoKVxuICAgIHtcbiAgICAgICAgaWYoIHRoaXMuY2hlY2tDb25uZWN0ZWRBbGwoKSlcbiAgICAgICAge1xuICAgICAgICAgICAgaWYodGhpcy5jaGVja0ZpbGxBbGwoKSlcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAvLyB0Ll91aU1hbmFnZXIuaGlkZUZpbGxBbGxQb3B1cCgpXG4gICAgICAgICAgICB9ZWxzZXtcbiAgICAgICAgICAgICAgICAvLyAgdC5fdWlNYW5hZ2VyLnNob3dGaWxsQWxsUG9wdXAoKVxuICAgICAgICAgICAgICAgIFxuICAgICAgICAgICAgfVxuICAgICAgICB9ZWxzZXtcbiAgICAgICAgICAgIC8vIF91aU1hbmFnZXIuaGlkZUZpbGxBbGxQb3B1cCgpXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBpc1RpbGVDb25uZWN0ZWQodCwgZSkge1xuICAgICAgICB2YXIgbiwgaSA9IHQuX3JvdztcbiAgICAgICAgbiA9IHQuX2NvbCArIChpIDw9IHRoaXMuX3Jvd0NvdW50IC8gMiA/IDAgOiB0Ll9yb3cgLSAodGhpcy5fcm93Q291bnQgLyAyIHwgMCkpO1xuICAgICAgICB2YXIgcywgYSA9IGUuX3JvdztcbiAgICAgICAgcmV0dXJuIHMgPSBlLl9jb2wgKyAoYSA8PSB0aGlzLl9yb3dDb3VudCAvIDIgPyAwIDogZS5fcm93IC0gKHRoaXMuX3Jvd0NvdW50IC8gMiB8IDApKSxcbiAgICAgICAgaSAtIDEgPT0gYSAmJiBuIC0gMSA9PSBzIHx8IGkgLSAxID09IGEgJiYgbiA9PSBzIHx8IGkgPT0gYSAmJiBuIC0gMSA9PSBzIHx8IGkgPT0gYSAmJiBuICsgMSA9PSBzIHx8IGkgKyAxID09IGEgJiYgbiA9PSBzIHx8IGkgKyAxID09IGEgJiYgbiArIDEgPT0gcyA/IHRydWU6ZmFsc2VcbiAgICB9XG5cblxuICAgIG9uVG91Y2hNb3ZlZChlKVxuICAgIHtcbiAgICAgICAgbGV0IHQgPSB0aGlzO1xuICAgICAgICBpZiAoIXQuX2lzR2FtZU92ZXIpIHtcbiAgICAgICAgICAgIHZhciBwID0gZS5jdXJyZW50VG91Y2guZ2V0TG9jYXRpb24oKTtcbiAgICAgICAgICAgIHAgPSB0aGlzLm5vZGUuY29udmVydFRvTm9kZVNwYWNlQVIocCk7XG4gICAgICAgICAgICB2YXIgaTpIZXhvblRpbGUgPSB0LmZpbmRUaWxlQnlQb3MocC54LHAueSk7XG5cbiAgICAgICAgICAgIGlmIChudWxsICE9IHQuX3BpY2tlZFRpbGUgJiYgbnVsbCAhPSBpKSBpZiAodC5pc1RpbGVDb25uZWN0ZWQodC5fcGlja2VkVGlsZSwgaSkpIHtcbiAgICAgICAgICAgICAgICBpZiAoMCA9PSBpLmdldF9hbmltYWwoKSkobnVsbCA9PSB0Ll9waWNrZWRUaWxlLnRhcmdldFRpbGUgfHwgbnVsbCA9PSB0Ll9waWNrZWRUaWxlLnJldmVyc2VDb25uZWN0ZWRUaWxlKSAmJiAodC5fZ3JpZE1hbmFnZXIuc2V0U3RhdGUodC5fcGlja2VkVGlsZS5nZXRfcm93KCksIHQuX3BpY2tlZFRpbGUuZ2V0X2NvbCgpLCBpLmdldF9yb3coKSwgaS5nZXRfY29sKCksICEwKSwgdC5fcGlja2VkVGlsZS5jb25uZWN0KGkpLCB0Ll9waWNrZWRUaWxlID0gaSwgdC5fcGlja2VkVGlsZS5zZXRfaXNDb25uZWN0aW5nKCEwKSk7XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoaS5nZXRfYW5pbWFsKCkgPT0gdC5fcGlja2VkVGlsZS5nZXRfYW5pbWFsKCkpIGlmIChmYWxzZSA9PSBpLmlzQ2hhbmdhYmxlICYmICEgaS5lcXVhbHModC5fcGlja2VkVGlsZS5nZXRIZWFkKCkpKSBudWxsID09IGkucmV2ZXJzZUNvbm5lY3RlZFRpbGUgJiYgKHQuX2dyaWRNYW5hZ2VyLnNldFN0YXRlKHQuX3BpY2tlZFRpbGUuZ2V0X3JvdygpLCB0Ll9waWNrZWRUaWxlLmdldF9jb2woKSwgaS5nZXRfcm93KCksIGkuZ2V0X2NvbCgpLCAhMCksIHQuX3BpY2tlZFRpbGUuY29ubmVjdChpKSwgdC5fcGlja2VkVGlsZSA9IGkpO1xuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHQuX3BpY2tlZFRpbGUgPSBpLCBpID0gdC5fcGlja2VkVGlsZTsgbnVsbCAhPSBpICYmIG51bGwgIT0gaS5jb25uZWN0ZWRUaWxlOykgdC5fZ3JpZE1hbmFnZXIuc2V0U3RhdGUoaS5nZXRfcm93KCksIGkuZ2V0X2NvbCgpLCBpLmNvbm5lY3RlZFRpbGUuZ2V0X3JvdygpLCBpLmNvbm5lY3RlZFRpbGUuZ2V0X2NvbCgpLCAhMSksXG4gICAgICAgICAgICAgICAgICAgIGkgPSBpLmNvbm5lY3RlZFRpbGU7XG4gICAgICAgICAgICAgICAgICAgIHQuX3BpY2tlZFRpbGUuY29ubmVjdChudWxsKVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAoaS5nZXRfYW5pbWFsKCkgPT0gdC5fcGlja2VkVGlsZS5nZXRfYW5pbWFsKCkgJiYgIWkuZXF1YWxzKHQuX3BpY2tlZFRpbGUpICYmIG51bGwgIT0gaS5jb25uZWN0ZWRUaWxlKSB7XG4gICAgICAgICAgICAgICAgZm9yICh0Ll9waWNrZWRUaWxlID0gaSwgaSA9IHQuX3BpY2tlZFRpbGU7IG51bGwgIT0gaSAmJiBudWxsICE9IGkuY29ubmVjdGVkVGlsZTspIHQuX2dyaWRNYW5hZ2VyLnNldFN0YXRlKGkuZ2V0X3JvdygpLCBpLmdldF9jb2woKSwgaS5jb25uZWN0ZWRUaWxlLmdldF9yb3coKSwgaS5jb25uZWN0ZWRUaWxlLmdldF9jb2woKSwgITEpLFxuICAgICAgICAgICAgICAgIGkgPSBpLmNvbm5lY3RlZFRpbGU7XG4gICAgICAgICAgICAgICAgdC5fcGlja2VkVGlsZS5jb25uZWN0KG51bGwpXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0aGlzLm1vdmVGb2N1cyhwKVxuICAgICAgICAgICAgLy8gdC5fdWlNYW5hZ2VyLm1vdmVGb2N1cyhuLCBlKSxcbiAgICAgICAgICAgIC8vdGhpcy5jaGVja0NvbXBlbGV0ZSgpXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBvblRvdWNoRW5kZWQoKVxuICAgIHtcbiAgICAgICAgbGV0IHQgPSB0aGlzO1xuICAgICAgICB2YXIgZSA9IGZhbHNlO1xuICAgICAgICBpZiAoIXQuX2lzR2FtZU92ZXIpIHtcbiAgICAgICAgICAgIGlmIChudWxsICE9IHQuX3BpY2tlZFRpbGUpIHtcbiAgICAgICAgICAgICAgICB2YXIgbiA9IHQuX3BpY2tlZFRpbGUuZ2V0SGVhZCgpO1xuICAgICAgICAgICAgICAgIGZvciAobnVsbCAhPSB0Ll9waWNrZWRUaWxlLmFuaW1hbFNwcml0ZSAmJiBudWxsICE9IG4gJiYgbnVsbCAhPSBuLmFuaW1hbFNwcml0ZSAmJiAoZSA9IHRydWUsIHQuX3BpY2tlZFRpbGUuYW5pbWFsU3ByaXRlLmNvbm5lY3RlZCgpLCBuLmFuaW1hbFNwcml0ZS5jb25uZWN0ZWQoKSk7IG51bGwgIT0gbjspIG4uc2V0X2lzQ29ubmVjdGluZyhmYWxzZSksXG4gICAgICAgICAgICAgICAgbiA9IG4uY29ubmVjdGVkVGlsZTtcbiAgICAgICAgICAgICAgICB0Ll9tb3ZlQ291bnQrK1xuICAgICAgICAgICAgICAgIFVzZXJJbmZvLnN0ZXBVc2VkICsrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdC5fcGlja2VkVGlsZSA9IG51bGxcbiAgICAgICAgICAgIC8vIHQuX3VpTWFuYWdlci5oaWRlRm9jdXMoKSxcbiAgICAgICAgICAgIHRoaXMuaGlkZUZvY3VzKCk7XG4gICAgICAgICAgICBpZiggdC5jaGVja0Nvbm5lY3RlZEFsbCgpKVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGlmKHQuY2hlY2tGaWxsQWxsKCkpXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAvLyB0Ll91aU1hbmFnZXIuaGlkZUZpbGxBbGxQb3B1cCgpXG4gICAgICAgICAgICAgICAgICAgIHQuX2lzR2FtZU92ZXIgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICAvLyB0Ll91aU1hbmFnZXIuc2hvd0NsZWFyUG9wdXAodC5fbW92ZUNvdW50LCB0LnBlcmZlY3RNb3ZlQ291bnQpXG4gICAgICAgICAgICAgICAgICAgIHQuZGFuY2VBbGwoKTtcblxuICAgICAgICAgICAgICAgIH1lbHNle1xuICAgICAgICAgICAgICAgICAgICAvLyAgdC5fdWlNYW5hZ2VyLnNob3dGaWxsQWxsUG9wdXAoKVxuICAgICAgICAgICAgICAgICAgICBUb2FzdC5tYWtlKFwi5b+F6aG75aGr5ruh5omA5pyJ5qC85a2QXCIpXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfWVsc2V7XG4gICAgICAgICAgICAgICAgLy8gX3VpTWFuYWdlci5oaWRlRmlsbEFsbFBvcHVwKClcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmKGU9PSB0cnVlICYmICF0Ll9pc0dhbWVPdmVyKVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIC8vIGpuLnBsYXlTb3VuZCgxKVxuICAgICAgICAgICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlFZmZlY3QoUi5hdWRpb19saW5rLGZhbHNlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIDEgPT0gZSAmJiAwID09IHQuX2lzR2FtZU92ZXIgJiYgam4ucGxheVNvdW5kKDEpXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBzaG93Rm9jdXMoYW5pbWFsKVxuICAgIHtcbiAgICAgICAgY29uc29sZS5sb2coYW5pbWFsKTtcbiAgICAgICAgdGhpcy5mb2N1c05vZGUuYWN0aXZlID0gdHJ1ZVxuICAgICAgICB0aGlzLmZvY3VzTm9kZS56SW5kZXggPSAxMDA7XG4gICAgICAgIHRoaXMuZm9jdXNOb2RlLmNvbG9yID0gUi5jb2xvcnNbYW5pbWFsXS5jbG9uZSgpO1xuICAgIH1cblxuICAgIG1vdmVGb2N1cyhwKVxuICAgIHtcbiAgICAgICAgdGhpcy5mb2N1c05vZGUucG9zaXRpb24gPSBwO1xuICAgIH1cblxuICAgIGhpZGVGb2N1cygpXG4gICAge1xuICAgICAgICB0aGlzLmZvY3VzTm9kZS5hY3RpdmUgPSBmYWxzZVxuICAgIH1cblxuICAgIGRhbmNlQWxsKCkge1xuICAgICAgICAvLyBqbi5wbGF5U291bmQoMyk7XG4gICAgICAgIGNjLmF1ZGlvRW5naW5lLnBsYXlFZmZlY3QoUi5hdWRpb193aW4sZmFsc2UpO1xuICAgICAgICBmb3IgKHZhciB0ID0gMCxlID0gdGhpcy5fdGlsZUxpc3Q7IHQgPCBlLmxlbmd0aDspIHtcbiAgICAgICAgICAgIHZhciBuID0gZVt0XTsgKyt0O1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBuLmxlbmd0aDspIHtcbiAgICAgICAgICAgICAgICB2YXIgcyA9IG5baV07ICsraSxcbiAgICAgICAgICAgICAgICBudWxsICE9IHMuYW5pbWFsU3ByaXRlICYmIHMuYW5pbWFsU3ByaXRlLmxvb3BKdW1wKDEpXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgIFxuICAgICAgICB0aGlzLnNjaGVkdWxlT25jZSh0aGlzLnNob3dXaW5EaWFsb2csMSlcbiAgICB9XG5cbiAgICBzaG93V2luRGlhbG9nKClcbiAgICB7XG4gICAgICAgIFZpZXdNYW5hZ2VyLmluc3RhbmNlLnNob3coXCJHYW1lL1dpbkRpYWxvZ1wiKVxuICAgIH1cblxuICAgIGNsaWNrX3BhdXNlKClcbiAgICB7XG4gICAgICAgIGh0dHBVdGlscy5odHRwUG9zdChjb25zdHMuSFRUUF9SRUNPUkRfU0VSVkVSLHt0aXRsZTon5ri45oiP55WM6Z2iJyxjb250ZW50Oifngrnlh7vov5Tlm54nfSxmdW5jdGlvbigpe30pO1xuICAgICAgICBWaWV3TWFuYWdlci5pbnN0YW5jZS5zaG93KFwiR2FtZS9QYXVzZURpYWxvZ1wiKVxuICAgIH1cblxuICAgIGNsaWNrX3NoYXJlKClcbiAgICB7XG4gICAgICAgIFBsYXRmb3JtLnNoYXJlKCk7XG4gICAgfVxuXG4gICAgc2V0RmlndXJlKCkge1xuICAgICAgICAvLyB0aGlzLl9maWd1cmVMYXllciA9IG5ldyBnLFxuICAgICAgICB0aGlzLl9maWd1cmVMaXN0ID0gW11cbiAgICAgICAgLy8gdGhpcy5vd25lci5hZGRDaGlsZCh0aGlzLl9maWd1cmVMYXllcik7XG4gICAgICAgIGZvciAodmFyIHQgPSBbXSwgZSA9IDA7IDEwID4gZTspIGUrKywgdC5wdXNoKG51bGwpO1xuXG4gICAgICAgIGZvciAodmFyIGUgPSAwLCBuID0gdGhpcy5fbGV2ZWxEYXRhLmZpZ3VyZTsgZSA8IG4ubGVuZ3RoOykge1xuICAgICAgICAgICAgdmFyIGkgPSBuW2VdO1xuICAgICAgICAgICAgKytlO1xuICAgICAgICAgICAgdmFyIHM6SGV4b25UaWxlID0gdGhpcy5fdGlsZUxpc3RbaVswXV1baVsxXV1cbiAgICAgICAgICAgIHZhciBhID0gcy5nZXRfYm9yZGVyUG9zaXRpb24oKTtcblxuICAgICAgICAgICAgLy8gcy5hbmltYWxTcHJpdGUgPSBuZXcgJG4oaVsyXSwgYS5nZXRfeCgpLCBhLmdldF95KCkpXG4gICAgICAgICAgICAvLyB0aGlzLm93bmVyLmFkZENoaWxkKChuZXcgZykuYWRkKHMuYW5pbWFsU3ByaXRlKSlcbiAgICAgICAgICAgIGxldCB0eXBlID0gaVsyXTtcbiAgICAgICAgICAgIGxldCBub2RlID0gY2MuaW5zdGFudGlhdGUoUi5hbmltYWxQcmVmYWJzW3R5cGUtMV0pXG4gICAgICAgICAgICBzLmFuaW1hbFNwcml0ZSA9IG5vZGUuZ2V0Q29tcG9uZW50KEFuaW1hbCk7XG4gICAgICAgICAgICAvLyBzLmFuaW1hbFNwcml0ZS50eXBlID0gdHlwZTtcbiAgICAgICAgICAgIG5vZGUuc2V0UG9zaXRpb24oYS54LGEueSk7XG4gICAgICAgICAgICBub2RlLnBhcmVudCA9IHRoaXMudGlsZUxheWVyO1xuICAgICAgICAgICAgbm9kZS56SW5kZXggPSAxMTA7XG5cbiAgICAgICAgICAgIC8vIGFuaW1hbC50eXBlID0gdHlwZTsgXG4gICAgICAgICAgICAvLyBhbmltYWwudHggPSBhLnggOyBcblxuICAgICAgICAgICAgcy5zZXRfYW5pbWFsKGlbMl0pXG4gICAgICAgICAgICBzLmlzQ2hhbmdhYmxlID0gZmFsc2UgXG4gICAgICAgICAgICB0aGlzLl9maWd1cmVMaXN0LnB1c2gocylcbiAgICAgICAgICAgIG51bGwgPT0gdFtpWzJdXSA/IHRbaVsyXV0gPSBzIDogKHMudGFyZ2V0VGlsZSA9IHRbaVsyXV0sIHRbaVsyXV0udGFyZ2V0VGlsZSA9IHMpXG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5wZXJmZWN0TW92ZUNvdW50ID0gdGhpcy5fZmlndXJlTGlzdC5sZW5ndGggLyAyIHwgMFxuICAgIH1cblxuICAgIGZpbmRUaWxlQnlQb3MoeCwgeSkge1xuICAgICAgICB2YXIgbiA9IG51bGxcbiAgICAgICAgdmFyIGkgPSAxZTZcbiAgICAgICAgdmFyIHMgPSBjYy52Mih4LCB5KVxuICAgICAgICB2YXIgciA9IHRoaXMuX3RpbGVMaXN0XG4gICAgICAgIGZvciAodmFyIGEgPSAwOyBhIDwgci5sZW5ndGg7KythKSB7XG4gICAgICAgICAgICB2YXIgbyA9IHJbYV07XG4gICAgICAgICAgICBmb3IgKHZhciBfID0gMDsgXyA8IG8ubGVuZ3RoOysrXykge1xuICAgICAgICAgICAgICAgIHZhciBsID0gb1tfXVxuICAgICAgICAgICAgICAgIHZhciB0cCA9IG9bX10ubm9kZS5wb3NpdGlvbjtcbiAgICAgICAgICAgICAgICB2YXIgaCA9IHMuc3ViKHRwKS5tYWcoKVxuICAgICAgICAgICAgICAgIGlmIChoIDwgNTAgJiYgaCA8IGkgKXtcbiAgICAgICAgICAgICAgICAgICAgaSA9IGg7IFxuICAgICAgICAgICAgICAgICAgICBuID0gbDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gNDAgPiBoICYmIGkgPiBoICYmIChpID0gaCwgbiA9IGwpXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG5cbiAgICB9XG4gICAgcmVtb3ZlR3JpZEZyb21UaWxlKHQpIHtcbiAgICAgICAgZm9yICg7IG51bGwgIT0gdCAmJiBudWxsICE9IHQuY29ubmVjdGVkVGlsZTspIHRoaXMuX2dyaWRNYW5hZ2VyLnNldFN0YXRlKHQuZ2V0X3JvdygpLCB0LmdldF9jb2woKSwgdC5jb25uZWN0ZWRUaWxlLmdldF9yb3coKSwgdC5jb25uZWN0ZWRUaWxlLmdldF9jb2woKSwgITEpLCB0ID0gdC5jb25uZWN0ZWRUaWxlXG4gICAgfVxuICAgIGNoZWNrRmlsbEFsbCgpIHtcbiAgICAgICAgZm9yICh2YXIgdCA9IDAsIGUgPSB0aGlzLl90aWxlTGlzdDsgdCA8IGUubGVuZ3RoOykge1xuICAgICAgICAgICAgdmFyIG4gPSBlW3RdO1xuICAgICAgICAgICAgKyt0O1xuICAgICAgICAgICAgZm9yICh2YXIgaSA9IDA7IGkgPCBuLmxlbmd0aDspIHtcbiAgICAgICAgICAgICAgICB2YXIgcyA9IG5baV07XG4gICAgICAgICAgICAgICAgaWYgKCsraSwgMCA9PSBzLmdldF9hbmltYWwoKSkgcmV0dXJuICExXG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuICEwXG4gICAgfVxuICAgIGNoZWNrQ29ubmVjdGVkQWxsKCkge1xuICAgICAgICBmb3IgKHZhciB0ID0gMCwgZSA9IHRoaXMuX3RpbGVMaXN0OyB0IDwgZS5sZW5ndGg7KSB7XG4gICAgICAgICAgICB2YXIgbiA9IGVbdF07XG4gICAgICAgICAgICArK3Q7XG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IG4ubGVuZ3RoOykge1xuICAgICAgICAgICAgICAgIHZhciBzID0gbltpXTtcbiAgICAgICAgICAgICAgICBpZiAoKytpLCBudWxsICE9IHMudGFyZ2V0VGlsZSkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgYSA9IHMuZ2V0SGVhZCgpLFxuICAgICAgICAgICAgICAgICAgICAgICAgciA9IHMuZ2V0VGFpbCgpO1xuICAgICAgICAgICAgICAgICAgICBpZiAoMCA9PSBzLnRhcmdldFRpbGUuZXF1YWxzKGEpICYmIDAgPT0gcy50YXJnZXRUaWxlLmVxdWFscyhyKSkgcmV0dXJuICExXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiAhMFxuICAgIH1cbn0iXX0=
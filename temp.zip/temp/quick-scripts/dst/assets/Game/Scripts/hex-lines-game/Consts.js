
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Game/Scripts/hex-lines-game/Consts.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'ccf28Nj1JdBbY/NtYiwJtcW', 'Consts');
// Game/Scripts/hex-lines-game/Consts.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Consts = /** @class */ (function () {
    function Consts() {
    }
    Consts.CenterY = 0;
    Consts.CenterX = 0;
    Consts.ColSize = 84;
    Consts.RowSize = 61;
    Consts.StagePageCount = 3;
    Consts.FreeSkinId = 5;
    return Consts;
}());
exports.default = Consts;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcR2FtZVxcU2NyaXB0c1xcaGV4LWxpbmVzLWdhbWVcXENvbnN0cy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7SUFBQTtJQVFBLENBQUM7SUFOVSxjQUFPLEdBQUcsQ0FBQyxDQUFDO0lBQ1osY0FBTyxHQUFHLENBQUMsQ0FBQztJQUNaLGNBQU8sR0FBRyxFQUFFLENBQUM7SUFDYixjQUFPLEdBQUcsRUFBRSxDQUFDO0lBQ2IscUJBQWMsR0FBRyxDQUFDLENBQUM7SUFDbkIsaUJBQVUsR0FBRyxDQUFDLENBQUM7SUFDMUIsYUFBQztDQVJELEFBUUMsSUFBQTtrQkFSb0IsTUFBTSIsImZpbGUiOiIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImV4cG9ydCBkZWZhdWx0IGNsYXNzIENvbnN0c1xue1xuICAgIHN0YXRpYyBDZW50ZXJZID0gMDtcbiAgICBzdGF0aWMgQ2VudGVyWCA9IDA7XG4gICAgc3RhdGljIENvbFNpemUgPSA4NDtcbiAgICBzdGF0aWMgUm93U2l6ZSA9IDYxO1xuICAgIHN0YXRpYyBTdGFnZVBhZ2VDb3VudCA9IDM7XG4gICAgc3RhdGljIEZyZWVTa2luSWQgPSA1O1xufSJdfQ==
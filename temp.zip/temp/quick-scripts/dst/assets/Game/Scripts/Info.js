
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Game/Scripts/Info.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '894ddeHxZNOMqD6BW+YheZr', 'Info');
// Game/Scripts/Info.ts

Object.defineProperty(exports, "__esModule", { value: true });
exports.UserInfo = exports.ChoiceType = void 0;
var DataCenter_1 = require("../../framework/plugin_boosts/misc/DataCenter");
var Res_1 = require("./hex-lines-game/Res");
var ToastManager_1 = require("../../framework/plugin_boosts/ui/ToastManager");
var Device_1 = require("../../framework/plugin_boosts/gamesys/Device");
var ChoiceType;
(function (ChoiceType) {
    ChoiceType[ChoiceType["DailyGet"] = 0] = "DailyGet";
    ChoiceType[ChoiceType["Levelup"] = 1] = "Levelup";
    ChoiceType[ChoiceType["Get"] = 2] = "Get";
    ChoiceType[ChoiceType["Shop"] = 3] = "Shop";
    ChoiceType[ChoiceType["BannerAdRefresh"] = 4] = "BannerAdRefresh";
    ChoiceType[ChoiceType["HB"] = 5] = "HB";
})(ChoiceType = exports.ChoiceType || (exports.ChoiceType = {}));
var UserInfoClass = /** @class */ (function (_super) {
    __extends(UserInfoClass, _super);
    function UserInfoClass() {
        var _this = _super.call(this) || this;
        _this.choices = [];
        _this.version = "6";
        _this.level = 1;
        _this.selectedSkin = "2";
        _this.dailyGetTime = new Date(2018, 1, 1).getTime();
        _this.freedrawTime = _this.dailyGetTime;
        _this.luckyVideoWatchTime = _this.dailyGetTime;
        _this.shopFreeDiamondTime = _this.dailyGetTime;
        _this.diamond = 0;
        _this.sfx_enabled = true;
        _this.firstTimeReach = false;
        _this.luckyVideoWatchCount = 0;
        _this.timePassed = 0;
        _this.stepUsed = 0;
        _this.currentLevel = 1;
        _this.unlock(_this.selectedSkin);
        setTimeout(function () {
            _this.save();
        }, 60 * 1000);
        return _this;
        // onexit game =>save
    }
    // ret: 0:directly-get 1:share 2:video
    UserInfoClass.prototype.getChoice = function (slotId) {
        return this.choices[slotId] || 0;
    };
    UserInfoClass.prototype.init = function () {
    };
    UserInfoClass.prototype.onGetConfig = function (data) {
        if (data) {
            var record = data[0];
            if (record) {
                this.choices = JSON.parse(record[this.version]);
            }
        }
    };
    UserInfoClass.prototype.addDiamond = function (d, b) {
        if (b === void 0) { b = true; }
        if (typeof (d) == "number")
            this.diamond += d;
        else
            this.diamond += parseInt(d);
        if (b) {
            ToastManager_1.Toast.make("获得钻石 x" + d);
            Device_1.default.playEffect(Res_1.R.audio_get_diamond);
        }
        if (!this.firstTimeReach) {
            if (this.diamond >= 500) {
                ToastManager_1.Toast.make("哇可以买皮肤了，快去皮肤商店看看吧!", 2);
                this.firstTimeReach = true;
                exports.UserInfo.save();
            }
        }
    };
    UserInfoClass.prototype.isUnlock = function (skin_id) {
        var carUnlocked = localStorage.getItem("unlocked_" + skin_id);
        if (!carUnlocked) {
            return false;
        }
        else {
            return carUnlocked == "1";
        }
    };
    UserInfoClass.prototype.isAllUnlocked = function () {
        var c = 0;
        for (var i = 0; i < Res_1.R.skinConfig.json.length; i++) {
            var v = Res_1.R.skinConfig.json[i];
            if (exports.UserInfo.isUnlock(v.id)) {
                c++;
            }
        }
        return c == Res_1.R.skinConfig.json.length;
    };
    UserInfoClass.prototype.getSkinById = function (id) {
        var res = Res_1.R.skinConfig.json.filter(function (v) { return v.id == id; });
        return res[0];
    };
    UserInfoClass.prototype.unlock = function (skin_id) {
        localStorage.setItem("unlocked_" + skin_id, "1");
    };
    __decorate([
        DataCenter_1.field()
    ], UserInfoClass.prototype, "level", void 0);
    __decorate([
        DataCenter_1.field()
    ], UserInfoClass.prototype, "selectedSkin", void 0);
    __decorate([
        DataCenter_1.field()
    ], UserInfoClass.prototype, "dailyGetTime", void 0);
    __decorate([
        DataCenter_1.field()
    ], UserInfoClass.prototype, "freedrawTime", void 0);
    __decorate([
        DataCenter_1.field()
    ], UserInfoClass.prototype, "luckyVideoWatchTime", void 0);
    __decorate([
        DataCenter_1.field()
    ], UserInfoClass.prototype, "shopFreeDiamondTime", void 0);
    __decorate([
        DataCenter_1.field()
    ], UserInfoClass.prototype, "diamond", void 0);
    __decorate([
        DataCenter_1.field()
    ], UserInfoClass.prototype, "sfx_enabled", void 0);
    __decorate([
        DataCenter_1.field()
    ], UserInfoClass.prototype, "firstTimeReach", void 0);
    __decorate([
        DataCenter_1.field()
    ], UserInfoClass.prototype, "luckyVideoWatchCount", void 0);
    UserInfoClass = __decorate([
        DataCenter_1.dc("Info")
    ], UserInfoClass);
    return UserInfoClass;
}(DataCenter_1.default));
exports.default = UserInfoClass;
exports.UserInfo = DataCenter_1.default.register(UserInfoClass);

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcR2FtZVxcU2NyaXB0c1xcSW5mby50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLDRFQUFzRjtBQUN0Riw0Q0FBeUM7QUFDekMsOEVBQXNFO0FBQ3RFLHVFQUFrRTtBQUlsRSxJQUFZLFVBT1g7QUFQRCxXQUFZLFVBQVU7SUFDbEIsbURBQVEsQ0FBQTtJQUNSLGlEQUFPLENBQUE7SUFDUCx5Q0FBRyxDQUFBO0lBQ0gsMkNBQUksQ0FBQTtJQUNKLGlFQUFlLENBQUE7SUFDZix1Q0FBRSxDQUFBO0FBQ04sQ0FBQyxFQVBXLFVBQVUsR0FBVixrQkFBVSxLQUFWLGtCQUFVLFFBT3JCO0FBR0Q7SUFBMkMsaUNBQVU7SUFxRmpEO1FBQUEsWUFFSSxpQkFBTyxTQU1WO1FBM0ZELGFBQU8sR0FBTSxFQUFFLENBQUE7UUFDZixhQUFPLEdBQVUsR0FBRyxDQUFDO1FBNkJyQixXQUFLLEdBQVUsQ0FBQyxDQUFDO1FBR2pCLGtCQUFZLEdBQVUsR0FBRyxDQUFDO1FBRzFCLGtCQUFZLEdBQVcsSUFBSSxJQUFJLENBQUMsSUFBSSxFQUFDLENBQUMsRUFBQyxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQztRQUdwRCxrQkFBWSxHQUFVLEtBQUksQ0FBQyxZQUFZLENBQUM7UUFHeEMseUJBQW1CLEdBQVUsS0FBSSxDQUFDLFlBQVksQ0FBQTtRQUc5Qyx5QkFBbUIsR0FBVSxLQUFJLENBQUMsWUFBWSxDQUFDO1FBRy9DLGFBQU8sR0FBVSxDQUFDLENBQUM7UUFHbkIsaUJBQVcsR0FBVyxJQUFJLENBQUM7UUFHM0Isb0JBQWMsR0FBVyxLQUFLLENBQUM7UUFHL0IsMEJBQW9CLEdBQVUsQ0FBQyxDQUFDO1FBQ2hDLGdCQUFVLEdBQVcsQ0FBQyxDQUFDO1FBQ3ZCLGNBQVEsR0FBVSxDQUFDLENBQUM7UUFzQnBCLGtCQUFZLEdBQVUsQ0FBQyxDQUFDO1FBS3BCLEtBQUksQ0FBQyxNQUFNLENBQUMsS0FBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO1FBQy9CLFVBQVUsQ0FBQztZQUNQLEtBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNoQixDQUFDLEVBQUUsRUFBRSxHQUFHLElBQUksQ0FBQyxDQUFBOztRQUNiLHFCQUFxQjtJQUN6QixDQUFDO0lBekZELHNDQUFzQztJQUN0QyxpQ0FBUyxHQUFULFVBQVUsTUFBTTtRQUVaLE9BQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDckMsQ0FBQztJQUVELDRCQUFJLEdBQUo7SUFJQSxDQUFDO0lBSUQsbUNBQVcsR0FBWCxVQUFZLElBQUk7UUFFWixJQUFHLElBQUksRUFDUDtZQUNJLElBQUksTUFBTSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQTtZQUNwQixJQUFHLE1BQU0sRUFDVDtnQkFDSSxJQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFBO2FBQ2xEO1NBQ0o7SUFFTCxDQUFDO0lBa0NELGtDQUFVLEdBQVYsVUFBVyxDQUFDLEVBQUMsQ0FBUTtRQUFSLGtCQUFBLEVBQUEsUUFBUTtRQUVqQixJQUFHLE9BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxRQUFRO1lBQUUsSUFBSSxDQUFDLE9BQU8sSUFBSSxDQUFDLENBQUM7O1lBQ3ZDLElBQUksQ0FBQyxPQUFPLElBQUksUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ2pDLElBQUcsQ0FBQyxFQUNKO1lBQ0ksb0JBQUssQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFBO1lBQ3hCLGdCQUFNLENBQUMsVUFBVSxDQUFDLE9BQUMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1NBQzFDO1FBQ0QsSUFBRyxDQUFDLElBQUksQ0FBQyxjQUFjLEVBQ3ZCO1lBQ0ksSUFBRyxJQUFJLENBQUMsT0FBTyxJQUFJLEdBQUcsRUFDdEI7Z0JBQ0ksb0JBQUssQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUMsQ0FBQyxDQUFDLENBQUE7Z0JBQ2xDLElBQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFBO2dCQUMxQixnQkFBUSxDQUFDLElBQUksRUFBRSxDQUFDO2FBQ25CO1NBQ0o7SUFDTCxDQUFDO0lBY0QsZ0NBQVEsR0FBUixVQUFTLE9BQU87UUFFWixJQUFJLFdBQVcsR0FBSSxZQUFZLENBQUMsT0FBTyxDQUFDLFdBQVcsR0FBQyxPQUFPLENBQUMsQ0FBQztRQUM3RCxJQUFHLENBQUMsV0FBVyxFQUNmO1lBQ0ksT0FBTyxLQUFLLENBQUE7U0FDZjthQUNEO1lBQ0ksT0FBTyxXQUFXLElBQUksR0FBRyxDQUFBO1NBQzVCO0lBQ0wsQ0FBQztJQUVELHFDQUFhLEdBQWI7UUFFSSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDVixLQUFJLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUUsT0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFDLENBQUMsRUFBRSxFQUM5QztZQUNJLElBQUksQ0FBQyxHQUFHLE9BQUMsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFBO1lBQzVCLElBQUcsZ0JBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxFQUMxQjtnQkFDSSxDQUFDLEVBQUcsQ0FBQTthQUNQO1NBQ0o7UUFDRCxPQUFPLENBQUMsSUFBSSxPQUFDLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUE7SUFDeEMsQ0FBQztJQUdELG1DQUFXLEdBQVgsVUFBWSxFQUFPO1FBQ2YsSUFBSSxHQUFHLEdBQUcsT0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQUEsQ0FBQyxJQUFHLE9BQU8sQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUEsQ0FBQSxDQUFDLENBQUMsQ0FBQztRQUMzRCxPQUFPLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUNqQixDQUFDO0lBR0QsOEJBQU0sR0FBTixVQUFPLE9BQU87UUFFVixZQUFZLENBQUMsT0FBTyxDQUFDLFdBQVcsR0FBQyxPQUFPLEVBQUcsR0FBRyxDQUFDLENBQUE7SUFDbkQsQ0FBQztJQW5HRDtRQURDLGtCQUFLLEVBQUU7Z0RBQ1M7SUFHakI7UUFEQyxrQkFBSyxFQUFFO3VEQUNrQjtJQUcxQjtRQURDLGtCQUFLLEVBQUU7dURBQzRDO0lBR3BEO1FBREMsa0JBQUssRUFBRTt1REFDZ0M7SUFHeEM7UUFEQyxrQkFBSyxFQUFFOzhEQUNzQztJQUc5QztRQURDLGtCQUFLLEVBQUU7OERBQ3VDO0lBRy9DO1FBREMsa0JBQUssRUFBRTtrREFDVztJQUduQjtRQURDLGtCQUFLLEVBQUU7c0RBQ21CO0lBRzNCO1FBREMsa0JBQUssRUFBRTt5REFDdUI7SUFHL0I7UUFEQyxrQkFBSyxFQUFFOytEQUN3QjtJQTNEZixhQUFhO1FBRGpDLGVBQUUsQ0FBQyxNQUFNLENBQUM7T0FDVSxhQUFhLENBcUlqQztJQUFELG9CQUFDO0NBcklELEFBcUlDLENBckkwQyxvQkFBVSxHQXFJcEQ7a0JBcklvQixhQUFhO0FBc0l2QixRQUFBLFFBQVEsR0FBaUIsb0JBQVUsQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLENBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgRGF0YUNlbnRlciwgeyBkYywgZmllbGQgfSBmcm9tIFwiLi4vLi4vZnJhbWV3b3JrL3BsdWdpbl9ib29zdHMvbWlzYy9EYXRhQ2VudGVyXCI7XG5pbXBvcnQgeyBSIH0gZnJvbSBcIi4vaGV4LWxpbmVzLWdhbWUvUmVzXCI7XG5pbXBvcnQgeyBUb2FzdCB9IGZyb20gXCIuLi8uLi9mcmFtZXdvcmsvcGx1Z2luX2Jvb3N0cy91aS9Ub2FzdE1hbmFnZXJcIjtcbmltcG9ydCBEZXZpY2UgZnJvbSBcIi4uLy4uL2ZyYW1ld29yay9wbHVnaW5fYm9vc3RzL2dhbWVzeXMvRGV2aWNlXCI7XG5pbXBvcnQgUGxhdGZvcm0gZnJvbSBcIi4uLy4uL2ZyYW1ld29yay9QbGF0Zm9ybVwiO1xuXG5cbmV4cG9ydCBlbnVtIENob2ljZVR5cGUgIHtcbiAgICBEYWlseUdldCxcbiAgICBMZXZlbHVwLFxuICAgIEdldCxcbiAgICBTaG9wLFxuICAgIEJhbm5lckFkUmVmcmVzaCxcbiAgICBIQixcbn1cblxuQGRjKFwiSW5mb1wiKVxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgVXNlckluZm9DbGFzcyBleHRlbmRzIERhdGFDZW50ZXJcbntcbiAgICBjaG9pY2VzOltdID0gW11cbiAgICB2ZXJzaW9uOnN0cmluZyA9IFwiNlwiO1xuICAgIC8vIHJldDogMDpkaXJlY3RseS1nZXQgMTpzaGFyZSAyOnZpZGVvXG4gICAgZ2V0Q2hvaWNlKHNsb3RJZClcbiAgICB7XG4gICAgICAgIHJldHVybiB0aGlzLmNob2ljZXNbc2xvdElkXSB8fCAwO1xuICAgIH1cblxuICAgIGluaXQoKVxuICAgIHtcbiBcbiAgICAgIFxuICAgIH1cblxuICBcblxuICAgIG9uR2V0Q29uZmlnKGRhdGEpXG4gICAge1xuICAgICAgICBpZihkYXRhKVxuICAgICAgICB7XG4gICAgICAgICAgICBsZXQgcmVjb3JkID0gZGF0YVswXVxuICAgICAgICAgICAgaWYocmVjb3JkKVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHRoaXMuY2hvaWNlcyA9IEpTT04ucGFyc2UocmVjb3JkW3RoaXMudmVyc2lvbl0pXG4gICAgICAgICAgICB9XG4gICAgICAgIH0gXG4gICAgIFxuICAgIH1cblxuICAgIEBmaWVsZCgpXG4gICAgbGV2ZWw6bnVtYmVyID0gMTtcblxuICAgIEBmaWVsZCgpXG4gICAgc2VsZWN0ZWRTa2luOnN0cmluZyA9IFwiMlwiO1xuXG4gICAgQGZpZWxkKClcbiAgICBkYWlseUdldFRpbWU6bnVtYmVyID0gIG5ldyBEYXRlKDIwMTgsMSwxKS5nZXRUaW1lKCk7XG5cbiAgICBAZmllbGQoKVxuICAgIGZyZWVkcmF3VGltZTpudW1iZXIgPSB0aGlzLmRhaWx5R2V0VGltZTtcblxuICAgIEBmaWVsZCgpXG4gICAgbHVja3lWaWRlb1dhdGNoVGltZTpudW1iZXIgPSB0aGlzLmRhaWx5R2V0VGltZVxuXG4gICAgQGZpZWxkKClcbiAgICBzaG9wRnJlZURpYW1vbmRUaW1lOm51bWJlciA9IHRoaXMuZGFpbHlHZXRUaW1lO1xuXG4gICAgQGZpZWxkKClcbiAgICBkaWFtb25kOm51bWJlciA9IDA7XG5cbiAgICBAZmllbGQoKVxuICAgIHNmeF9lbmFibGVkOmJvb2xlYW4gPSB0cnVlO1xuXG4gICAgQGZpZWxkKClcbiAgICBmaXJzdFRpbWVSZWFjaDpib29sZWFuID0gZmFsc2U7XG5cbiAgICBAZmllbGQoKVxuICAgIGx1Y2t5VmlkZW9XYXRjaENvdW50Om51bWJlciA9IDA7XG4gICAgdGltZVBhc3NlZDogbnVtYmVyID0gMDtcbiAgICBzdGVwVXNlZDpudW1iZXIgPSAwO1xuXG4gICAgYWRkRGlhbW9uZChkLGIgPSB0cnVlKVxuICAgIHtcbiAgICAgICAgaWYodHlwZW9mKGQpID09IFwibnVtYmVyXCIpIHRoaXMuZGlhbW9uZCArPSBkO1xuICAgICAgICBlbHNlIHRoaXMuZGlhbW9uZCArPSBwYXJzZUludChkKTtcbiAgICAgICAgaWYoYilcbiAgICAgICAge1xuICAgICAgICAgICAgVG9hc3QubWFrZShcIuiOt+W+l+mSu+efsyB4XCIgKyBkKVxuICAgICAgICAgICAgRGV2aWNlLnBsYXlFZmZlY3QoUi5hdWRpb19nZXRfZGlhbW9uZCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYoIXRoaXMuZmlyc3RUaW1lUmVhY2gpXG4gICAgICAgIHtcbiAgICAgICAgICAgIGlmKHRoaXMuZGlhbW9uZCA+PSA1MDApXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgVG9hc3QubWFrZShcIuWTh+WPr+S7peS5sOearuiCpOS6hu+8jOW/q+WOu+earuiCpOWVhuW6l+eci+eci+WQpyFcIiwyKVxuICAgICAgICAgICAgICAgIHRoaXMuZmlyc3RUaW1lUmVhY2ggPSB0cnVlXG4gICAgICAgICAgICAgICAgVXNlckluZm8uc2F2ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG4gICAgY3VycmVudExldmVsOm51bWJlciA9IDE7XG5cbiAgICBjb25zdHJ1Y3RvcigpXG4gICAge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLnVubG9jayh0aGlzLnNlbGVjdGVkU2tpbik7XG4gICAgICAgIHNldFRpbWVvdXQoKCk9PntcbiAgICAgICAgICAgIHRoaXMuc2F2ZSgpO1xuICAgICAgICB9LCA2MCAqIDEwMDApXG4gICAgICAgIC8vIG9uZXhpdCBnYW1lID0+c2F2ZVxuICAgIH1cblxuICAgIGlzVW5sb2NrKHNraW5faWQpXG4gICAge1xuICAgICAgICBsZXQgY2FyVW5sb2NrZWQgPSAgbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1bmxvY2tlZF9cIitza2luX2lkKTtcbiAgICAgICAgaWYoIWNhclVubG9ja2VkKVxuICAgICAgICB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgICAgfWVsc2VcbiAgICAgICAge1xuICAgICAgICAgICAgcmV0dXJuIGNhclVubG9ja2VkID09IFwiMVwiXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBpc0FsbFVubG9ja2VkKClcbiAgICB7XG4gICAgICAgIGxldCBjID0gMDtcbiAgICAgICAgZm9yKHZhciBpID0gMCA7aSA8Ui5za2luQ29uZmlnLmpzb24ubGVuZ3RoO2krKylcbiAgICAgICAge1xuICAgICAgICAgICAgdmFyIHYgPSBSLnNraW5Db25maWcuanNvbltpXVxuICAgICAgICAgICAgaWYoVXNlckluZm8uaXNVbmxvY2sodi5pZCkpXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgYyArK1xuICAgICAgICAgICAgfVxuICAgICAgICB9ICAgXG4gICAgICAgIHJldHVybiBjID09IFIuc2tpbkNvbmZpZy5qc29uLmxlbmd0aFxuICAgIH1cblxuXG4gICAgZ2V0U2tpbkJ5SWQoaWQ6IGFueSk6IGFueSB7XG4gICAgICAgIGxldCByZXMgPSBSLnNraW5Db25maWcuanNvbi5maWx0ZXIodj0+e3JldHVybiB2LmlkID09IGlkfSk7XG4gICAgICAgIHJldHVybiByZXNbMF1cbiAgICB9XG5cblxuICAgIHVubG9jayhza2luX2lkKVxuICAgIHtcbiAgICAgICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJ1bmxvY2tlZF9cIitza2luX2lkICwgXCIxXCIpXG4gICAgfVxuXG59XG5leHBvcnQgdmFyIFVzZXJJbmZvOlVzZXJJbmZvQ2xhc3MgPSBEYXRhQ2VudGVyLnJlZ2lzdGVyKFVzZXJJbmZvQ2xhc3MpIl19
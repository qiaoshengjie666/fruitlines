
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/framework/Platform.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '8fc52zVaq1FVrE4//XvMzeK', 'Platform');
// framework/Platform.ts

Object.defineProperty(exports, "__esModule", { value: true });
var WxCommands;
(function (WxCommands) {
    WxCommands[WxCommands["Hide"] = 99] = "Hide";
    WxCommands[WxCommands["Next"] = 100] = "Next";
    WxCommands[WxCommands["RankSmall"] = 101] = "RankSmall";
    WxCommands[WxCommands["Rank"] = 102] = "Rank";
})(WxCommands || (WxCommands = {}));
var Platform = /** @class */ (function () {
    function Platform() {
    }
    return Platform;
}());
exports.default = Platform;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcZnJhbWV3b3JrXFxQbGF0Zm9ybS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7O0FBUUEsSUFBSyxVQU1KO0FBTkQsV0FBSyxVQUFVO0lBRVgsNENBQVMsQ0FBQTtJQUNULDZDQUFJLENBQUE7SUFDSix1REFBUyxDQUFBO0lBQ1QsNkNBQUksQ0FBQTtBQUNSLENBQUMsRUFOSSxVQUFVLEtBQVYsVUFBVSxRQU1kO0FBRUQ7SUFBQTtJQUlBLENBQUM7SUFBRCxlQUFDO0FBQUQsQ0FKQSxBQUlDLElBQUEiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJcbmltcG9ydCB7IFRvYXN0IH0gZnJvbSBcIi4vcGx1Z2luX2Jvb3N0cy91aS9Ub2FzdE1hbmFnZXJcIjtcblxuaW1wb3J0IERldmljZSBmcm9tIFwiLi9wbHVnaW5fYm9vc3RzL2dhbWVzeXMvRGV2aWNlXCI7XG5pbXBvcnQgU3ByaXRlRnJhbWVDYWNoZSBmcm9tIFwiLi9wbHVnaW5fYm9vc3RzL21pc2MvU3ByaXRlRnJhbWVDYWNoZVwiO1xuaW1wb3J0IFNpZ25hbCBmcm9tIFwiLi9wbHVnaW5fYm9vc3RzL21pc2MvU2lnbmFsXCI7XG5pbXBvcnQgeyBldmVudCB9IGZyb20gXCIuL3BsdWdpbl9ib29zdHMvdXRpbHMvRXZlbnRNYW5hZ2VyXCI7XG5cbmVudW0gV3hDb21tYW5kc1xue1xuICAgIEhpZGUgPSA5OSxcbiAgICBOZXh0LFxuICAgIFJhbmtTbWFsbCxcbiAgICBSYW5rLFxufVxuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBQbGF0Zm9ybVxue1xuICAgXG4gICAgXG59Il19
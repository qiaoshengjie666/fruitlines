
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/framework/network/MessageType.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '9f654W7umlMeasjS7fKQj29', 'MessageType');
// framework/network/MessageType.ts

Object.defineProperty(exports, "__esModule", { value: true });
exports.SocketTag = void 0;
/**
* name
*/
var SocketTag;
(function (SocketTag) {
    SocketTag[SocketTag["KSOCKET_OPEN"] = 0] = "KSOCKET_OPEN";
    SocketTag[SocketTag["KSOCKET_CLOSE"] = 1] = "KSOCKET_CLOSE";
    SocketTag[SocketTag["KSOCKET_MESSAGE"] = 2] = "KSOCKET_MESSAGE";
    SocketTag[SocketTag["KSOCKET_ERROR"] = 3] = "KSOCKET_ERROR";
})(SocketTag = exports.SocketTag || (exports.SocketTag = {}));

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcZnJhbWV3b3JrXFxuZXR3b3JrXFxNZXNzYWdlVHlwZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBOztFQUVFO0FBQ0QsSUFBWSxTQUtYO0FBTEQsV0FBWSxTQUFTO0lBQ3BCLHlEQUFZLENBQUE7SUFDWiwyREFBYSxDQUFBO0lBQ2IsK0RBQWUsQ0FBQTtJQUNmLDJEQUFhLENBQUE7QUFDZCxDQUFDLEVBTFcsU0FBUyxHQUFULGlCQUFTLEtBQVQsaUJBQVMsUUFLcEIiLCJmaWxlIjoiIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiogbmFtZSBcbiovXG5cdGV4cG9ydCBlbnVtIFNvY2tldFRhZyB7XG5cdFx0S1NPQ0tFVF9PUEVOLFxuXHRcdEtTT0NLRVRfQ0xPU0UsXG5cdFx0S1NPQ0tFVF9NRVNTQUdFLFxuXHRcdEtTT0NLRVRfRVJST1IsXG5cdH1cdCJdfQ==

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/gameComon/scripts/room.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '690ef7tcntLt4eCVVAMIQ0O', 'room');
// gameComon/scripts/room.js

"use strict";

/*中台配置文件获取*/
var Emitter = require('emitter');

var consts = require('./model/consts');

var Room = cc.Class({
  "extends": Emitter,
  initWithData: function initWithData(data) {
    this.commonConfig = {};
    this.configSuccess1 = false;
    this.isHadWord = false;
    var url = consts.HTTP_GET_PAAS_DATA_SERVER + "?gameId=" + consts.GAME_ID + "&plat=" + appGame.platform + "&version=" + appGame.packageVersion + "&brand=" + '' + "&from=MiddleDesk";
    console.log("room url===" + url); //url = 'https://cs.snmi.cn/game/GetGameValue?gameId=1&plat=toutiao&version=1.0.4&brand=&from=MiddleDesk'

    httpUtils.httpSendRequest(url, function (res) {
      console.log("room ==" + JSON.stringify(res));

      if (res && res.Code == 200) {
        var detailparse = JSON.parse(res.Detail);

        if (detailparse) {
          if (detailparse.word) {
            this.isHadWord = true;
            util.spreadWordFun();
          }

          this.commonConfig = detailparse;
          this.configSuccess1 = true;
        }

        appGame.emitter.emit(consts.HTTP_EVENT_MIDDLE_DESK_CONFIG, {});

        if (this.configSuccess2 && this.configSuccess1) {
          appGame.gameServerRoom.emit(consts.CLIENT_GAME_START, {});
        }
      } else {
        util.loadJSONData("comJson", 'comConfig', function (data) {
          if (data) {
            this.commonConfig = data;
            this.configSuccess1 = true;

            if (data.word) {
              this.isHadWord = true;
              util.spreadWordFun();
            }
          }

          appGame.emitter.emit(consts.HTTP_EVENT_MIDDLE_DESK_CONFIG, {});

          if (this.configSuccess2 && this.configSuccess1) {
            appGame.gameServerRoom.emit(consts.CLIENT_GAME_START, {});
          }
        }.bind(this));
      }
    }.bind(this)); // util.loadJSONData("comJson",'comConfig',function(data){
    //     if(data){
    //         this.commonConfig = data;
    //         this.configSuccess1 = true;
    //     }
    //     appGame.emitter.emit(consts.HTTP_EVENT_MIDDLE_DESK_CONFIG,{});
    //     if(this.configSuccess2 && this.configSuccess1){
    //         appGame.gameServerRoom.emit(consts.CLIENT_GAME_START,{});
    //     }
    // }.bind(this));
  }
});
module.exports = Room;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcZ2FtZUNvbW9uXFxzY3JpcHRzXFxyb29tLmpzIl0sIm5hbWVzIjpbIkVtaXR0ZXIiLCJyZXF1aXJlIiwiY29uc3RzIiwiUm9vbSIsImNjIiwiQ2xhc3MiLCJpbml0V2l0aERhdGEiLCJkYXRhIiwiY29tbW9uQ29uZmlnIiwiY29uZmlnU3VjY2VzczEiLCJpc0hhZFdvcmQiLCJ1cmwiLCJIVFRQX0dFVF9QQUFTX0RBVEFfU0VSVkVSIiwiR0FNRV9JRCIsImFwcEdhbWUiLCJwbGF0Zm9ybSIsInBhY2thZ2VWZXJzaW9uIiwiY29uc29sZSIsImxvZyIsImh0dHBVdGlscyIsImh0dHBTZW5kUmVxdWVzdCIsInJlcyIsIkpTT04iLCJzdHJpbmdpZnkiLCJDb2RlIiwiZGV0YWlscGFyc2UiLCJwYXJzZSIsIkRldGFpbCIsIndvcmQiLCJ1dGlsIiwic3ByZWFkV29yZEZ1biIsImVtaXR0ZXIiLCJlbWl0IiwiSFRUUF9FVkVOVF9NSURETEVfREVTS19DT05GSUciLCJjb25maWdTdWNjZXNzMiIsImdhbWVTZXJ2ZXJSb29tIiwiQ0xJRU5UX0dBTUVfU1RBUlQiLCJsb2FkSlNPTkRhdGEiLCJiaW5kIiwibW9kdWxlIiwiZXhwb3J0cyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBLElBQUlBLE9BQU8sR0FBR0MsT0FBTyxDQUFDLFNBQUQsQ0FBckI7O0FBQ0EsSUFBTUMsTUFBTSxHQUFHRCxPQUFPLENBQUMsZ0JBQUQsQ0FBdEI7O0FBQ0EsSUFBSUUsSUFBSSxHQUFHQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNoQixhQUFTTCxPQURPO0FBRWhCTSxFQUFBQSxZQUFZLEVBQUUsc0JBQVVDLElBQVYsRUFBZ0I7QUFDMUIsU0FBS0MsWUFBTCxHQUFvQixFQUFwQjtBQUNBLFNBQUtDLGNBQUwsR0FBc0IsS0FBdEI7QUFDQSxTQUFLQyxTQUFMLEdBQWlCLEtBQWpCO0FBQ0EsUUFBSUMsR0FBRyxHQUFHVCxNQUFNLENBQUNVLHlCQUFQLEdBQWlDLFVBQWpDLEdBQTRDVixNQUFNLENBQUNXLE9BQW5ELEdBQTJELFFBQTNELEdBQW9FQyxPQUFPLENBQUNDLFFBQTVFLEdBQ04sV0FETSxHQUNNRCxPQUFPLENBQUNFLGNBRGQsR0FDNkIsU0FEN0IsR0FDdUMsRUFEdkMsR0FDMEMsa0JBRHBEO0FBRUFDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLGdCQUFjUCxHQUExQixFQU4wQixDQU8xQjs7QUFDQVEsSUFBQUEsU0FBUyxDQUFDQyxlQUFWLENBQTBCVCxHQUExQixFQUE4QixVQUFTVSxHQUFULEVBQWE7QUFDdkNKLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFlBQVVJLElBQUksQ0FBQ0MsU0FBTCxDQUFlRixHQUFmLENBQXRCOztBQUNBLFVBQUdBLEdBQUcsSUFBSUEsR0FBRyxDQUFDRyxJQUFKLElBQVksR0FBdEIsRUFBMEI7QUFDdEIsWUFBSUMsV0FBVyxHQUFHSCxJQUFJLENBQUNJLEtBQUwsQ0FBV0wsR0FBRyxDQUFDTSxNQUFmLENBQWxCOztBQUNBLFlBQUdGLFdBQUgsRUFBZTtBQUNYLGNBQUdBLFdBQVcsQ0FBQ0csSUFBZixFQUFvQjtBQUNoQixpQkFBS2xCLFNBQUwsR0FBaUIsSUFBakI7QUFDQW1CLFlBQUFBLElBQUksQ0FBQ0MsYUFBTDtBQUNIOztBQUNELGVBQUt0QixZQUFMLEdBQW9CaUIsV0FBcEI7QUFDQSxlQUFLaEIsY0FBTCxHQUFzQixJQUF0QjtBQUNIOztBQUNESyxRQUFBQSxPQUFPLENBQUNpQixPQUFSLENBQWdCQyxJQUFoQixDQUFxQjlCLE1BQU0sQ0FBQytCLDZCQUE1QixFQUEwRCxFQUExRDs7QUFDQSxZQUFHLEtBQUtDLGNBQUwsSUFBdUIsS0FBS3pCLGNBQS9CLEVBQThDO0FBQzFDSyxVQUFBQSxPQUFPLENBQUNxQixjQUFSLENBQXVCSCxJQUF2QixDQUE0QjlCLE1BQU0sQ0FBQ2tDLGlCQUFuQyxFQUFxRCxFQUFyRDtBQUNIO0FBQ0osT0FkRCxNQWNLO0FBQ0RQLFFBQUFBLElBQUksQ0FBQ1EsWUFBTCxDQUFrQixTQUFsQixFQUE0QixXQUE1QixFQUF3QyxVQUFTOUIsSUFBVCxFQUFjO0FBQ2xELGNBQUdBLElBQUgsRUFBUTtBQUNKLGlCQUFLQyxZQUFMLEdBQW9CRCxJQUFwQjtBQUNBLGlCQUFLRSxjQUFMLEdBQXNCLElBQXRCOztBQUNBLGdCQUFHRixJQUFJLENBQUNxQixJQUFSLEVBQWE7QUFDVCxtQkFBS2xCLFNBQUwsR0FBaUIsSUFBakI7QUFDQW1CLGNBQUFBLElBQUksQ0FBQ0MsYUFBTDtBQUNIO0FBQ0o7O0FBQ0RoQixVQUFBQSxPQUFPLENBQUNpQixPQUFSLENBQWdCQyxJQUFoQixDQUFxQjlCLE1BQU0sQ0FBQytCLDZCQUE1QixFQUEwRCxFQUExRDs7QUFDQSxjQUFHLEtBQUtDLGNBQUwsSUFBdUIsS0FBS3pCLGNBQS9CLEVBQThDO0FBQzFDSyxZQUFBQSxPQUFPLENBQUNxQixjQUFSLENBQXVCSCxJQUF2QixDQUE0QjlCLE1BQU0sQ0FBQ2tDLGlCQUFuQyxFQUFxRCxFQUFyRDtBQUNIO0FBQ0osU0FidUMsQ0FhdENFLElBYnNDLENBYWpDLElBYmlDLENBQXhDO0FBY0g7QUFDSixLQWhDNkIsQ0FnQzVCQSxJQWhDNEIsQ0FnQ3ZCLElBaEN1QixDQUE5QixFQVIwQixDQXlDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQXJEZSxDQUFULENBQVg7QUF3REFDLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQnJDLElBQWpCIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvKuS4reWPsOmFjee9ruaWh+S7tuiOt+WPliovXHJcbnZhciBFbWl0dGVyID0gcmVxdWlyZSgnZW1pdHRlcicpO1xyXG5jb25zdCBjb25zdHMgPSByZXF1aXJlKCcuL21vZGVsL2NvbnN0cycpO1xyXG52YXIgUm9vbSA9IGNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IEVtaXR0ZXIsXHJcbiAgICBpbml0V2l0aERhdGE6IGZ1bmN0aW9uIChkYXRhKSB7XHJcbiAgICAgICAgdGhpcy5jb21tb25Db25maWcgPSB7fTtcclxuICAgICAgICB0aGlzLmNvbmZpZ1N1Y2Nlc3MxID0gZmFsc2U7XHJcbiAgICAgICAgdGhpcy5pc0hhZFdvcmQgPSBmYWxzZTtcclxuICAgICAgICBsZXQgdXJsID0gY29uc3RzLkhUVFBfR0VUX1BBQVNfREFUQV9TRVJWRVIrXCI/Z2FtZUlkPVwiK2NvbnN0cy5HQU1FX0lEK1wiJnBsYXQ9XCIrYXBwR2FtZS5wbGF0Zm9ybVxyXG4gICAgICAgICAgICtcIiZ2ZXJzaW9uPVwiK2FwcEdhbWUucGFja2FnZVZlcnNpb24rXCImYnJhbmQ9XCIrJycrXCImZnJvbT1NaWRkbGVEZXNrXCI7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJyb29tIHVybD09PVwiK3VybClcclxuICAgICAgICAvL3VybCA9ICdodHRwczovL2NzLnNubWkuY24vZ2FtZS9HZXRHYW1lVmFsdWU/Z2FtZUlkPTEmcGxhdD10b3V0aWFvJnZlcnNpb249MS4wLjQmYnJhbmQ9JmZyb209TWlkZGxlRGVzaydcclxuICAgICAgICBodHRwVXRpbHMuaHR0cFNlbmRSZXF1ZXN0KHVybCxmdW5jdGlvbihyZXMpe1xyXG4gICAgICAgICAgICBjb25zb2xlLmxvZyhcInJvb20gPT1cIitKU09OLnN0cmluZ2lmeShyZXMpKVxyXG4gICAgICAgICAgICBpZihyZXMgJiYgcmVzLkNvZGUgPT0gMjAwKXtcclxuICAgICAgICAgICAgICAgIGxldCBkZXRhaWxwYXJzZSA9IEpTT04ucGFyc2UocmVzLkRldGFpbClcclxuICAgICAgICAgICAgICAgIGlmKGRldGFpbHBhcnNlKXtcclxuICAgICAgICAgICAgICAgICAgICBpZihkZXRhaWxwYXJzZS53b3JkKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5pc0hhZFdvcmQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB1dGlsLnNwcmVhZFdvcmRGdW4oKTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jb21tb25Db25maWcgPSBkZXRhaWxwYXJzZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbmZpZ1N1Y2Nlc3MxID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGFwcEdhbWUuZW1pdHRlci5lbWl0KGNvbnN0cy5IVFRQX0VWRU5UX01JRERMRV9ERVNLX0NPTkZJRyx7fSk7XHJcbiAgICAgICAgICAgICAgICBpZih0aGlzLmNvbmZpZ1N1Y2Nlc3MyICYmIHRoaXMuY29uZmlnU3VjY2VzczEpe1xyXG4gICAgICAgICAgICAgICAgICAgIGFwcEdhbWUuZ2FtZVNlcnZlclJvb20uZW1pdChjb25zdHMuQ0xJRU5UX0dBTUVfU1RBUlQse30pO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgICAgIHV0aWwubG9hZEpTT05EYXRhKFwiY29tSnNvblwiLCdjb21Db25maWcnLGZ1bmN0aW9uKGRhdGEpe1xyXG4gICAgICAgICAgICAgICAgICAgIGlmKGRhdGEpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLmNvbW1vbkNvbmZpZyA9IGRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnU3VjY2VzczEgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZihkYXRhLndvcmQpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy5pc0hhZFdvcmQgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdXRpbC5zcHJlYWRXb3JkRnVuKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgYXBwR2FtZS5lbWl0dGVyLmVtaXQoY29uc3RzLkhUVFBfRVZFTlRfTUlERExFX0RFU0tfQ09ORklHLHt9KTtcclxuICAgICAgICAgICAgICAgICAgICBpZih0aGlzLmNvbmZpZ1N1Y2Nlc3MyICYmIHRoaXMuY29uZmlnU3VjY2VzczEpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBhcHBHYW1lLmdhbWVTZXJ2ZXJSb29tLmVtaXQoY29uc3RzLkNMSUVOVF9HQU1FX1NUQVJULHt9KTtcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9LmJpbmQodGhpcykpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfS5iaW5kKHRoaXMpKTtcclxuICAgICAgICAvLyB1dGlsLmxvYWRKU09ORGF0YShcImNvbUpzb25cIiwnY29tQ29uZmlnJyxmdW5jdGlvbihkYXRhKXtcclxuICAgICAgICAvLyAgICAgaWYoZGF0YSl7XHJcbiAgICAgICAgLy8gICAgICAgICB0aGlzLmNvbW1vbkNvbmZpZyA9IGRhdGE7XHJcbiAgICAgICAgLy8gICAgICAgICB0aGlzLmNvbmZpZ1N1Y2Nlc3MxID0gdHJ1ZTtcclxuICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgIC8vICAgICBhcHBHYW1lLmVtaXR0ZXIuZW1pdChjb25zdHMuSFRUUF9FVkVOVF9NSURETEVfREVTS19DT05GSUcse30pO1xyXG4gICAgICAgIC8vICAgICBpZih0aGlzLmNvbmZpZ1N1Y2Nlc3MyICYmIHRoaXMuY29uZmlnU3VjY2VzczEpe1xyXG4gICAgICAgIC8vICAgICAgICAgYXBwR2FtZS5nYW1lU2VydmVyUm9vbS5lbWl0KGNvbnN0cy5DTElFTlRfR0FNRV9TVEFSVCx7fSk7XHJcbiAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAvLyB9LmJpbmQodGhpcykpO1xyXG4gICAgfVxyXG59KTtcclxuXHJcbm1vZHVsZS5leHBvcnRzID0gUm9vbTtcclxuIl19
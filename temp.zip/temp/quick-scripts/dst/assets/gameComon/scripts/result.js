
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/gameComon/scripts/result.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '33fa5PoD/RJD6LgBnT5ywP1', 'result');
// gameComon/scripts/result.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    title: cc.Label,
    contentLabel: cc.Label,
    nextBtn: cc.Button,
    backBtn: cc.Button,
    nextBtnCallback: null,
    backBtnCallback: null
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.nextBtn.node.on(cc.Node.EventType.TOUCH_END, this.onNextBtnClicked, this);
    this.backBtn.node.on(cc.Node.EventType.TOUCH_END, this.onBackBtnClicked, this);
  },
  start: function start() {},

  /**
   * @param opts
   * nextCB 下一局按钮回调
   * backCB 重玩本关按钮回调
   */
  show: function show(opts) {
    opts = opts || {};

    if (opts.nextCB) {
      this.nextBtnCallback = opts.nextCB;
    }

    if (opts.backCB) {
      this.backBtnCallback = opts.backCB;
    }

    if (opts.info) {
      this.info = opts.info;
    }

    if (opts.config) {
      if (this.info.isWin) {
        this.resultConfig = opts.config.win;
      } else {
        this.resultConfig = opts.config.fail;
      }
    }

    this.refreshUI();
  },
  refreshUI: function refreshUI() {
    if (this.info) {
      this.title.string = this.info.isWin ? this.resultConfig.title : this.resultConfig.title;
      this.contentLabel.string = this.info.isWin ? this.resultConfig.content : this.resultConfig.content;
      this.nextBtn.node.getChildByName('Background').getChildByName('New Label').getComponent(cc.Label).string = this.resultConfig.btn1.name;
      this.backBtn.node.getChildByName('Background').getChildByName('New Label').getComponent(cc.Label).string = this.resultConfig.btn2.name;
      this.nextBtn.node.getChildByName('Background').getChildByName('icon').active = this.resultConfig.btn1.icon;
      this.backBtn.node.getChildByName('Background').getChildByName('icon').active = this.resultConfig.btn2.icon;
    }

    if (appGame.interstitialAd) {
      appGame.interstitialAd.playAd();
    }

    appGame.banner.playBanner(2);
  },
  onNextBtnClicked: function onNextBtnClicked(event) {
    var isPlayVideo = false;
    var isForce = true;

    if (this.resultConfig) {
      isPlayVideo = this.resultConfig.btn1.video;
      isForce = this.resultConfig.btn1.force;
    }

    if (isPlayVideo) {
      appGame.videoBanner.playVideoAd(isForce, function () {
        this.nextBtnCallback && this.nextBtnCallback(this.info.isWin);
        this.hide();
      }.bind(this));
    } else {
      this.nextBtnCallback && this.nextBtnCallback(this.info.isWin);
      this.hide();
    }
  },
  onBackBtnClicked: function onBackBtnClicked(event) {
    var isPlayVideo = false;
    var isForce = true;

    if (this.resultConfig) {
      isPlayVideo = this.resultConfig.btn2.video;
      isForce = this.resultConfig.btn2.force;
    }

    if (isPlayVideo) {
      //配置需要播放视频
      appGame.videoBanner.playVideoAd(isForce, function () {
        console.log("看视频成功");
        this.backBtnCallback && this.backBtnCallback(this.info.isWin);
        this.hide();
      }.bind(this));
    } else {
      //不用播放视频
      this.backBtnCallback && this.backBtnCallback(this.info.isWin);
      this.hide();
    }
  },
  hide: function hide() {
    appGame.banner.playBanner(3);
    this.node.removeFromParent();
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcZ2FtZUNvbW9uXFxzY3JpcHRzXFxyZXN1bHQuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJ0aXRsZSIsIkxhYmVsIiwiY29udGVudExhYmVsIiwibmV4dEJ0biIsIkJ1dHRvbiIsImJhY2tCdG4iLCJuZXh0QnRuQ2FsbGJhY2siLCJiYWNrQnRuQ2FsbGJhY2siLCJvbkxvYWQiLCJub2RlIiwib24iLCJOb2RlIiwiRXZlbnRUeXBlIiwiVE9VQ0hfRU5EIiwib25OZXh0QnRuQ2xpY2tlZCIsIm9uQmFja0J0bkNsaWNrZWQiLCJzdGFydCIsInNob3ciLCJvcHRzIiwibmV4dENCIiwiYmFja0NCIiwiaW5mbyIsImNvbmZpZyIsImlzV2luIiwicmVzdWx0Q29uZmlnIiwid2luIiwiZmFpbCIsInJlZnJlc2hVSSIsInN0cmluZyIsImNvbnRlbnQiLCJnZXRDaGlsZEJ5TmFtZSIsImdldENvbXBvbmVudCIsImJ0bjEiLCJuYW1lIiwiYnRuMiIsImFjdGl2ZSIsImljb24iLCJhcHBHYW1lIiwiaW50ZXJzdGl0aWFsQWQiLCJwbGF5QWQiLCJiYW5uZXIiLCJwbGF5QmFubmVyIiwiZXZlbnQiLCJpc1BsYXlWaWRlbyIsImlzRm9yY2UiLCJ2aWRlbyIsImZvcmNlIiwidmlkZW9CYW5uZXIiLCJwbGF5VmlkZW9BZCIsImhpZGUiLCJiaW5kIiwiY29uc29sZSIsImxvZyIsInJlbW92ZUZyb21QYXJlbnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxLQUFLLEVBQUNKLEVBQUUsQ0FBQ0ssS0FERDtBQUVSQyxJQUFBQSxZQUFZLEVBQUNOLEVBQUUsQ0FBQ0ssS0FGUjtBQUdSRSxJQUFBQSxPQUFPLEVBQUNQLEVBQUUsQ0FBQ1EsTUFISDtBQUlSQyxJQUFBQSxPQUFPLEVBQUNULEVBQUUsQ0FBQ1EsTUFKSDtBQUtSRSxJQUFBQSxlQUFlLEVBQUUsSUFMVDtBQU1SQyxJQUFBQSxlQUFlLEVBQUU7QUFOVCxHQUhQO0FBWUw7QUFFQUMsRUFBQUEsTUFkSyxvQkFjSztBQUNOLFNBQUtMLE9BQUwsQ0FBYU0sSUFBYixDQUFrQkMsRUFBbEIsQ0FBcUJkLEVBQUUsQ0FBQ2UsSUFBSCxDQUFRQyxTQUFSLENBQWtCQyxTQUF2QyxFQUFpRCxLQUFLQyxnQkFBdEQsRUFBdUUsSUFBdkU7QUFDQSxTQUFLVCxPQUFMLENBQWFJLElBQWIsQ0FBa0JDLEVBQWxCLENBQXFCZCxFQUFFLENBQUNlLElBQUgsQ0FBUUMsU0FBUixDQUFrQkMsU0FBdkMsRUFBaUQsS0FBS0UsZ0JBQXRELEVBQXVFLElBQXZFO0FBQ0gsR0FqQkk7QUFtQkxDLEVBQUFBLEtBbkJLLG1CQW1CSSxDQUVSLENBckJJOztBQXVCTDtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0tDLEVBQUFBLElBQUksRUFBRSxjQUFVQyxJQUFWLEVBQWdCO0FBQ25CQSxJQUFBQSxJQUFJLEdBQUdBLElBQUksSUFBSSxFQUFmOztBQUNBLFFBQUdBLElBQUksQ0FBQ0MsTUFBUixFQUFlO0FBQ1gsV0FBS2IsZUFBTCxHQUF1QlksSUFBSSxDQUFDQyxNQUE1QjtBQUNIOztBQUNELFFBQUdELElBQUksQ0FBQ0UsTUFBUixFQUFlO0FBQ1gsV0FBS2IsZUFBTCxHQUF1QlcsSUFBSSxDQUFDRSxNQUE1QjtBQUNIOztBQUNELFFBQUdGLElBQUksQ0FBQ0csSUFBUixFQUFhO0FBQ1QsV0FBS0EsSUFBTCxHQUFZSCxJQUFJLENBQUNHLElBQWpCO0FBQ0g7O0FBQ0QsUUFBR0gsSUFBSSxDQUFDSSxNQUFSLEVBQWU7QUFDWCxVQUFHLEtBQUtELElBQUwsQ0FBVUUsS0FBYixFQUFtQjtBQUNmLGFBQUtDLFlBQUwsR0FBb0JOLElBQUksQ0FBQ0ksTUFBTCxDQUFZRyxHQUFoQztBQUNILE9BRkQsTUFFSztBQUNELGFBQUtELFlBQUwsR0FBb0JOLElBQUksQ0FBQ0ksTUFBTCxDQUFZSSxJQUFoQztBQUNIO0FBQ0o7O0FBQ0QsU0FBS0MsU0FBTDtBQUNILEdBL0NJO0FBaURMQSxFQUFBQSxTQWpESyx1QkFpRE07QUFDUCxRQUFHLEtBQUtOLElBQVIsRUFBYTtBQUNULFdBQUtyQixLQUFMLENBQVc0QixNQUFYLEdBQW9CLEtBQUtQLElBQUwsQ0FBVUUsS0FBVixHQUFnQixLQUFLQyxZQUFMLENBQWtCeEIsS0FBbEMsR0FBd0MsS0FBS3dCLFlBQUwsQ0FBa0J4QixLQUE5RTtBQUNBLFdBQUtFLFlBQUwsQ0FBa0IwQixNQUFsQixHQUEyQixLQUFLUCxJQUFMLENBQVVFLEtBQVYsR0FBZ0IsS0FBS0MsWUFBTCxDQUFrQkssT0FBbEMsR0FBMEMsS0FBS0wsWUFBTCxDQUFrQkssT0FBdkY7QUFFQSxXQUFLMUIsT0FBTCxDQUFhTSxJQUFiLENBQWtCcUIsY0FBbEIsQ0FBaUMsWUFBakMsRUFBK0NBLGNBQS9DLENBQThELFdBQTlELEVBQTJFQyxZQUEzRSxDQUF3Rm5DLEVBQUUsQ0FBQ0ssS0FBM0YsRUFBa0cyQixNQUFsRyxHQUEyRyxLQUFLSixZQUFMLENBQWtCUSxJQUFsQixDQUF1QkMsSUFBbEk7QUFDQSxXQUFLNUIsT0FBTCxDQUFhSSxJQUFiLENBQWtCcUIsY0FBbEIsQ0FBaUMsWUFBakMsRUFBK0NBLGNBQS9DLENBQThELFdBQTlELEVBQTJFQyxZQUEzRSxDQUF3Rm5DLEVBQUUsQ0FBQ0ssS0FBM0YsRUFBa0cyQixNQUFsRyxHQUEyRyxLQUFLSixZQUFMLENBQWtCVSxJQUFsQixDQUF1QkQsSUFBbEk7QUFFQSxXQUFLOUIsT0FBTCxDQUFhTSxJQUFiLENBQWtCcUIsY0FBbEIsQ0FBaUMsWUFBakMsRUFBK0NBLGNBQS9DLENBQThELE1BQTlELEVBQXNFSyxNQUF0RSxHQUErRSxLQUFLWCxZQUFMLENBQWtCUSxJQUFsQixDQUF1QkksSUFBdEc7QUFDQSxXQUFLL0IsT0FBTCxDQUFhSSxJQUFiLENBQWtCcUIsY0FBbEIsQ0FBaUMsWUFBakMsRUFBK0NBLGNBQS9DLENBQThELE1BQTlELEVBQXNFSyxNQUF0RSxHQUErRSxLQUFLWCxZQUFMLENBQWtCVSxJQUFsQixDQUF1QkUsSUFBdEc7QUFDSDs7QUFDRCxRQUFHQyxPQUFPLENBQUNDLGNBQVgsRUFBMEI7QUFDdEJELE1BQUFBLE9BQU8sQ0FBQ0MsY0FBUixDQUF1QkMsTUFBdkI7QUFDSDs7QUFDREYsSUFBQUEsT0FBTyxDQUFDRyxNQUFSLENBQWVDLFVBQWYsQ0FBMEIsQ0FBMUI7QUFDSCxHQWhFSTtBQWtFTDNCLEVBQUFBLGdCQWxFSyw0QkFrRVk0QixLQWxFWixFQWtFa0I7QUFDbkIsUUFBSUMsV0FBVyxHQUFHLEtBQWxCO0FBQ0EsUUFBSUMsT0FBTyxHQUFHLElBQWQ7O0FBQ0EsUUFBRyxLQUFLcEIsWUFBUixFQUFxQjtBQUNqQm1CLE1BQUFBLFdBQVcsR0FBRyxLQUFLbkIsWUFBTCxDQUFrQlEsSUFBbEIsQ0FBdUJhLEtBQXJDO0FBQ0FELE1BQUFBLE9BQU8sR0FBRyxLQUFLcEIsWUFBTCxDQUFrQlEsSUFBbEIsQ0FBdUJjLEtBQWpDO0FBQ0g7O0FBQ0QsUUFBR0gsV0FBSCxFQUFlO0FBQ1hOLE1BQUFBLE9BQU8sQ0FBQ1UsV0FBUixDQUFvQkMsV0FBcEIsQ0FBZ0NKLE9BQWhDLEVBQXdDLFlBQVU7QUFDOUMsYUFBS3RDLGVBQUwsSUFBd0IsS0FBS0EsZUFBTCxDQUFxQixLQUFLZSxJQUFMLENBQVVFLEtBQS9CLENBQXhCO0FBQ0EsYUFBSzBCLElBQUw7QUFDSCxPQUh1QyxDQUd0Q0MsSUFIc0MsQ0FHakMsSUFIaUMsQ0FBeEM7QUFJSCxLQUxELE1BS0s7QUFDRCxXQUFLNUMsZUFBTCxJQUF3QixLQUFLQSxlQUFMLENBQXFCLEtBQUtlLElBQUwsQ0FBVUUsS0FBL0IsQ0FBeEI7QUFDQSxXQUFLMEIsSUFBTDtBQUNIO0FBQ0osR0FsRkk7QUFvRkxsQyxFQUFBQSxnQkFwRkssNEJBb0ZZMkIsS0FwRlosRUFvRmtCO0FBQ25CLFFBQUlDLFdBQVcsR0FBRyxLQUFsQjtBQUNBLFFBQUlDLE9BQU8sR0FBRyxJQUFkOztBQUNBLFFBQUcsS0FBS3BCLFlBQVIsRUFBcUI7QUFDakJtQixNQUFBQSxXQUFXLEdBQUcsS0FBS25CLFlBQUwsQ0FBa0JVLElBQWxCLENBQXVCVyxLQUFyQztBQUNBRCxNQUFBQSxPQUFPLEdBQUcsS0FBS3BCLFlBQUwsQ0FBa0JVLElBQWxCLENBQXVCWSxLQUFqQztBQUNIOztBQUVELFFBQUdILFdBQUgsRUFBZTtBQUFDO0FBQ1pOLE1BQUFBLE9BQU8sQ0FBQ1UsV0FBUixDQUFvQkMsV0FBcEIsQ0FBZ0NKLE9BQWhDLEVBQXdDLFlBQVU7QUFDOUNPLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7QUFDQSxhQUFLN0MsZUFBTCxJQUF3QixLQUFLQSxlQUFMLENBQXFCLEtBQUtjLElBQUwsQ0FBVUUsS0FBL0IsQ0FBeEI7QUFDQSxhQUFLMEIsSUFBTDtBQUNILE9BSnVDLENBSXRDQyxJQUpzQyxDQUlqQyxJQUppQyxDQUF4QztBQUtILEtBTkQsTUFNSztBQUFDO0FBQ0YsV0FBSzNDLGVBQUwsSUFBd0IsS0FBS0EsZUFBTCxDQUFxQixLQUFLYyxJQUFMLENBQVVFLEtBQS9CLENBQXhCO0FBQ0EsV0FBSzBCLElBQUw7QUFDSDtBQUNKLEdBdEdJO0FBdUdMQSxFQUFBQSxJQXZHSyxrQkF1R0M7QUFDRlosSUFBQUEsT0FBTyxDQUFDRyxNQUFSLENBQWVDLFVBQWYsQ0FBMEIsQ0FBMUI7QUFDQSxTQUFLaEMsSUFBTCxDQUFVNEMsZ0JBQVY7QUFDSCxHQTFHSSxDQTRHTDs7QUE1R0ssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICB0aXRsZTpjYy5MYWJlbCxcclxuICAgICAgICBjb250ZW50TGFiZWw6Y2MuTGFiZWwsXHJcbiAgICAgICAgbmV4dEJ0bjpjYy5CdXR0b24sXHJcbiAgICAgICAgYmFja0J0bjpjYy5CdXR0b24sXHJcbiAgICAgICAgbmV4dEJ0bkNhbGxiYWNrOiBudWxsLFxyXG4gICAgICAgIGJhY2tCdG5DYWxsYmFjazogbnVsbFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICBvbkxvYWQgKCkge1xyXG4gICAgICAgIHRoaXMubmV4dEJ0bi5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0VORCx0aGlzLm9uTmV4dEJ0bkNsaWNrZWQsdGhpcyk7XHJcbiAgICAgICAgdGhpcy5iYWNrQnRuLm5vZGUub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELHRoaXMub25CYWNrQnRuQ2xpY2tlZCx0aGlzKTtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLyoqXHJcbiAgICAgKiBAcGFyYW0gb3B0c1xyXG4gICAgICogbmV4dENCIOS4i+S4gOWxgOaMiemSruWbnuiwg1xyXG4gICAgICogYmFja0NCIOmHjeeOqeacrOWFs+aMiemSruWbnuiwg1xyXG4gICAgICovXHJcbiAgICAgc2hvdzogZnVuY3Rpb24gKG9wdHMpIHtcclxuICAgICAgICBvcHRzID0gb3B0cyB8fCB7fTtcclxuICAgICAgICBpZihvcHRzLm5leHRDQil7XHJcbiAgICAgICAgICAgIHRoaXMubmV4dEJ0bkNhbGxiYWNrID0gb3B0cy5uZXh0Q0I7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlmKG9wdHMuYmFja0NCKXtcclxuICAgICAgICAgICAgdGhpcy5iYWNrQnRuQ2FsbGJhY2sgPSBvcHRzLmJhY2tDQjtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYob3B0cy5pbmZvKXtcclxuICAgICAgICAgICAgdGhpcy5pbmZvID0gb3B0cy5pbmZvO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZihvcHRzLmNvbmZpZyl7XHJcbiAgICAgICAgICAgIGlmKHRoaXMuaW5mby5pc1dpbil7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnJlc3VsdENvbmZpZyA9IG9wdHMuY29uZmlnLndpbjtcclxuICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICB0aGlzLnJlc3VsdENvbmZpZyA9IG9wdHMuY29uZmlnLmZhaWw7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgdGhpcy5yZWZyZXNoVUkoKTtcclxuICAgIH0sXHJcblxyXG4gICAgcmVmcmVzaFVJKCl7XHJcbiAgICAgICAgaWYodGhpcy5pbmZvKXtcclxuICAgICAgICAgICAgdGhpcy50aXRsZS5zdHJpbmcgPSB0aGlzLmluZm8uaXNXaW4/dGhpcy5yZXN1bHRDb25maWcudGl0bGU6dGhpcy5yZXN1bHRDb25maWcudGl0bGU7XHJcbiAgICAgICAgICAgIHRoaXMuY29udGVudExhYmVsLnN0cmluZyA9IHRoaXMuaW5mby5pc1dpbj90aGlzLnJlc3VsdENvbmZpZy5jb250ZW50OnRoaXMucmVzdWx0Q29uZmlnLmNvbnRlbnQ7XHJcblxyXG4gICAgICAgICAgICB0aGlzLm5leHRCdG4ubm9kZS5nZXRDaGlsZEJ5TmFtZSgnQmFja2dyb3VuZCcpLmdldENoaWxkQnlOYW1lKCdOZXcgTGFiZWwnKS5nZXRDb21wb25lbnQoY2MuTGFiZWwpLnN0cmluZyA9IHRoaXMucmVzdWx0Q29uZmlnLmJ0bjEubmFtZTtcclxuICAgICAgICAgICAgdGhpcy5iYWNrQnRuLm5vZGUuZ2V0Q2hpbGRCeU5hbWUoJ0JhY2tncm91bmQnKS5nZXRDaGlsZEJ5TmFtZSgnTmV3IExhYmVsJykuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKS5zdHJpbmcgPSB0aGlzLnJlc3VsdENvbmZpZy5idG4yLm5hbWU7XHJcblxyXG4gICAgICAgICAgICB0aGlzLm5leHRCdG4ubm9kZS5nZXRDaGlsZEJ5TmFtZSgnQmFja2dyb3VuZCcpLmdldENoaWxkQnlOYW1lKCdpY29uJykuYWN0aXZlID0gdGhpcy5yZXN1bHRDb25maWcuYnRuMS5pY29uO1xyXG4gICAgICAgICAgICB0aGlzLmJhY2tCdG4ubm9kZS5nZXRDaGlsZEJ5TmFtZSgnQmFja2dyb3VuZCcpLmdldENoaWxkQnlOYW1lKCdpY29uJykuYWN0aXZlID0gdGhpcy5yZXN1bHRDb25maWcuYnRuMi5pY29uO1xyXG4gICAgICAgIH1cclxuICAgICAgICBpZihhcHBHYW1lLmludGVyc3RpdGlhbEFkKXtcclxuICAgICAgICAgICAgYXBwR2FtZS5pbnRlcnN0aXRpYWxBZC5wbGF5QWQoKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgYXBwR2FtZS5iYW5uZXIucGxheUJhbm5lcigyKTtcclxuICAgIH0sXHJcblxyXG4gICAgb25OZXh0QnRuQ2xpY2tlZChldmVudCl7XHJcbiAgICAgICAgbGV0IGlzUGxheVZpZGVvID0gZmFsc2U7XHJcbiAgICAgICAgbGV0IGlzRm9yY2UgPSB0cnVlO1xyXG4gICAgICAgIGlmKHRoaXMucmVzdWx0Q29uZmlnKXtcclxuICAgICAgICAgICAgaXNQbGF5VmlkZW8gPSB0aGlzLnJlc3VsdENvbmZpZy5idG4xLnZpZGVvO1xyXG4gICAgICAgICAgICBpc0ZvcmNlID0gdGhpcy5yZXN1bHRDb25maWcuYnRuMS5mb3JjZTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYoaXNQbGF5VmlkZW8pe1xyXG4gICAgICAgICAgICBhcHBHYW1lLnZpZGVvQmFubmVyLnBsYXlWaWRlb0FkKGlzRm9yY2UsZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgIHRoaXMubmV4dEJ0bkNhbGxiYWNrICYmIHRoaXMubmV4dEJ0bkNhbGxiYWNrKHRoaXMuaW5mby5pc1dpbik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmhpZGUoKTtcclxuICAgICAgICAgICAgfS5iaW5kKHRoaXMpKTtcclxuICAgICAgICB9ZWxzZXtcclxuICAgICAgICAgICAgdGhpcy5uZXh0QnRuQ2FsbGJhY2sgJiYgdGhpcy5uZXh0QnRuQ2FsbGJhY2sodGhpcy5pbmZvLmlzV2luKTtcclxuICAgICAgICAgICAgdGhpcy5oaWRlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBvbkJhY2tCdG5DbGlja2VkKGV2ZW50KXtcclxuICAgICAgICBsZXQgaXNQbGF5VmlkZW8gPSBmYWxzZTtcclxuICAgICAgICBsZXQgaXNGb3JjZSA9IHRydWU7XHJcbiAgICAgICAgaWYodGhpcy5yZXN1bHRDb25maWcpe1xyXG4gICAgICAgICAgICBpc1BsYXlWaWRlbyA9IHRoaXMucmVzdWx0Q29uZmlnLmJ0bjIudmlkZW87XHJcbiAgICAgICAgICAgIGlzRm9yY2UgPSB0aGlzLnJlc3VsdENvbmZpZy5idG4yLmZvcmNlO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgICAgICBpZihpc1BsYXlWaWRlbyl7Ly/phY3nva7pnIDopoHmkq3mlL7op4bpopFcclxuICAgICAgICAgICAgYXBwR2FtZS52aWRlb0Jhbm5lci5wbGF5VmlkZW9BZChpc0ZvcmNlLGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIueci+inhumikeaIkOWKn1wiKVxyXG4gICAgICAgICAgICAgICAgdGhpcy5iYWNrQnRuQ2FsbGJhY2sgJiYgdGhpcy5iYWNrQnRuQ2FsbGJhY2sodGhpcy5pbmZvLmlzV2luKTtcclxuICAgICAgICAgICAgICAgIHRoaXMuaGlkZSgpO1xyXG4gICAgICAgICAgICB9LmJpbmQodGhpcykpO1xyXG4gICAgICAgIH1lbHNley8v5LiN55So5pKt5pS+6KeG6aKRXHJcbiAgICAgICAgICAgIHRoaXMuYmFja0J0bkNhbGxiYWNrICYmIHRoaXMuYmFja0J0bkNhbGxiYWNrKHRoaXMuaW5mby5pc1dpbik7XHJcbiAgICAgICAgICAgIHRoaXMuaGlkZSgpO1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBoaWRlKCl7XHJcbiAgICAgICAgYXBwR2FtZS5iYW5uZXIucGxheUJhbm5lcigzKTtcclxuICAgICAgICB0aGlzLm5vZGUucmVtb3ZlRnJvbVBhcmVudCgpO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/gameComon/scripts/item.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '37e7b3Qh2JMQ5/8DSX2ow5C', 'item');
// gameComon/scripts/item.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {},
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    cc.log("item onLoad");
    this.node.active = false;
  },
  start: function start() {},
  init: function init(id) {
    cc.log("item init");

    if (appGame.gameServerRoom.commonConfig && appGame.gameServerRoom.commonConfig.item) {
      underscore.each(appGame.gameServerRoom.commonConfig.item, function (key, value) {
        if (key.id == id) {
          util.loadBundleSprite(key.bundle, key.sprite, this.node.getComponent(cc.Sprite), function () {
            this.node.active = true;
          }.bind(this));
        }
      }.bind(this));
    }
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcZ2FtZUNvbW9uXFxzY3JpcHRzXFxpdGVtLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwib25Mb2FkIiwibG9nIiwibm9kZSIsImFjdGl2ZSIsInN0YXJ0IiwiaW5pdCIsImlkIiwiYXBwR2FtZSIsImdhbWVTZXJ2ZXJSb29tIiwiY29tbW9uQ29uZmlnIiwiaXRlbSIsInVuZGVyc2NvcmUiLCJlYWNoIiwia2V5IiwidmFsdWUiLCJ1dGlsIiwibG9hZEJ1bmRsZVNwcml0ZSIsImJ1bmRsZSIsInNwcml0ZSIsImdldENvbXBvbmVudCIsIlNwcml0ZSIsImJpbmQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRSxFQUhQO0FBT0w7QUFFQUMsRUFBQUEsTUFUSyxvQkFTSztBQUNOSixJQUFBQSxFQUFFLENBQUNLLEdBQUgsQ0FBTyxhQUFQO0FBQ0EsU0FBS0MsSUFBTCxDQUFVQyxNQUFWLEdBQW1CLEtBQW5CO0FBQ0gsR0FaSTtBQWNMQyxFQUFBQSxLQWRLLG1CQWNJLENBRVIsQ0FoQkk7QUFpQkxDLEVBQUFBLElBakJLLGdCQWlCQUMsRUFqQkEsRUFpQkc7QUFDSlYsSUFBQUEsRUFBRSxDQUFDSyxHQUFILENBQU8sV0FBUDs7QUFDQSxRQUFHTSxPQUFPLENBQUNDLGNBQVIsQ0FBdUJDLFlBQXZCLElBQXVDRixPQUFPLENBQUNDLGNBQVIsQ0FBdUJDLFlBQXZCLENBQW9DQyxJQUE5RSxFQUFtRjtBQUMvRUMsTUFBQUEsVUFBVSxDQUFDQyxJQUFYLENBQWdCTCxPQUFPLENBQUNDLGNBQVIsQ0FBdUJDLFlBQXZCLENBQW9DQyxJQUFwRCxFQUF5RCxVQUFTRyxHQUFULEVBQWFDLEtBQWIsRUFBbUI7QUFDeEUsWUFBR0QsR0FBRyxDQUFDUCxFQUFKLElBQVVBLEVBQWIsRUFBZ0I7QUFDWlMsVUFBQUEsSUFBSSxDQUFDQyxnQkFBTCxDQUFzQkgsR0FBRyxDQUFDSSxNQUExQixFQUFpQ0osR0FBRyxDQUFDSyxNQUFyQyxFQUE0QyxLQUFLaEIsSUFBTCxDQUFVaUIsWUFBVixDQUF1QnZCLEVBQUUsQ0FBQ3dCLE1BQTFCLENBQTVDLEVBQThFLFlBQVU7QUFDcEYsaUJBQUtsQixJQUFMLENBQVVDLE1BQVYsR0FBbUIsSUFBbkI7QUFDSCxXQUY2RSxDQUU1RWtCLElBRjRFLENBRXZFLElBRnVFLENBQTlFO0FBR0g7QUFDSixPQU53RCxDQU12REEsSUFOdUQsQ0FNbEQsSUFOa0QsQ0FBekQ7QUFPSDtBQUNKLEdBNUJJLENBOEJMOztBQTlCSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG5cclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuICAgICAgICBjYy5sb2coXCJpdGVtIG9uTG9hZFwiKVxyXG4gICAgICAgIHRoaXMubm9kZS5hY3RpdmUgPSBmYWxzZTtcclxuICAgIH0sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG4gICAgICAgIFxyXG4gICAgfSxcclxuICAgIGluaXQoaWQpe1xyXG4gICAgICAgIGNjLmxvZyhcIml0ZW0gaW5pdFwiKVxyXG4gICAgICAgIGlmKGFwcEdhbWUuZ2FtZVNlcnZlclJvb20uY29tbW9uQ29uZmlnICYmIGFwcEdhbWUuZ2FtZVNlcnZlclJvb20uY29tbW9uQ29uZmlnLml0ZW0pe1xyXG4gICAgICAgICAgICB1bmRlcnNjb3JlLmVhY2goYXBwR2FtZS5nYW1lU2VydmVyUm9vbS5jb21tb25Db25maWcuaXRlbSxmdW5jdGlvbihrZXksdmFsdWUpe1xyXG4gICAgICAgICAgICAgICAgaWYoa2V5LmlkID09IGlkKXtcclxuICAgICAgICAgICAgICAgICAgICB1dGlsLmxvYWRCdW5kbGVTcHJpdGUoa2V5LmJ1bmRsZSxrZXkuc3ByaXRlLHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuU3ByaXRlKSxmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLm5vZGUuYWN0aXZlID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgICAgICB9LmJpbmQodGhpcykpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LmJpbmQodGhpcykpO1xyXG4gICAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/gameComon/scripts/roomGame.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'beb9925+ZFD6pMLNAwAhYoo', 'roomGame');
// gameComon/scripts/roomGame.js

"use strict";

/*游戏配置文件获取*/
var Room = require('room');

var consts = require('./model/consts');

var RoomGame = cc.Class({
  "extends": Room,
  statics: {
    create: function create(data) {
      var roomObj = new RoomGame();
      roomObj.initWithData(data);
      return roomObj;
    }
  },
  initWithData: function initWithData(data) {
    this._super(data.room); //录屏路径


    this.videoPath = ''; //获取录屏的系统时间

    this.screenTime = 0;
    this.gameConfigData = {};
    this.wordRid = '';
    this.configSuccess2 = false;
    var url = consts.HTTP_GET_PAAS_DATA_SERVER + "?gameId=" + consts.GAME_ID + "&plat=" + appGame.platform + "&version=" + appGame.packageVersion + "&brand=" + '' + "&from=game";
    console.log("roomgame url===" + url); //let url = "https://cs.snmi.cn/switch/GetGameValue?gameId=10&userId=42239347-c1d9-8fff-543a-d748941d4ce0&tag=1&plat=toutiao&version=1.0.3&failtimes=0&winpasstimes=0"

    httpUtils.httpSendRequest(url, function (res) {
      console.log("roomgame ==" + JSON.stringify(res));

      if (res && res.Code == 200) {
        var detailparse = JSON.parse(res.Detail);

        if (detailparse) {
          console.log("word==========" + detailparse.word);
          this.gameConfigData = detailparse;
          this.isGameStart = true;
        }

        this.configSuccess2 = true;

        if (this.configSuccess2 && this.configSuccess1) {
          appGame.gameServerRoom.emit(consts.CLIENT_GAME_START, {});
        }
      } else {
        util.loadJSONData('json', "game", function (data) {
          this.gameConfigData = data;
          this.isGameStart = true;
          this.configSuccess2 = true;

          if (this.configSuccess2 && this.configSuccess1) {
            appGame.gameServerRoom.emit(consts.CLIENT_GAME_START, {});
          }
        }.bind(this));
      }
    }.bind(this)); // util.loadJSONData('json',"game",function(data){
    //     cc.log("data=="+JSON.stringify(data))
    //     this.gameConfigData = data;
    //     if(this.configSuccess2 && this.configSuccess1){
    //         appGame.gameServerRoom.emit(consts.CLIENT_GAME_START,{});
    //     }
    // }.bind(this));
  }
});
module.exports = RoomGame;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcZ2FtZUNvbW9uXFxzY3JpcHRzXFxyb29tR2FtZS5qcyJdLCJuYW1lcyI6WyJSb29tIiwicmVxdWlyZSIsImNvbnN0cyIsIlJvb21HYW1lIiwiY2MiLCJDbGFzcyIsInN0YXRpY3MiLCJjcmVhdGUiLCJkYXRhIiwicm9vbU9iaiIsImluaXRXaXRoRGF0YSIsIl9zdXBlciIsInJvb20iLCJ2aWRlb1BhdGgiLCJzY3JlZW5UaW1lIiwiZ2FtZUNvbmZpZ0RhdGEiLCJ3b3JkUmlkIiwiY29uZmlnU3VjY2VzczIiLCJ1cmwiLCJIVFRQX0dFVF9QQUFTX0RBVEFfU0VSVkVSIiwiR0FNRV9JRCIsImFwcEdhbWUiLCJwbGF0Zm9ybSIsInBhY2thZ2VWZXJzaW9uIiwiY29uc29sZSIsImxvZyIsImh0dHBVdGlscyIsImh0dHBTZW5kUmVxdWVzdCIsInJlcyIsIkpTT04iLCJzdHJpbmdpZnkiLCJDb2RlIiwiZGV0YWlscGFyc2UiLCJwYXJzZSIsIkRldGFpbCIsIndvcmQiLCJpc0dhbWVTdGFydCIsImNvbmZpZ1N1Y2Nlc3MxIiwiZ2FtZVNlcnZlclJvb20iLCJlbWl0IiwiQ0xJRU5UX0dBTUVfU1RBUlQiLCJ1dGlsIiwibG9hZEpTT05EYXRhIiwiYmluZCIsIm1vZHVsZSIsImV4cG9ydHMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQSxJQUFJQSxJQUFJLEdBQUdDLE9BQU8sQ0FBQyxNQUFELENBQWxCOztBQUNBLElBQU1DLE1BQU0sR0FBR0QsT0FBTyxDQUFDLGdCQUFELENBQXRCOztBQUNBLElBQUlFLFFBQVEsR0FBR0MsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDcEIsYUFBU0wsSUFEVztBQUdwQk0sRUFBQUEsT0FBTyxFQUFFO0FBQ0xDLElBQUFBLE1BQU0sRUFBRSxnQkFBVUMsSUFBVixFQUFnQjtBQUNwQixVQUFJQyxPQUFPLEdBQUcsSUFBSU4sUUFBSixFQUFkO0FBQ0FNLE1BQUFBLE9BQU8sQ0FBQ0MsWUFBUixDQUFxQkYsSUFBckI7QUFDQSxhQUFPQyxPQUFQO0FBQ0g7QUFMSSxHQUhXO0FBVXBCQyxFQUFBQSxZQUFZLEVBQUUsc0JBQVVGLElBQVYsRUFBZ0I7QUFDMUIsU0FBS0csTUFBTCxDQUFZSCxJQUFJLENBQUNJLElBQWpCLEVBRDBCLENBRTFCOzs7QUFDQSxTQUFLQyxTQUFMLEdBQWlCLEVBQWpCLENBSDBCLENBSTFCOztBQUNBLFNBQUtDLFVBQUwsR0FBa0IsQ0FBbEI7QUFDQSxTQUFLQyxjQUFMLEdBQXNCLEVBQXRCO0FBQ0EsU0FBS0MsT0FBTCxHQUFlLEVBQWY7QUFDQSxTQUFLQyxjQUFMLEdBQXNCLEtBQXRCO0FBQ0EsUUFBSUMsR0FBRyxHQUFHaEIsTUFBTSxDQUFDaUIseUJBQVAsR0FBaUMsVUFBakMsR0FBNENqQixNQUFNLENBQUNrQixPQUFuRCxHQUEyRCxRQUEzRCxHQUFvRUMsT0FBTyxDQUFDQyxRQUE1RSxHQUNULFdBRFMsR0FDR0QsT0FBTyxDQUFDRSxjQURYLEdBQzBCLFNBRDFCLEdBQ29DLEVBRHBDLEdBQ3VDLFlBRGpEO0FBRUFDLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLG9CQUFrQlAsR0FBOUIsRUFYMEIsQ0FZMUI7O0FBQ0FRLElBQUFBLFNBQVMsQ0FBQ0MsZUFBVixDQUEwQlQsR0FBMUIsRUFBOEIsVUFBU1UsR0FBVCxFQUFhO0FBQ3ZDSixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxnQkFBY0ksSUFBSSxDQUFDQyxTQUFMLENBQWVGLEdBQWYsQ0FBMUI7O0FBQ0EsVUFBR0EsR0FBRyxJQUFJQSxHQUFHLENBQUNHLElBQUosSUFBWSxHQUF0QixFQUEwQjtBQUN0QixZQUFJQyxXQUFXLEdBQUdILElBQUksQ0FBQ0ksS0FBTCxDQUFXTCxHQUFHLENBQUNNLE1BQWYsQ0FBbEI7O0FBQ0EsWUFBR0YsV0FBSCxFQUFlO0FBQ1hSLFVBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLG1CQUFpQk8sV0FBVyxDQUFDRyxJQUF6QztBQUNBLGVBQUtwQixjQUFMLEdBQXNCaUIsV0FBdEI7QUFDQSxlQUFLSSxXQUFMLEdBQW1CLElBQW5CO0FBQ0g7O0FBQ0QsYUFBS25CLGNBQUwsR0FBc0IsSUFBdEI7O0FBQ0EsWUFBRyxLQUFLQSxjQUFMLElBQXVCLEtBQUtvQixjQUEvQixFQUE4QztBQUMxQ2hCLFVBQUFBLE9BQU8sQ0FBQ2lCLGNBQVIsQ0FBdUJDLElBQXZCLENBQTRCckMsTUFBTSxDQUFDc0MsaUJBQW5DLEVBQXFELEVBQXJEO0FBQ0g7QUFDSixPQVhELE1BV0s7QUFDREMsUUFBQUEsSUFBSSxDQUFDQyxZQUFMLENBQWtCLE1BQWxCLEVBQXlCLE1BQXpCLEVBQWdDLFVBQVNsQyxJQUFULEVBQWM7QUFDMUMsZUFBS08sY0FBTCxHQUFzQlAsSUFBdEI7QUFDQSxlQUFLNEIsV0FBTCxHQUFtQixJQUFuQjtBQUNBLGVBQUtuQixjQUFMLEdBQXNCLElBQXRCOztBQUNBLGNBQUcsS0FBS0EsY0FBTCxJQUF1QixLQUFLb0IsY0FBL0IsRUFBOEM7QUFDMUNoQixZQUFBQSxPQUFPLENBQUNpQixjQUFSLENBQXVCQyxJQUF2QixDQUE0QnJDLE1BQU0sQ0FBQ3NDLGlCQUFuQyxFQUFxRCxFQUFyRDtBQUNIO0FBQ0osU0FQK0IsQ0FPOUJHLElBUDhCLENBT3pCLElBUHlCLENBQWhDO0FBUUg7QUFDSixLQXZCNkIsQ0F1QjVCQSxJQXZCNEIsQ0F1QnZCLElBdkJ1QixDQUE5QixFQWIwQixDQXNDMUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDSDtBQXZEbUIsQ0FBVCxDQUFmO0FBMERBQyxNQUFNLENBQUNDLE9BQVAsR0FBaUIxQyxRQUFqQiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLyrmuLjmiI/phY3nva7mlofku7bojrflj5YqL1xyXG52YXIgUm9vbSA9IHJlcXVpcmUoJ3Jvb20nKTtcclxuY29uc3QgY29uc3RzID0gcmVxdWlyZSgnLi9tb2RlbC9jb25zdHMnKTtcclxudmFyIFJvb21HYW1lID0gY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogUm9vbSxcclxuXHJcbiAgICBzdGF0aWNzOiB7XHJcbiAgICAgICAgY3JlYXRlOiBmdW5jdGlvbiAoZGF0YSkge1xyXG4gICAgICAgICAgICBsZXQgcm9vbU9iaiA9IG5ldyBSb29tR2FtZSgpO1xyXG4gICAgICAgICAgICByb29tT2JqLmluaXRXaXRoRGF0YShkYXRhKTtcclxuICAgICAgICAgICAgcmV0dXJuIHJvb21PYmo7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGluaXRXaXRoRGF0YTogZnVuY3Rpb24gKGRhdGEpIHtcclxuICAgICAgICB0aGlzLl9zdXBlcihkYXRhLnJvb20pO1xyXG4gICAgICAgIC8v5b2V5bGP6Lev5b6EXHJcbiAgICAgICAgdGhpcy52aWRlb1BhdGggPSAnJztcclxuICAgICAgICAvL+iOt+WPluW9leWxj+eahOezu+e7n+aXtumXtFxyXG4gICAgICAgIHRoaXMuc2NyZWVuVGltZSA9IDA7XHJcbiAgICAgICAgdGhpcy5nYW1lQ29uZmlnRGF0YSA9IHt9O1xyXG4gICAgICAgIHRoaXMud29yZFJpZCA9ICcnO1xyXG4gICAgICAgIHRoaXMuY29uZmlnU3VjY2VzczIgPSBmYWxzZTtcclxuICAgICAgICBsZXQgdXJsID0gY29uc3RzLkhUVFBfR0VUX1BBQVNfREFUQV9TRVJWRVIrXCI/Z2FtZUlkPVwiK2NvbnN0cy5HQU1FX0lEK1wiJnBsYXQ9XCIrYXBwR2FtZS5wbGF0Zm9ybVxyXG4gICAgICAgICtcIiZ2ZXJzaW9uPVwiK2FwcEdhbWUucGFja2FnZVZlcnNpb24rXCImYnJhbmQ9XCIrJycrXCImZnJvbT1nYW1lXCI7XHJcbiAgICAgICAgY29uc29sZS5sb2coXCJyb29tZ2FtZSB1cmw9PT1cIit1cmwpXHJcbiAgICAgICAgLy9sZXQgdXJsID0gXCJodHRwczovL2NzLnNubWkuY24vc3dpdGNoL0dldEdhbWVWYWx1ZT9nYW1lSWQ9MTAmdXNlcklkPTQyMjM5MzQ3LWMxZDktOGZmZi01NDNhLWQ3NDg5NDFkNGNlMCZ0YWc9MSZwbGF0PXRvdXRpYW8mdmVyc2lvbj0xLjAuMyZmYWlsdGltZXM9MCZ3aW5wYXNzdGltZXM9MFwiXHJcbiAgICAgICAgaHR0cFV0aWxzLmh0dHBTZW5kUmVxdWVzdCh1cmwsZnVuY3Rpb24ocmVzKXtcclxuICAgICAgICAgICAgY29uc29sZS5sb2coXCJyb29tZ2FtZSA9PVwiK0pTT04uc3RyaW5naWZ5KHJlcykpXHJcbiAgICAgICAgICAgIGlmKHJlcyAmJiByZXMuQ29kZSA9PSAyMDApe1xyXG4gICAgICAgICAgICAgICAgbGV0IGRldGFpbHBhcnNlID0gSlNPTi5wYXJzZShyZXMuRGV0YWlsKVxyXG4gICAgICAgICAgICAgICAgaWYoZGV0YWlscGFyc2Upe1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwid29yZD09PT09PT09PT1cIitkZXRhaWxwYXJzZS53b3JkKVxyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ2FtZUNvbmZpZ0RhdGEgPSBkZXRhaWxwYXJzZTtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmlzR2FtZVN0YXJ0ID0gdHJ1ZTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIHRoaXMuY29uZmlnU3VjY2VzczIgPSB0cnVlO1xyXG4gICAgICAgICAgICAgICAgaWYodGhpcy5jb25maWdTdWNjZXNzMiAmJiB0aGlzLmNvbmZpZ1N1Y2Nlc3MxKXtcclxuICAgICAgICAgICAgICAgICAgICBhcHBHYW1lLmdhbWVTZXJ2ZXJSb29tLmVtaXQoY29uc3RzLkNMSUVOVF9HQU1FX1NUQVJULHt9KTtcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICB1dGlsLmxvYWRKU09ORGF0YSgnanNvbicsXCJnYW1lXCIsZnVuY3Rpb24oZGF0YSl7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5nYW1lQ29uZmlnRGF0YSA9IGRhdGE7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5pc0dhbWVTdGFydCA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5jb25maWdTdWNjZXNzMiA9IHRydWU7XHJcbiAgICAgICAgICAgICAgICAgICAgaWYodGhpcy5jb25maWdTdWNjZXNzMiAmJiB0aGlzLmNvbmZpZ1N1Y2Nlc3MxKXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgYXBwR2FtZS5nYW1lU2VydmVyUm9vbS5lbWl0KGNvbnN0cy5DTElFTlRfR0FNRV9TVEFSVCx7fSk7XHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfS5iaW5kKHRoaXMpKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0uYmluZCh0aGlzKSk7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8gdXRpbC5sb2FkSlNPTkRhdGEoJ2pzb24nLFwiZ2FtZVwiLGZ1bmN0aW9uKGRhdGEpe1xyXG4gICAgICAgIC8vICAgICBjYy5sb2coXCJkYXRhPT1cIitKU09OLnN0cmluZ2lmeShkYXRhKSlcclxuICAgICAgICAvLyAgICAgdGhpcy5nYW1lQ29uZmlnRGF0YSA9IGRhdGE7XHJcbiAgICAgICAgLy8gICAgIGlmKHRoaXMuY29uZmlnU3VjY2VzczIgJiYgdGhpcy5jb25maWdTdWNjZXNzMSl7XHJcbiAgICAgICAgLy8gICAgICAgICBhcHBHYW1lLmdhbWVTZXJ2ZXJSb29tLmVtaXQoY29uc3RzLkNMSUVOVF9HQU1FX1NUQVJULHt9KTtcclxuICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgIC8vIH0uYmluZCh0aGlzKSk7XHJcbiAgICB9LFxyXG59KTtcclxuXHJcbm1vZHVsZS5leHBvcnRzID0gUm9vbUdhbWU7XHJcbiJdfQ==
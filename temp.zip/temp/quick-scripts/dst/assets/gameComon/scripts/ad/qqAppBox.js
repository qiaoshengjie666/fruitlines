
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/gameComon/scripts/ad/qqAppBox.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '348eeAr679Oq75aKnlLmZ1c', 'qqAppBox');
// gameComon/scripts/ad/qqAppBox.js

"use strict";

var QQAppBOX = cc.Class({
  "extends": cc.Component,
  properties: {},
  ctor: function ctor() {
    this.instance = null;
  },
  statics: {
    create: function create(data) {
      if (!this.instance) {
        this.instance = new QQAppBOX();
        this.instance.initWithData(data);
        return this.instance;
      }
    }
  },
  initWithData: function initWithData(data) {
    this.boxId = '';

    if (cc.sys.platform == cc.sys.WECHAT_GAME && appGame.platform == 'QQ') {
      //QQ  
      var res = qq.getSystemInfoSync();
      this.width = res.windowWidth;
      this.height = res.windowHeight;
      var Version2 = util.compareVersion(res.SDKVersion, "1.7.1");

      if (Version2 > 0) {
        this.boxId = "686b9ffc40992b21d352e841f3bb2085";

        if (appGame.gameServerRoom.gameConfigData && appGame.gameServerRoom.gameConfigData.boxId && appGame.gameServerRoom.gameConfigData.boxId.QQ) {
          this.boxId = appGame.gameServerRoom.gameConfigData.boxId.QQ.adUnitId;
        }

        this.globalData = {
          appbox: qq.createAppBox({
            adUnitId: this.boxId
          })
        };
      } else {
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
          title: '广告盒子',
          content: '基础库版本太低不创建广告盒子'
        }, function () {});
      }
    }
  },
  playBox: function playBox(show) {
    var _this = this;

    if (this.globalData && this.globalData.appbox) {
      if (show) {
        this.globalData.appbox.load().then(function () {
          _this.globalData.appbox.show();

          httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
            title: '广告盒子',
            content: '展示'
          }, function () {});
        });
      } else {
        this.globalData.appbox.destroy();
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
          title: '广告盒子',
          content: '隐藏'
        }, function () {});
      }
    }
  }
});
module.exports = QQAppBOX;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcZ2FtZUNvbW9uXFxzY3JpcHRzXFxhZFxccXFBcHBCb3guanMiXSwibmFtZXMiOlsiUVFBcHBCT1giLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImN0b3IiLCJpbnN0YW5jZSIsInN0YXRpY3MiLCJjcmVhdGUiLCJkYXRhIiwiaW5pdFdpdGhEYXRhIiwiYm94SWQiLCJzeXMiLCJwbGF0Zm9ybSIsIldFQ0hBVF9HQU1FIiwiYXBwR2FtZSIsInJlcyIsInFxIiwiZ2V0U3lzdGVtSW5mb1N5bmMiLCJ3aWR0aCIsIndpbmRvd1dpZHRoIiwiaGVpZ2h0Iiwid2luZG93SGVpZ2h0IiwiVmVyc2lvbjIiLCJ1dGlsIiwiY29tcGFyZVZlcnNpb24iLCJTREtWZXJzaW9uIiwiZ2FtZVNlcnZlclJvb20iLCJnYW1lQ29uZmlnRGF0YSIsIlFRIiwiYWRVbml0SWQiLCJnbG9iYWxEYXRhIiwiYXBwYm94IiwiY3JlYXRlQXBwQm94IiwiaHR0cFV0aWxzIiwiaHR0cFBvc3QiLCJjb25zdHMiLCJIVFRQX1JFQ09SRF9TRVJWRVIiLCJ0aXRsZSIsImNvbnRlbnQiLCJwbGF5Qm94Iiwic2hvdyIsImxvYWQiLCJ0aGVuIiwiZGVzdHJveSIsIm1vZHVsZSIsImV4cG9ydHMiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsUUFBUSxHQUFHQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNwQixhQUFTRCxFQUFFLENBQUNFLFNBRFE7QUFHcEJDLEVBQUFBLFVBQVUsRUFBRSxFQUhRO0FBS3BCQyxFQUFBQSxJQUxvQixrQkFLZDtBQUNGLFNBQUtDLFFBQUwsR0FBZ0IsSUFBaEI7QUFDSCxHQVBtQjtBQVFwQkMsRUFBQUEsT0FBTyxFQUFFO0FBQ0xDLElBQUFBLE1BQU0sRUFBRSxnQkFBVUMsSUFBVixFQUFnQjtBQUNwQixVQUFHLENBQUMsS0FBS0gsUUFBVCxFQUFrQjtBQUNkLGFBQUtBLFFBQUwsR0FBZ0IsSUFBSU4sUUFBSixFQUFoQjtBQUNBLGFBQUtNLFFBQUwsQ0FBY0ksWUFBZCxDQUEyQkQsSUFBM0I7QUFDQSxlQUFPLEtBQUtILFFBQVo7QUFDSDtBQUNKO0FBUEksR0FSVztBQWlCcEJJLEVBQUFBLFlBQVksRUFBRSxzQkFBVUQsSUFBVixFQUFnQjtBQUMxQixTQUFLRSxLQUFMLEdBQWEsRUFBYjs7QUFDQSxRQUFHVixFQUFFLENBQUNXLEdBQUgsQ0FBT0MsUUFBUCxJQUFtQlosRUFBRSxDQUFDVyxHQUFILENBQU9FLFdBQTFCLElBQXdDQyxPQUFPLENBQUNGLFFBQVIsSUFBb0IsSUFBL0QsRUFBb0U7QUFBRTtBQUNsRSxVQUFNRyxHQUFHLEdBQUdDLEVBQUUsQ0FBQ0MsaUJBQUgsRUFBWjtBQUNBLFdBQUtDLEtBQUwsR0FBYUgsR0FBRyxDQUFDSSxXQUFqQjtBQUNBLFdBQUtDLE1BQUwsR0FBY0wsR0FBRyxDQUFDTSxZQUFsQjtBQUNBLFVBQUlDLFFBQVEsR0FBR0MsSUFBSSxDQUFDQyxjQUFMLENBQW9CVCxHQUFHLENBQUNVLFVBQXhCLEVBQW1DLE9BQW5DLENBQWY7O0FBQ0EsVUFBR0gsUUFBUSxHQUFHLENBQWQsRUFBZ0I7QUFDWixhQUFLWixLQUFMLEdBQWEsa0NBQWI7O0FBQ0EsWUFBR0ksT0FBTyxDQUFDWSxjQUFSLENBQXVCQyxjQUF2QixJQUF5Q2IsT0FBTyxDQUFDWSxjQUFSLENBQXVCQyxjQUF2QixDQUFzQ2pCLEtBQS9FLElBQXdGSSxPQUFPLENBQUNZLGNBQVIsQ0FBdUJDLGNBQXZCLENBQXNDakIsS0FBdEMsQ0FBNENrQixFQUF2SSxFQUEwSTtBQUN0SSxlQUFLbEIsS0FBTCxHQUFhSSxPQUFPLENBQUNZLGNBQVIsQ0FBdUJDLGNBQXZCLENBQXNDakIsS0FBdEMsQ0FBNENrQixFQUE1QyxDQUErQ0MsUUFBNUQ7QUFDSDs7QUFDRCxhQUFLQyxVQUFMLEdBQWtCO0FBQ2RDLFVBQUFBLE1BQU0sRUFBQ2YsRUFBRSxDQUFDZ0IsWUFBSCxDQUFnQjtBQUNuQkgsWUFBQUEsUUFBUSxFQUFFLEtBQUtuQjtBQURJLFdBQWhCO0FBRE8sU0FBbEI7QUFLSCxPQVZELE1BVUs7QUFDRHVCLFFBQUFBLFNBQVMsQ0FBQ0MsUUFBVixDQUFtQkMsTUFBTSxDQUFDQyxrQkFBMUIsRUFBNkM7QUFBQ0MsVUFBQUEsS0FBSyxFQUFDLE1BQVA7QUFBY0MsVUFBQUEsT0FBTyxFQUFDO0FBQXRCLFNBQTdDLEVBQXFGLFlBQVUsQ0FBRSxDQUFqRztBQUNIO0FBQ0o7QUFDSixHQXRDbUI7QUF1Q3BCQyxFQUFBQSxPQUFPLEVBQUMsaUJBQVNDLElBQVQsRUFBYztBQUFBOztBQUNsQixRQUFHLEtBQUtWLFVBQUwsSUFBbUIsS0FBS0EsVUFBTCxDQUFnQkMsTUFBdEMsRUFBNkM7QUFDekMsVUFBR1MsSUFBSCxFQUFRO0FBQ0osYUFBS1YsVUFBTCxDQUFnQkMsTUFBaEIsQ0FBdUJVLElBQXZCLEdBQThCQyxJQUE5QixDQUFtQyxZQUFJO0FBQ25DLFVBQUEsS0FBSSxDQUFDWixVQUFMLENBQWdCQyxNQUFoQixDQUF1QlMsSUFBdkI7O0FBQ0FQLFVBQUFBLFNBQVMsQ0FBQ0MsUUFBVixDQUFtQkMsTUFBTSxDQUFDQyxrQkFBMUIsRUFBNkM7QUFBQ0MsWUFBQUEsS0FBSyxFQUFDLE1BQVA7QUFBY0MsWUFBQUEsT0FBTyxFQUFDO0FBQXRCLFdBQTdDLEVBQXlFLFlBQVUsQ0FDbEYsQ0FERDtBQUVILFNBSkQ7QUFLSCxPQU5ELE1BTUs7QUFDRCxhQUFLUixVQUFMLENBQWdCQyxNQUFoQixDQUF1QlksT0FBdkI7QUFDQVYsUUFBQUEsU0FBUyxDQUFDQyxRQUFWLENBQW1CQyxNQUFNLENBQUNDLGtCQUExQixFQUE2QztBQUFDQyxVQUFBQSxLQUFLLEVBQUMsTUFBUDtBQUFjQyxVQUFBQSxPQUFPLEVBQUM7QUFBdEIsU0FBN0MsRUFBeUUsWUFBVSxDQUNsRixDQUREO0FBRUg7QUFDSjtBQUNKO0FBckRtQixDQUFULENBQWY7QUF1REFNLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQjlDLFFBQWpCIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgUVFBcHBCT1ggPSBjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgfSxcclxuICAgIGN0b3IoKXtcclxuICAgICAgICB0aGlzLmluc3RhbmNlID0gbnVsbDtcclxuICAgIH0sXHJcbiAgICBzdGF0aWNzOiB7XHJcbiAgICAgICAgY3JlYXRlOiBmdW5jdGlvbiAoZGF0YSkge1xyXG4gICAgICAgICAgICBpZighdGhpcy5pbnN0YW5jZSl7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmluc3RhbmNlID0gbmV3IFFRQXBwQk9YKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmluc3RhbmNlLmluaXRXaXRoRGF0YShkYXRhKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmluc3RhbmNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGluaXRXaXRoRGF0YTogZnVuY3Rpb24gKGRhdGEpIHtcclxuICAgICAgICB0aGlzLmJveElkID0gJyc7XHJcbiAgICAgICAgaWYoY2Muc3lzLnBsYXRmb3JtID09IGNjLnN5cy5XRUNIQVRfR0FNRSAmJmFwcEdhbWUucGxhdGZvcm0gPT0gJ1FRJyl7IC8vUVEgIFxyXG4gICAgICAgICAgICBjb25zdCByZXMgPSBxcS5nZXRTeXN0ZW1JbmZvU3luYygpO1xyXG4gICAgICAgICAgICB0aGlzLndpZHRoID0gcmVzLndpbmRvd1dpZHRoO1xyXG4gICAgICAgICAgICB0aGlzLmhlaWdodCA9IHJlcy53aW5kb3dIZWlnaHQ7XHJcbiAgICAgICAgICAgIHZhciBWZXJzaW9uMiA9IHV0aWwuY29tcGFyZVZlcnNpb24ocmVzLlNES1ZlcnNpb24sXCIxLjcuMVwiKTtcclxuICAgICAgICAgICAgaWYoVmVyc2lvbjIgPiAwKXtcclxuICAgICAgICAgICAgICAgIHRoaXMuYm94SWQgPSBcIjY4NmI5ZmZjNDA5OTJiMjFkMzUyZTg0MWYzYmIyMDg1XCI7XHJcbiAgICAgICAgICAgICAgICBpZihhcHBHYW1lLmdhbWVTZXJ2ZXJSb29tLmdhbWVDb25maWdEYXRhICYmIGFwcEdhbWUuZ2FtZVNlcnZlclJvb20uZ2FtZUNvbmZpZ0RhdGEuYm94SWQgJiYgYXBwR2FtZS5nYW1lU2VydmVyUm9vbS5nYW1lQ29uZmlnRGF0YS5ib3hJZC5RUSl7XHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5ib3hJZCA9IGFwcEdhbWUuZ2FtZVNlcnZlclJvb20uZ2FtZUNvbmZpZ0RhdGEuYm94SWQuUVEuYWRVbml0SWQ7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB0aGlzLmdsb2JhbERhdGEgPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgYXBwYm94OnFxLmNyZWF0ZUFwcEJveCh7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFkVW5pdElkOiB0aGlzLmJveElkXHJcbiAgICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfWVsc2V7XHJcbiAgICAgICAgICAgICAgICBodHRwVXRpbHMuaHR0cFBvc3QoY29uc3RzLkhUVFBfUkVDT1JEX1NFUlZFUix7dGl0bGU6J+W5v+WRiuebkuWtkCcsY29udGVudDon5Z+656GA5bqT54mI5pys5aSq5L2O5LiN5Yib5bu65bm/5ZGK55uS5a2QJ30sZnVuY3Rpb24oKXt9KVxyXG4gICAgICAgICAgICB9ICAgIFxyXG4gICAgICAgIH0gICAgICAgXHJcbiAgICB9LFxyXG4gICAgcGxheUJveDpmdW5jdGlvbihzaG93KXtcclxuICAgICAgICBpZih0aGlzLmdsb2JhbERhdGEgJiYgdGhpcy5nbG9iYWxEYXRhLmFwcGJveCl7XHJcbiAgICAgICAgICAgIGlmKHNob3cpe1xyXG4gICAgICAgICAgICAgICAgdGhpcy5nbG9iYWxEYXRhLmFwcGJveC5sb2FkKCkudGhlbigoKT0+e1xyXG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ2xvYmFsRGF0YS5hcHBib3guc2hvdygpO1xyXG4gICAgICAgICAgICAgICAgICAgIGh0dHBVdGlscy5odHRwUG9zdChjb25zdHMuSFRUUF9SRUNPUkRfU0VSVkVSLHt0aXRsZTon5bm/5ZGK55uS5a2QJyxjb250ZW50OiflsZXnpLonfSxmdW5jdGlvbigpe1xyXG4gICAgICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgICAgdGhpcy5nbG9iYWxEYXRhLmFwcGJveC5kZXN0cm95KCk7XHJcbiAgICAgICAgICAgICAgICBodHRwVXRpbHMuaHR0cFBvc3QoY29uc3RzLkhUVFBfUkVDT1JEX1NFUlZFUix7dGl0bGU6J+W5v+WRiuebkuWtkCcsY29udGVudDon6ZqQ6JePJ30sZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59KTtcclxubW9kdWxlLmV4cG9ydHMgPSBRUUFwcEJPWDsiXX0=
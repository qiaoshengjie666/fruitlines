
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/gameComon/scripts/ad/wxgridAd.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '27d3buB6l5GlarYvR/+7For', 'wxgridAd');
// gameComon/scripts/ad/wxgridAd.js

"use strict";

var targetBannerAdWidth = 200;
var width = 100;
var height = 100;
var adId = '2b0c0dgf20nf3qe2jj';
var GridAd = cc.Class({
  properties: {},
  ctor: function ctor() {
    this.instance = null;
  },
  statics: {
    create: function create(data) {
      if (!this.instance) {
        this.instance = new GridAd();
        this.instance.initWithData(data);
        return this.instance;
      }
    }
  },
  initWithData: function initWithData(data) {
    if (cc.sys.platform == cc.sys.WECHAT_GAME && appGame.platform == 'WX') {
      var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
          windowWidth = _wx$getSystemInfoSync.windowWidth,
          windowHeight = _wx$getSystemInfoSync.windowHeight;

      this.targetBannerAdWidth = 200;
      this.width = windowWidth;
      this.height = windowHeight;
      this.adId = 'adunit-144bcfc4f8f3cefe';
      console.log("banner 第一次创建");
      this.globalData = {
        gridAd: wx.createGridAd({
          adUnitId: this.adId,
          adTheme: 'white',
          gridCount: 5,
          style: {
            left: 0,
            top: 0,
            width: 330,
            opacity: 0.8
          }
        })
      };
      this.globalData.gridAd.onError(function (res) {
        console.log('盒子广告onError', res);
      });
    }
  },
  playGridAd: function playGridAd(isShow) {
    if (isShow) {
      if (this.globalData && this.globalData.gridAd) {
        console.log("播放盒子广告");
        this.globalData.gridAd.show().then(function () {
          console.log("盒子广告展示成功");
        });
      }
    } else {
      this.globalData.gridAd.hide();
    }
  }
});
module.exports = GridAd;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcZ2FtZUNvbW9uXFxzY3JpcHRzXFxhZFxcd3hncmlkQWQuanMiXSwibmFtZXMiOlsidGFyZ2V0QmFubmVyQWRXaWR0aCIsIndpZHRoIiwiaGVpZ2h0IiwiYWRJZCIsIkdyaWRBZCIsImNjIiwiQ2xhc3MiLCJwcm9wZXJ0aWVzIiwiY3RvciIsImluc3RhbmNlIiwic3RhdGljcyIsImNyZWF0ZSIsImRhdGEiLCJpbml0V2l0aERhdGEiLCJzeXMiLCJwbGF0Zm9ybSIsIldFQ0hBVF9HQU1FIiwiYXBwR2FtZSIsInd4IiwiZ2V0U3lzdGVtSW5mb1N5bmMiLCJ3aW5kb3dXaWR0aCIsIndpbmRvd0hlaWdodCIsImNvbnNvbGUiLCJsb2ciLCJnbG9iYWxEYXRhIiwiZ3JpZEFkIiwiY3JlYXRlR3JpZEFkIiwiYWRVbml0SWQiLCJhZFRoZW1lIiwiZ3JpZENvdW50Iiwic3R5bGUiLCJsZWZ0IiwidG9wIiwib3BhY2l0eSIsIm9uRXJyb3IiLCJyZXMiLCJwbGF5R3JpZEFkIiwiaXNTaG93Iiwic2hvdyIsInRoZW4iLCJoaWRlIiwibW9kdWxlIiwiZXhwb3J0cyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFJQSxtQkFBbUIsR0FBRyxHQUExQjtBQUNBLElBQUlDLEtBQUssR0FBRyxHQUFaO0FBQ0EsSUFBSUMsTUFBTSxHQUFHLEdBQWI7QUFDQSxJQUFJQyxJQUFJLEdBQUcsb0JBQVg7QUFDQSxJQUFJQyxNQUFNLEdBQUdDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ2xCQyxFQUFBQSxVQUFVLEVBQUUsRUFETTtBQUdsQkMsRUFBQUEsSUFIa0Isa0JBR1g7QUFDSCxTQUFLQyxRQUFMLEdBQWdCLElBQWhCO0FBQ0gsR0FMaUI7QUFNbEJDLEVBQUFBLE9BQU8sRUFBRTtBQUNMQyxJQUFBQSxNQUFNLEVBQUUsZ0JBQVVDLElBQVYsRUFBZ0I7QUFDcEIsVUFBSSxDQUFDLEtBQUtILFFBQVYsRUFBb0I7QUFDaEIsYUFBS0EsUUFBTCxHQUFnQixJQUFJTCxNQUFKLEVBQWhCO0FBQ0EsYUFBS0ssUUFBTCxDQUFjSSxZQUFkLENBQTJCRCxJQUEzQjtBQUNBLGVBQU8sS0FBS0gsUUFBWjtBQUNIO0FBQ0o7QUFQSSxHQU5TO0FBZWxCSSxFQUFBQSxZQUFZLEVBQUUsc0JBQVVELElBQVYsRUFBZ0I7QUFDMUIsUUFBSVAsRUFBRSxDQUFDUyxHQUFILENBQU9DLFFBQVAsSUFBbUJWLEVBQUUsQ0FBQ1MsR0FBSCxDQUFPRSxXQUExQixJQUF5Q0MsT0FBTyxDQUFDRixRQUFSLElBQW9CLElBQWpFLEVBQXVFO0FBQUEsa0NBQzdCRyxFQUFFLENBQUNDLGlCQUFILEVBRDZCO0FBQUEsVUFDM0RDLFdBRDJELHlCQUMzREEsV0FEMkQ7QUFBQSxVQUM5Q0MsWUFEOEMseUJBQzlDQSxZQUQ4Qzs7QUFFbkUsV0FBS3JCLG1CQUFMLEdBQTJCLEdBQTNCO0FBQ0EsV0FBS0MsS0FBTCxHQUFhbUIsV0FBYjtBQUNBLFdBQUtsQixNQUFMLEdBQWNtQixZQUFkO0FBQ0EsV0FBS2xCLElBQUwsR0FBWSx5QkFBWjtBQUNBbUIsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksY0FBWjtBQUNBLFdBQUtDLFVBQUwsR0FBa0I7QUFDZEMsUUFBQUEsTUFBTSxFQUFFUCxFQUFFLENBQUNRLFlBQUgsQ0FBZ0I7QUFDcEJDLFVBQUFBLFFBQVEsRUFBRSxLQUFLeEIsSUFESztBQUVwQnlCLFVBQUFBLE9BQU8sRUFBRSxPQUZXO0FBR3BCQyxVQUFBQSxTQUFTLEVBQUUsQ0FIUztBQUlwQkMsVUFBQUEsS0FBSyxFQUFFO0FBQ0hDLFlBQUFBLElBQUksRUFBRSxDQURIO0FBRUhDLFlBQUFBLEdBQUcsRUFBRSxDQUZGO0FBR0gvQixZQUFBQSxLQUFLLEVBQUUsR0FISjtBQUlIZ0MsWUFBQUEsT0FBTyxFQUFFO0FBSk47QUFKYSxTQUFoQjtBQURNLE9BQWxCO0FBYUEsV0FBS1QsVUFBTCxDQUFnQkMsTUFBaEIsQ0FBdUJTLE9BQXZCLENBQStCLFVBQVVDLEdBQVYsRUFBZTtBQUMxQ2IsUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksYUFBWixFQUEyQlksR0FBM0I7QUFDSCxPQUZEO0FBR0g7QUFDSixHQXhDaUI7QUF5Q2xCQyxFQUFBQSxVQUFVLEVBQUUsb0JBQVVDLE1BQVYsRUFBa0I7QUFDMUIsUUFBSUEsTUFBSixFQUFZO0FBRVIsVUFBSSxLQUFLYixVQUFMLElBQW1CLEtBQUtBLFVBQUwsQ0FBZ0JDLE1BQXZDLEVBQStDO0FBQzNDSCxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQ0EsYUFBS0MsVUFBTCxDQUFnQkMsTUFBaEIsQ0FBdUJhLElBQXZCLEdBQThCQyxJQUE5QixDQUFtQyxZQUFNO0FBQ3JDakIsVUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksVUFBWjtBQUNILFNBRkQ7QUFHSDtBQUNKLEtBUkQsTUFRTztBQUNILFdBQUtDLFVBQUwsQ0FBZ0JDLE1BQWhCLENBQXVCZSxJQUF2QjtBQUNIO0FBQ0o7QUFyRGlCLENBQVQsQ0FBYjtBQXdEQUMsTUFBTSxDQUFDQyxPQUFQLEdBQWlCdEMsTUFBakIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbInZhciB0YXJnZXRCYW5uZXJBZFdpZHRoID0gMjAwO1xyXG52YXIgd2lkdGggPSAxMDA7XHJcbnZhciBoZWlnaHQgPSAxMDA7XHJcbnZhciBhZElkID0gJzJiMGMwZGdmMjBuZjNxZTJqaic7XHJcbnZhciBHcmlkQWQgPSBjYy5DbGFzcyh7XHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICB9LFxyXG4gICAgY3RvcigpIHtcclxuICAgICAgICB0aGlzLmluc3RhbmNlID0gbnVsbDtcclxuICAgIH0sXHJcbiAgICBzdGF0aWNzOiB7XHJcbiAgICAgICAgY3JlYXRlOiBmdW5jdGlvbiAoZGF0YSkge1xyXG4gICAgICAgICAgICBpZiAoIXRoaXMuaW5zdGFuY2UpIHtcclxuICAgICAgICAgICAgICAgIHRoaXMuaW5zdGFuY2UgPSBuZXcgR3JpZEFkKCk7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmluc3RhbmNlLmluaXRXaXRoRGF0YShkYXRhKTtcclxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLmluc3RhbmNlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGluaXRXaXRoRGF0YTogZnVuY3Rpb24gKGRhdGEpIHtcclxuICAgICAgICBpZiAoY2Muc3lzLnBsYXRmb3JtID09IGNjLnN5cy5XRUNIQVRfR0FNRSAmJiBhcHBHYW1lLnBsYXRmb3JtID09ICdXWCcpIHtcclxuICAgICAgICAgICAgY29uc3QgeyB3aW5kb3dXaWR0aCwgd2luZG93SGVpZ2h0IH0gPSB3eC5nZXRTeXN0ZW1JbmZvU3luYygpO1xyXG4gICAgICAgICAgICB0aGlzLnRhcmdldEJhbm5lckFkV2lkdGggPSAyMDA7XHJcbiAgICAgICAgICAgIHRoaXMud2lkdGggPSB3aW5kb3dXaWR0aDtcclxuICAgICAgICAgICAgdGhpcy5oZWlnaHQgPSB3aW5kb3dIZWlnaHQ7XHJcbiAgICAgICAgICAgIHRoaXMuYWRJZCA9ICdhZHVuaXQtMTQ0YmNmYzRmOGYzY2VmZSc7XHJcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiYmFubmVyIOesrOS4gOasoeWIm+W7ulwiKVxyXG4gICAgICAgICAgICB0aGlzLmdsb2JhbERhdGEgPSB7XHJcbiAgICAgICAgICAgICAgICBncmlkQWQ6IHd4LmNyZWF0ZUdyaWRBZCh7XHJcbiAgICAgICAgICAgICAgICAgICAgYWRVbml0SWQ6IHRoaXMuYWRJZCxcclxuICAgICAgICAgICAgICAgICAgICBhZFRoZW1lOiAnd2hpdGUnLFxyXG4gICAgICAgICAgICAgICAgICAgIGdyaWRDb3VudDogNSxcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZToge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBsZWZ0OiAwLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB0b3A6IDAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiAzMzAsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9wYWNpdHk6IDAuOFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pLFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIHRoaXMuZ2xvYmFsRGF0YS5ncmlkQWQub25FcnJvcihmdW5jdGlvbiAocmVzKSB7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygn55uS5a2Q5bm/5ZGKb25FcnJvcicsIHJlcylcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgcGxheUdyaWRBZDogZnVuY3Rpb24gKGlzU2hvdykge1xyXG4gICAgICAgIGlmIChpc1Nob3cpIHtcclxuXHJcbiAgICAgICAgICAgIGlmICh0aGlzLmdsb2JhbERhdGEgJiYgdGhpcy5nbG9iYWxEYXRhLmdyaWRBZCkge1xyXG4gICAgICAgICAgICAgICAgY29uc29sZS5sb2coXCLmkq3mlL7nm5LlrZDlub/lkYpcIik7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmdsb2JhbERhdGEuZ3JpZEFkLnNob3coKS50aGVuKCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuebkuWtkOW5v+WRiuWxleekuuaIkOWKn1wiKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5nbG9iYWxEYXRhLmdyaWRBZC5oaWRlKCk7XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbn0pO1xyXG5tb2R1bGUuZXhwb3J0cyA9IEdyaWRBZDtcclxuIl19
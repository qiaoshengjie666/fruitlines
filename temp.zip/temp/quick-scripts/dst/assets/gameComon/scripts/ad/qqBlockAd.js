
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/gameComon/scripts/ad/qqBlockAd.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'd8a0ccas05AxZHvKiQ9cgNJ', 'qqBlockAd');
// gameComon/scripts/ad/qqBlockAd.js

"use strict";

var videoId = '';
var adUnitId = "";
var BlockAd = cc.Class({
  "extends": cc.Component,
  properties: {},
  ctor: function ctor() {
    this.instance = null;
  },
  statics: {
    create: function create(data) {
      if (!this.instance) {
        this.instance = new BlockAd();
        this.instance.initWithData(data);
        return this.instance;
      }
    }
  },
  initWithData: function initWithData(data) {
    this.targetBannerAdWidth = 200;
  },
  playBlockad: function playBlockad(show) {
    if (cc.sys.platform == cc.sys.WECHAT_GAME && appGame.platform == 'QQ') {
      //QQ
      if (show) {
        if (this.globalData && this.globalData.blockAd) {
          this.globalData.blockAd.destroy();
        }

        var res = qq.getSystemInfoSync();
        this.width = res.windowWidth;
        this.height = res.windowHeight;
        var Version2 = util.compareVersion(res.SDKVersion, "1.15.0"); //if(Version2 > 0){

        videoId = "672c9551ab8b8b8284a73dde8cf1406a";

        if (appGame.gameServerRoom.gameConfigData && appGame.gameServerRoom.gameConfigData.blockId && appGame.gameServerRoom.gameConfigData.blockId.QQ) {
          videoId = appGame.gameServerRoom.gameConfigData.blockId.QQ.adUnitId;
        }

        this.globalData = {
          blockAd: qq.createBlockAd({
            adUnitId: videoId,
            size: 5,
            orientation: 'landscape',
            style: {
              //left: 16,
              //top: this.height - (this.targetBannerAdWidth / 16) * 9, // 根据系统约定尺寸计算出广告高度,
              // width: this.targetBannerAdWidth,
              left: 16,
              top: this.height - this.targetBannerAdWidth / 16 * 9 * 2
            }
          })
        };
        this.globalData.blockAd.onError(function (res) {
          console.log('globalData blockAd onError', res);
        });
        console.log('globalData blockAd onLoad', res);
        this.globalData.blockAd.show(function (res) {
          console.log('globalData blockAd show error', res);
        });
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
          title: '积木广告',
          content: '展示'
        }, function () {});
      } else {
        if (this.globalData && this.globalData.blockAd) {
          this.globalData.blockAd.destroy();
          httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
            title: '积木广告',
            content: '隐藏'
          }, function () {});
        }
      }
    }
  },
  refreshSize: function refreshSize() {
    var _this = this;

    if (this.globalData && this.globalData.bannerAd) {
      if (cc.sys.platform == cc.sys.WECHAT_GAME && appGame.platform == 'QQ') {
        //QQ
        this.globalData.blockAd.onResize(function (size) {
          console.log("积木广告 shezhi大小" + _this.height + "   " + _this.width);
          _this.globalData.blockAd.style.top = _this.height - size.height;
          _this.globalData.blockAd.style.left = (_this.width - size.width) / 2;
        });
      }
    }
  }
});
module.exports = BlockAd;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcZ2FtZUNvbW9uXFxzY3JpcHRzXFxhZFxccXFCbG9ja0FkLmpzIl0sIm5hbWVzIjpbInZpZGVvSWQiLCJhZFVuaXRJZCIsIkJsb2NrQWQiLCJjYyIsIkNsYXNzIiwiQ29tcG9uZW50IiwicHJvcGVydGllcyIsImN0b3IiLCJpbnN0YW5jZSIsInN0YXRpY3MiLCJjcmVhdGUiLCJkYXRhIiwiaW5pdFdpdGhEYXRhIiwidGFyZ2V0QmFubmVyQWRXaWR0aCIsInBsYXlCbG9ja2FkIiwic2hvdyIsInN5cyIsInBsYXRmb3JtIiwiV0VDSEFUX0dBTUUiLCJhcHBHYW1lIiwiZ2xvYmFsRGF0YSIsImJsb2NrQWQiLCJkZXN0cm95IiwicmVzIiwicXEiLCJnZXRTeXN0ZW1JbmZvU3luYyIsIndpZHRoIiwid2luZG93V2lkdGgiLCJoZWlnaHQiLCJ3aW5kb3dIZWlnaHQiLCJWZXJzaW9uMiIsInV0aWwiLCJjb21wYXJlVmVyc2lvbiIsIlNES1ZlcnNpb24iLCJnYW1lU2VydmVyUm9vbSIsImdhbWVDb25maWdEYXRhIiwiYmxvY2tJZCIsIlFRIiwiY3JlYXRlQmxvY2tBZCIsInNpemUiLCJvcmllbnRhdGlvbiIsInN0eWxlIiwibGVmdCIsInRvcCIsIm9uRXJyb3IiLCJjb25zb2xlIiwibG9nIiwiaHR0cFV0aWxzIiwiaHR0cFBvc3QiLCJjb25zdHMiLCJIVFRQX1JFQ09SRF9TRVJWRVIiLCJ0aXRsZSIsImNvbnRlbnQiLCJyZWZyZXNoU2l6ZSIsImJhbm5lckFkIiwib25SZXNpemUiLCJtb2R1bGUiLCJleHBvcnRzIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLElBQUlBLE9BQU8sR0FBRyxFQUFkO0FBQ0EsSUFBSUMsUUFBUSxHQUFHLEVBQWY7QUFDQSxJQUFJQyxPQUFPLEdBQUdDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ25CLGFBQVNELEVBQUUsQ0FBQ0UsU0FETztBQUduQkMsRUFBQUEsVUFBVSxFQUFFLEVBSE87QUFLbkJDLEVBQUFBLElBTG1CLGtCQUtiO0FBQ0YsU0FBS0MsUUFBTCxHQUFnQixJQUFoQjtBQUNILEdBUGtCO0FBUW5CQyxFQUFBQSxPQUFPLEVBQUU7QUFDTEMsSUFBQUEsTUFBTSxFQUFFLGdCQUFVQyxJQUFWLEVBQWdCO0FBQ3BCLFVBQUcsQ0FBQyxLQUFLSCxRQUFULEVBQWtCO0FBQ2QsYUFBS0EsUUFBTCxHQUFnQixJQUFJTixPQUFKLEVBQWhCO0FBQ0EsYUFBS00sUUFBTCxDQUFjSSxZQUFkLENBQTJCRCxJQUEzQjtBQUNBLGVBQU8sS0FBS0gsUUFBWjtBQUNIO0FBQ0o7QUFQSSxHQVJVO0FBaUJuQkksRUFBQUEsWUFBWSxFQUFFLHNCQUFVRCxJQUFWLEVBQWdCO0FBQzFCLFNBQUtFLG1CQUFMLEdBQTJCLEdBQTNCO0FBQ0gsR0FuQmtCO0FBb0JuQkMsRUFBQUEsV0FBVyxFQUFDLHFCQUFTQyxJQUFULEVBQWM7QUFDdEIsUUFBR1osRUFBRSxDQUFDYSxHQUFILENBQU9DLFFBQVAsSUFBbUJkLEVBQUUsQ0FBQ2EsR0FBSCxDQUFPRSxXQUExQixJQUF3Q0MsT0FBTyxDQUFDRixRQUFSLElBQW9CLElBQS9ELEVBQW9FO0FBQUU7QUFDcEUsVUFBR0YsSUFBSCxFQUFRO0FBQ04sWUFBRyxLQUFLSyxVQUFMLElBQW1CLEtBQUtBLFVBQUwsQ0FBZ0JDLE9BQXRDLEVBQThDO0FBQzVDLGVBQUtELFVBQUwsQ0FBZ0JDLE9BQWhCLENBQXdCQyxPQUF4QjtBQUNEOztBQUNELFlBQU1DLEdBQUcsR0FBR0MsRUFBRSxDQUFDQyxpQkFBSCxFQUFaO0FBQ0EsYUFBS0MsS0FBTCxHQUFhSCxHQUFHLENBQUNJLFdBQWpCO0FBQ0EsYUFBS0MsTUFBTCxHQUFjTCxHQUFHLENBQUNNLFlBQWxCO0FBQ0EsWUFBSUMsUUFBUSxHQUFHQyxJQUFJLENBQUNDLGNBQUwsQ0FBb0JULEdBQUcsQ0FBQ1UsVUFBeEIsRUFBbUMsUUFBbkMsQ0FBZixDQVBNLENBUU47O0FBQ0lqQyxRQUFBQSxPQUFPLEdBQUcsa0NBQVY7O0FBQ0EsWUFBR21CLE9BQU8sQ0FBQ2UsY0FBUixDQUF1QkMsY0FBdkIsSUFBeUNoQixPQUFPLENBQUNlLGNBQVIsQ0FBdUJDLGNBQXZCLENBQXNDQyxPQUEvRSxJQUEwRmpCLE9BQU8sQ0FBQ2UsY0FBUixDQUF1QkMsY0FBdkIsQ0FBc0NDLE9BQXRDLENBQThDQyxFQUEzSSxFQUE4STtBQUM1SXJDLFVBQUFBLE9BQU8sR0FBR21CLE9BQU8sQ0FBQ2UsY0FBUixDQUF1QkMsY0FBdkIsQ0FBc0NDLE9BQXRDLENBQThDQyxFQUE5QyxDQUFpRHBDLFFBQTNEO0FBQ0Q7O0FBQ0QsYUFBS21CLFVBQUwsR0FBa0I7QUFDZEMsVUFBQUEsT0FBTyxFQUFFRyxFQUFFLENBQUNjLGFBQUgsQ0FBaUI7QUFDeEJyQyxZQUFBQSxRQUFRLEVBQUVELE9BRGM7QUFFeEJ1QyxZQUFBQSxJQUFJLEVBQUUsQ0FGa0I7QUFHeEJDLFlBQUFBLFdBQVcsRUFBRSxXQUhXO0FBSXhCQyxZQUFBQSxLQUFLLEVBQUU7QUFDTDtBQUNBO0FBQ0E7QUFDQUMsY0FBQUEsSUFBSSxFQUFDLEVBSkE7QUFLTEMsY0FBQUEsR0FBRyxFQUFDLEtBQUtmLE1BQUwsR0FBZSxLQUFLZixtQkFBTCxHQUEyQixFQUE1QixHQUFrQyxDQUFsQyxHQUFvQztBQUxqRDtBQUppQixXQUFqQjtBQURLLFNBQWxCO0FBZUEsYUFBS08sVUFBTCxDQUFnQkMsT0FBaEIsQ0FBd0J1QixPQUF4QixDQUFnQyxVQUFBckIsR0FBRyxFQUFFO0FBQ25Dc0IsVUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksNEJBQVosRUFBeUN2QixHQUF6QztBQUNELFNBRkQ7QUFJQXNCLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLDJCQUFaLEVBQXdDdkIsR0FBeEM7QUFFQSxhQUFLSCxVQUFMLENBQWdCQyxPQUFoQixDQUF3Qk4sSUFBeEIsQ0FBNkIsVUFBQVEsR0FBRyxFQUFFO0FBQ2hDc0IsVUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksK0JBQVosRUFBNEN2QixHQUE1QztBQUNELFNBRkQ7QUFHQXdCLFFBQUFBLFNBQVMsQ0FBQ0MsUUFBVixDQUFtQkMsTUFBTSxDQUFDQyxrQkFBMUIsRUFBNkM7QUFBQ0MsVUFBQUEsS0FBSyxFQUFDLE1BQVA7QUFBY0MsVUFBQUEsT0FBTyxFQUFDO0FBQXRCLFNBQTdDLEVBQXlFLFlBQVUsQ0FBRSxDQUFyRjtBQUNMLE9BdENELE1Bc0NLO0FBQ0QsWUFBRyxLQUFLaEMsVUFBTCxJQUFtQixLQUFLQSxVQUFMLENBQWdCQyxPQUF0QyxFQUE4QztBQUM1QyxlQUFLRCxVQUFMLENBQWdCQyxPQUFoQixDQUF3QkMsT0FBeEI7QUFDQXlCLFVBQUFBLFNBQVMsQ0FBQ0MsUUFBVixDQUFtQkMsTUFBTSxDQUFDQyxrQkFBMUIsRUFBNkM7QUFBQ0MsWUFBQUEsS0FBSyxFQUFDLE1BQVA7QUFBY0MsWUFBQUEsT0FBTyxFQUFDO0FBQXRCLFdBQTdDLEVBQXlFLFlBQVUsQ0FDbEYsQ0FERDtBQUVEO0FBQ0o7QUFDQTtBQUNKLEdBcEVnQjtBQXFFakJDLEVBQUFBLFdBckVpQix5QkFxRUo7QUFBQTs7QUFDWCxRQUFHLEtBQUtqQyxVQUFMLElBQW1CLEtBQUtBLFVBQUwsQ0FBZ0JrQyxRQUF0QyxFQUErQztBQUMzQyxVQUFHbkQsRUFBRSxDQUFDYSxHQUFILENBQU9DLFFBQVAsSUFBbUJkLEVBQUUsQ0FBQ2EsR0FBSCxDQUFPRSxXQUExQixJQUF3Q0MsT0FBTyxDQUFDRixRQUFSLElBQW9CLElBQS9ELEVBQW9FO0FBQUU7QUFDbEUsYUFBS0csVUFBTCxDQUFnQkMsT0FBaEIsQ0FBd0JrQyxRQUF4QixDQUFpQyxVQUFDaEIsSUFBRCxFQUFVO0FBQ3ZDTSxVQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxrQkFBZ0IsS0FBSSxDQUFDbEIsTUFBckIsR0FBNEIsS0FBNUIsR0FBa0MsS0FBSSxDQUFDRixLQUFuRDtBQUNBLFVBQUEsS0FBSSxDQUFDTixVQUFMLENBQWdCQyxPQUFoQixDQUF3Qm9CLEtBQXhCLENBQThCRSxHQUE5QixHQUFvQyxLQUFJLENBQUNmLE1BQUwsR0FBY1csSUFBSSxDQUFDWCxNQUF2RDtBQUNBLFVBQUEsS0FBSSxDQUFDUixVQUFMLENBQWdCQyxPQUFoQixDQUF3Qm9CLEtBQXhCLENBQThCQyxJQUE5QixHQUFxQyxDQUFDLEtBQUksQ0FBQ2hCLEtBQUwsR0FBYWEsSUFBSSxDQUFDYixLQUFuQixJQUE0QixDQUFqRTtBQUNILFNBSkQ7QUFLSDtBQUNKO0FBQ0o7QUEvRWtCLENBQVQsQ0FBZDtBQWlGQThCLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQnZELE9BQWpCIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgdmlkZW9JZCA9ICcnO1xyXG52YXIgYWRVbml0SWQgPSBcIlwiO1xyXG52YXIgQmxvY2tBZCA9IGNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICB9LFxyXG4gICAgY3Rvcigpe1xyXG4gICAgICAgIHRoaXMuaW5zdGFuY2UgPSBudWxsO1xyXG4gICAgfSxcclxuICAgIHN0YXRpY3M6IHtcclxuICAgICAgICBjcmVhdGU6IGZ1bmN0aW9uIChkYXRhKSB7XHJcbiAgICAgICAgICAgIGlmKCF0aGlzLmluc3RhbmNlKXtcclxuICAgICAgICAgICAgICAgIHRoaXMuaW5zdGFuY2UgPSBuZXcgQmxvY2tBZCgpO1xyXG4gICAgICAgICAgICAgICAgdGhpcy5pbnN0YW5jZS5pbml0V2l0aERhdGEoZGF0YSk7XHJcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy5pbnN0YW5jZTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBpbml0V2l0aERhdGE6IGZ1bmN0aW9uIChkYXRhKSB7XHJcbiAgICAgICAgdGhpcy50YXJnZXRCYW5uZXJBZFdpZHRoID0gMjAwOyAgXHJcbiAgICB9LFxyXG4gICAgcGxheUJsb2NrYWQ6ZnVuY3Rpb24oc2hvdyl7XHJcbiAgICAgICAgaWYoY2Muc3lzLnBsYXRmb3JtID09IGNjLnN5cy5XRUNIQVRfR0FNRSAmJmFwcEdhbWUucGxhdGZvcm0gPT0gJ1FRJyl7IC8vUVFcclxuICAgICAgICAgIGlmKHNob3cpe1xyXG4gICAgICAgICAgICBpZih0aGlzLmdsb2JhbERhdGEgJiYgdGhpcy5nbG9iYWxEYXRhLmJsb2NrQWQpe1xyXG4gICAgICAgICAgICAgIHRoaXMuZ2xvYmFsRGF0YS5ibG9ja0FkLmRlc3Ryb3koKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBjb25zdCByZXMgPSBxcS5nZXRTeXN0ZW1JbmZvU3luYygpO1xyXG4gICAgICAgICAgICB0aGlzLndpZHRoID0gcmVzLndpbmRvd1dpZHRoO1xyXG4gICAgICAgICAgICB0aGlzLmhlaWdodCA9IHJlcy53aW5kb3dIZWlnaHQ7XHJcbiAgICAgICAgICAgIHZhciBWZXJzaW9uMiA9IHV0aWwuY29tcGFyZVZlcnNpb24ocmVzLlNES1ZlcnNpb24sXCIxLjE1LjBcIik7XHJcbiAgICAgICAgICAgIC8vaWYoVmVyc2lvbjIgPiAwKXtcclxuICAgICAgICAgICAgICAgIHZpZGVvSWQgPSBcIjY3MmM5NTUxYWI4YjhiODI4NGE3M2RkZThjZjE0MDZhXCI7XHJcbiAgICAgICAgICAgICAgICBpZihhcHBHYW1lLmdhbWVTZXJ2ZXJSb29tLmdhbWVDb25maWdEYXRhICYmIGFwcEdhbWUuZ2FtZVNlcnZlclJvb20uZ2FtZUNvbmZpZ0RhdGEuYmxvY2tJZCAmJiBhcHBHYW1lLmdhbWVTZXJ2ZXJSb29tLmdhbWVDb25maWdEYXRhLmJsb2NrSWQuUVEpe1xyXG4gICAgICAgICAgICAgICAgICB2aWRlb0lkID0gYXBwR2FtZS5nYW1lU2VydmVyUm9vbS5nYW1lQ29uZmlnRGF0YS5ibG9ja0lkLlFRLmFkVW5pdElkO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgdGhpcy5nbG9iYWxEYXRhID0ge1xyXG4gICAgICAgICAgICAgICAgICAgIGJsb2NrQWQ6IHFxLmNyZWF0ZUJsb2NrQWQoe1xyXG4gICAgICAgICAgICAgICAgICAgICAgYWRVbml0SWQ6IHZpZGVvSWQsXHJcbiAgICAgICAgICAgICAgICAgICAgICBzaXplOiA1LFxyXG4gICAgICAgICAgICAgICAgICAgICAgb3JpZW50YXRpb246ICdsYW5kc2NhcGUnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgc3R5bGU6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy9sZWZ0OiAxNixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy90b3A6IHRoaXMuaGVpZ2h0IC0gKHRoaXMudGFyZ2V0QmFubmVyQWRXaWR0aCAvIDE2KSAqIDksIC8vIOagueaNruezu+e7n+e6puWumuWwuuWvuOiuoeeul+WHuuW5v+WRiumrmOW6pixcclxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gd2lkdGg6IHRoaXMudGFyZ2V0QmFubmVyQWRXaWR0aCxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGVmdDoxNixcclxuICAgICAgICAgICAgICAgICAgICAgICAgdG9wOnRoaXMuaGVpZ2h0IC0gKHRoaXMudGFyZ2V0QmFubmVyQWRXaWR0aCAvIDE2KSAqIDkqMixcclxuICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgdGhpcy5nbG9iYWxEYXRhLmJsb2NrQWQub25FcnJvcihyZXM9PntcclxuICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2coJ2dsb2JhbERhdGEgYmxvY2tBZCBvbkVycm9yJyxyZXMpXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZygnZ2xvYmFsRGF0YSBibG9ja0FkIG9uTG9hZCcscmVzKVxyXG5cclxuICAgICAgICAgICAgICAgIHRoaXMuZ2xvYmFsRGF0YS5ibG9ja0FkLnNob3cocmVzPT57XHJcbiAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKCdnbG9iYWxEYXRhIGJsb2NrQWQgc2hvdyBlcnJvcicscmVzKVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgICAgICBodHRwVXRpbHMuaHR0cFBvc3QoY29uc3RzLkhUVFBfUkVDT1JEX1NFUlZFUix7dGl0bGU6J+enr+acqOW5v+WRiicsY29udGVudDon5bGV56S6J30sZnVuY3Rpb24oKXt9KTtcclxuICAgICAgICAgIH1lbHNle1xyXG4gICAgICAgICAgICAgIGlmKHRoaXMuZ2xvYmFsRGF0YSAmJiB0aGlzLmdsb2JhbERhdGEuYmxvY2tBZCl7XHJcbiAgICAgICAgICAgICAgICB0aGlzLmdsb2JhbERhdGEuYmxvY2tBZC5kZXN0cm95KCk7XHJcbiAgICAgICAgICAgICAgICBodHRwVXRpbHMuaHR0cFBvc3QoY29uc3RzLkhUVFBfUkVDT1JEX1NFUlZFUix7dGl0bGU6J+enr+acqOW5v+WRiicsY29udGVudDon6ZqQ6JePJ30sZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0gIFxyXG4gICAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICByZWZyZXNoU2l6ZSgpe1xyXG4gICAgICAgIGlmKHRoaXMuZ2xvYmFsRGF0YSAmJiB0aGlzLmdsb2JhbERhdGEuYmFubmVyQWQpe1xyXG4gICAgICAgICAgICBpZihjYy5zeXMucGxhdGZvcm0gPT0gY2Muc3lzLldFQ0hBVF9HQU1FICYmYXBwR2FtZS5wbGF0Zm9ybSA9PSAnUVEnKXsgLy9RUVxyXG4gICAgICAgICAgICAgICAgdGhpcy5nbG9iYWxEYXRhLmJsb2NrQWQub25SZXNpemUoKHNpemUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcIuenr+acqOW5v+WRiiBzaGV6aGnlpKflsI9cIit0aGlzLmhlaWdodCtcIiAgIFwiK3RoaXMud2lkdGgpXHJcbiAgICAgICAgICAgICAgICAgICAgdGhpcy5nbG9iYWxEYXRhLmJsb2NrQWQuc3R5bGUudG9wID0gdGhpcy5oZWlnaHQgLSBzaXplLmhlaWdodDtcclxuICAgICAgICAgICAgICAgICAgICB0aGlzLmdsb2JhbERhdGEuYmxvY2tBZC5zdHlsZS5sZWZ0ID0gKHRoaXMud2lkdGggLSBzaXplLndpZHRoKSAvIDI7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbn0pO1xyXG5tb2R1bGUuZXhwb3J0cyA9IEJsb2NrQWQ7XHJcbiJdfQ==
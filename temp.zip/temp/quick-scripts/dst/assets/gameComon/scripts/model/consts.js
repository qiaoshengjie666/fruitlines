
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/gameComon/scripts/model/consts.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'f36fcCR/lBD/qmR2CZ3f4L4', 'consts');
// gameComon/scripts/model/consts.js

"use strict";

var consts = {
  CLIENT_GAME_START: "client.onGameStart",
  LOCAL_EVENT_POPUP_LOADTIP: "localEventPopupLoadTip",
  //提示框,
  LOCAL_EVENT_POPUP_DIALOG: "localEventPopupDialog",
  //对话框,
  LOCAL_EVENT_POPUP_GAME_COMMON: "localEventPopupGameCommon",
  //公用prefab
  LOCAL_GAME_RESULT_NATIVE_AD: "client.onResultNativeAD",
  //原生广告
  CLIENT_GAME_VIDEO_SHOW: "client.onGameShowVideo",
  CLIENT_GAME_RESULT_VIDEO_SHOW: "client.onGameResultShowVideo",
  CLIENT_GAME_PLAY_VIDEO: "client.onGamePlayVideo",
  HTTP_RECORD_SERVER: "https://l.h5120.com/te/tk/gameapplist",
  HTTP_EVENT_MIDDLE_DESK_CONFIG: "client.onGameMiddleDeskConfig",
  //获取配置

  /*需要修改的配置*/
  HTTP_RECORD_PACKAGE: 'com.snmi.crazyremove',
  //包名
  HTTP_RECORD_PACKAGENAME: '疯狂消消消',
  //游戏名
  GAME_ID: 15,
  HTTP_GET_PAAS_DATA_SERVER: 'https://cs.snmi.cn/game/GetGameValue',
  //获取中台服务器配置
  HTTP_GET_GAME_DATA_SERVER: 'https://cs.snmi.cn/switch/GetGameValue',
  //获取游戏服务器配置

  /*不需要修改的配置*/
  HTTP_SPREAD_WORD: "https://s.snmi.cn/game/kl",
  HTTP_SPREAD_REPORT: "https://t.h5data.com/d/gkl?",
  HTTP_SPREAD_CLOSE: "https://t.h5data.com/d/gclose?rid="
};
module.exports = consts;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcZ2FtZUNvbW9uXFxzY3JpcHRzXFxtb2RlbFxcY29uc3RzLmpzIl0sIm5hbWVzIjpbImNvbnN0cyIsIkNMSUVOVF9HQU1FX1NUQVJUIiwiTE9DQUxfRVZFTlRfUE9QVVBfTE9BRFRJUCIsIkxPQ0FMX0VWRU5UX1BPUFVQX0RJQUxPRyIsIkxPQ0FMX0VWRU5UX1BPUFVQX0dBTUVfQ09NTU9OIiwiTE9DQUxfR0FNRV9SRVNVTFRfTkFUSVZFX0FEIiwiQ0xJRU5UX0dBTUVfVklERU9fU0hPVyIsIkNMSUVOVF9HQU1FX1JFU1VMVF9WSURFT19TSE9XIiwiQ0xJRU5UX0dBTUVfUExBWV9WSURFTyIsIkhUVFBfUkVDT1JEX1NFUlZFUiIsIkhUVFBfRVZFTlRfTUlERExFX0RFU0tfQ09ORklHIiwiSFRUUF9SRUNPUkRfUEFDS0FHRSIsIkhUVFBfUkVDT1JEX1BBQ0tBR0VOQU1FIiwiR0FNRV9JRCIsIkhUVFBfR0VUX1BBQVNfREFUQV9TRVJWRVIiLCJIVFRQX0dFVF9HQU1FX0RBVEFfU0VSVkVSIiwiSFRUUF9TUFJFQURfV09SRCIsIkhUVFBfU1BSRUFEX1JFUE9SVCIsIkhUVFBfU1BSRUFEX0NMT1NFIiwibW9kdWxlIiwiZXhwb3J0cyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFJQSxNQUFNLEdBQUc7QUFDVEMsRUFBQUEsaUJBQWlCLEVBQUMsb0JBRFQ7QUFFVEMsRUFBQUEseUJBQXlCLEVBQUMsd0JBRmpCO0FBRTJDO0FBQ3BEQyxFQUFBQSx3QkFBd0IsRUFBRSx1QkFIakI7QUFHMEM7QUFDbkRDLEVBQUFBLDZCQUE2QixFQUFFLDJCQUp0QjtBQUltRDtBQUM1REMsRUFBQUEsMkJBQTJCLEVBQUUseUJBTHBCO0FBSytDO0FBQ3hEQyxFQUFBQSxzQkFBc0IsRUFBQyx3QkFOZDtBQU9UQyxFQUFBQSw2QkFBNkIsRUFBQyw4QkFQckI7QUFRVEMsRUFBQUEsc0JBQXNCLEVBQUMsd0JBUmQ7QUFTVEMsRUFBQUEsa0JBQWtCLEVBQUMsdUNBVFY7QUFVVEMsRUFBQUEsNkJBQTZCLEVBQUMsK0JBVnJCO0FBVXNEOztBQUUvRDtBQUNBQyxFQUFBQSxtQkFBbUIsRUFBQyxzQkFiWDtBQWFtQztBQUM1Q0MsRUFBQUEsdUJBQXVCLEVBQUMsT0FkZjtBQWN3QjtBQUNqQ0MsRUFBQUEsT0FBTyxFQUFDLEVBZkM7QUFnQlRDLEVBQUFBLHlCQUF5QixFQUFDLHNDQWhCakI7QUFnQndEO0FBQ2pFQyxFQUFBQSx5QkFBeUIsRUFBQyx3Q0FqQmpCO0FBaUIwRDs7QUFDbkU7QUFDQUMsRUFBQUEsZ0JBQWdCLEVBQUMsMkJBbkJSO0FBb0JUQyxFQUFBQSxrQkFBa0IsRUFBQyw2QkFwQlY7QUFxQlRDLEVBQUFBLGlCQUFpQixFQUFDO0FBckJULENBQWI7QUF3QkFDLE1BQU0sQ0FBQ0MsT0FBUCxHQUFpQnBCLE1BQWpCIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJ2YXIgY29uc3RzID0ge1xuICAgIENMSUVOVF9HQU1FX1NUQVJUOlwiY2xpZW50Lm9uR2FtZVN0YXJ0XCIsXG4gICAgTE9DQUxfRVZFTlRfUE9QVVBfTE9BRFRJUDpcImxvY2FsRXZlbnRQb3B1cExvYWRUaXBcIiwgLy/mj5DnpLrmoYYsXG4gICAgTE9DQUxfRVZFTlRfUE9QVVBfRElBTE9HOiBcImxvY2FsRXZlbnRQb3B1cERpYWxvZ1wiLCAvL+WvueivneahhixcbiAgICBMT0NBTF9FVkVOVF9QT1BVUF9HQU1FX0NPTU1PTjogXCJsb2NhbEV2ZW50UG9wdXBHYW1lQ29tbW9uXCIsIC8v5YWs55SocHJlZmFiXG4gICAgTE9DQUxfR0FNRV9SRVNVTFRfTkFUSVZFX0FEOiBcImNsaWVudC5vblJlc3VsdE5hdGl2ZUFEXCIsIC8v5Y6f55Sf5bm/5ZGKXG4gICAgQ0xJRU5UX0dBTUVfVklERU9fU0hPVzpcImNsaWVudC5vbkdhbWVTaG93VmlkZW9cIixcbiAgICBDTElFTlRfR0FNRV9SRVNVTFRfVklERU9fU0hPVzpcImNsaWVudC5vbkdhbWVSZXN1bHRTaG93VmlkZW9cIixcbiAgICBDTElFTlRfR0FNRV9QTEFZX1ZJREVPOlwiY2xpZW50Lm9uR2FtZVBsYXlWaWRlb1wiLFxuICAgIEhUVFBfUkVDT1JEX1NFUlZFUjpcImh0dHBzOi8vbC5oNTEyMC5jb20vdGUvdGsvZ2FtZWFwcGxpc3RcIixcbiAgICBIVFRQX0VWRU5UX01JRERMRV9ERVNLX0NPTkZJRzpcImNsaWVudC5vbkdhbWVNaWRkbGVEZXNrQ29uZmlnXCIsIC8v6I635Y+W6YWN572uXG5cbiAgICAvKumcgOimgeS/ruaUueeahOmFjee9riovXG4gICAgSFRUUF9SRUNPUkRfUEFDS0FHRTonY29tLnNubWkuY3JhenlyZW1vdmUnLCAvL+WMheWQjVxuICAgIEhUVFBfUkVDT1JEX1BBQ0tBR0VOQU1FOifnlq/ni4LmtojmtojmtognLCAvL+a4uOaIj+WQjVxuICAgIEdBTUVfSUQ6MTUsXG4gICAgSFRUUF9HRVRfUEFBU19EQVRBX1NFUlZFUjonaHR0cHM6Ly9jcy5zbm1pLmNuL2dhbWUvR2V0R2FtZVZhbHVlJywvL+iOt+WPluS4reWPsOacjeWKoeWZqOmFjee9rlxuICAgIEhUVFBfR0VUX0dBTUVfREFUQV9TRVJWRVI6J2h0dHBzOi8vY3Muc25taS5jbi9zd2l0Y2gvR2V0R2FtZVZhbHVlJywvL+iOt+WPlua4uOaIj+acjeWKoeWZqOmFjee9rlxuICAgIC8q5LiN6ZyA6KaB5L+u5pS555qE6YWN572uKi9cbiAgICBIVFRQX1NQUkVBRF9XT1JEOlwiaHR0cHM6Ly9zLnNubWkuY24vZ2FtZS9rbFwiLFxuICAgIEhUVFBfU1BSRUFEX1JFUE9SVDpcImh0dHBzOi8vdC5oNWRhdGEuY29tL2QvZ2tsP1wiLFxuICAgIEhUVFBfU1BSRUFEX0NMT1NFOlwiaHR0cHM6Ly90Lmg1ZGF0YS5jb20vZC9nY2xvc2U/cmlkPVwiLFxufTtcblxubW9kdWxlLmV4cG9ydHMgPSBjb25zdHM7XG4iXX0=

(function () {
var scripts = [{"deps":{"./assets/framework/plugin_boosts/libs/easing":1,"./assets/framework/plugin_boosts/utils/Intersection":3,"./assets/gameComon/scripts/sign":4,"./assets/gameComon/scripts/model/util":6,"./assets/Game/Scripts/hex-lines-game/base/com":7,"./assets/framework/network/Message":8,"./assets/framework/plugin_boosts/gamesys/InfiniteBackground":9,"./assets/gameComon/scripts/ad/videoBanner":10,"./assets/framework/Platform":12,"./assets/Game/Scripts/g - 001":13,"./assets/Game/Scripts/hex-lines-game/Consts":14,"./assets/Game/Scripts/hex-lines-game/ds/IntMap":16,"./assets/migration/use_v2.0.x_cc.Toggle_event":17,"./assets/gameComon/scripts/horn":19,"./assets/framework/plugin_boosts/ui/game/LevelSelector":20,"./assets/gameComon/scripts/model/androidHelper":21,"./assets/gameComon/scripts/audio/audioMgr":22,"./assets/Game/Scripts/hex-lines-game/Res":31,"./assets/Game/Scripts/hex-lines-game/Animal":32,"./assets/framework/plugin_boosts/gamesys/PoolManager":39,"./assets/framework/plugin_boosts/gamesys/Device":44,"./assets/framework/plugin_boosts/gamesys/LocalTimeSystem":47,"./assets/framework/plugin_boosts/misc/Signal":48,"./assets/framework/plugin_boosts/misc/JoyStick":49,"./assets/framework/plugin_boosts/misc/BoostsAction":50,"./assets/framework/plugin_boosts/misc/SpriteFrameCache":51,"./assets/framework/plugin_boosts/misc/Net":55,"./assets/framework/plugin_boosts/ui/PandoraPoint":56,"./assets/framework/plugin_boosts/ui/LoadingManager":61,"./assets/framework/plugin_boosts/ui/UIFunctions":63,"./assets/framework/plugin_boosts/ui/UIComponent":64,"./assets/framework/plugin_boosts/gamesys/FSM":67,"./assets/framework/plugin_boosts/misc/FrameSwitch":68,"./assets/framework/plugin_boosts/utils/EventManager":70,"./assets/gameComon/scripts/loadTip":72,"./assets/gameComon/scripts/platformFun":73,"./assets/gameComon/scripts/result":74,"./assets/gameComon/scripts/item":76,"./assets/gameComon/scripts/ad/nativeAd":77,"./assets/gameComon/scripts/screenrecord":78,"./assets/gameComon/scripts/revive":79,"./assets/gameComon/scripts/updateTime":80,"./assets/gameComon/scripts/dialogBox":82,"./assets/gameComon/scripts/ad/qqAppBox":83,"./assets/gameComon/scripts/ad/qqBlockAd":84,"./assets/gameComon/scripts/ad/wxnativeAd":86,"./assets/gameComon/scripts/ad/wxgridAd":87,"./assets/gameComon/scripts/ad/interstitialAd":88,"./assets/gameComon/scripts/model/emitter":90,"./assets/gameComon/scripts/model/httpUtils":91,"./assets/gameComon/scripts/changeGame":92,"./assets/gameComon/scripts/model/consts":93,"./assets/gameComon/scripts/lucky":95,"./assets/gameComon/scripts/model/underscore":96,"./assets/framework/network/MessageDispatch":98,"./assets/framework/network/MessageType":99,"./assets/framework/plugin_boosts/ui/ViewManager":2,"./assets/gameComon/scripts/ad/banner":5,"./assets/Game/Scripts/hex-lines-game/Game":11,"./assets/Game/Scripts/Info":23,"./assets/Game/Scripts/ui/DCBackground":15,"./assets/Game/Scripts/Main":38,"./assets/framework/plugin_boosts/misc/ClickAudioManager":18,"./assets/gameComon/scripts/room":81,"./assets/gameComon/scripts/model/async":89,"./assets/Game/Scripts/hex-lines-game/GridManager":24,"./assets/Game/Scripts/ui/DailyGetDialog":25,"./assets/Game/Scripts/ui/LevelDialog":26,"./assets/Game/Scripts/ui/ShopItemTemplate":30,"./assets/Game/Scripts/ui/LuckyDialog":27,"./assets/Game/Scripts/ui/LevelupDialog":28,"./assets/Game/Scripts/ui/GetDialog":29,"./assets/Game/Scripts/hex-lines-game/HexonTile":33,"./assets/Game/Scripts/ui/ShopDialog":34,"./assets/Game/Scripts/ui/WinDialog":35,"./assets/Game/Scripts/ui/HbDialog":36,"./assets/Game/Scripts/ui/PauseDialog":37,"./assets/Game/Scripts/ui/DCParticleSystem":40,"./assets/framework/plugin_boosts/misc/InputSystem":45,"./assets/framework/plugin_boosts/misc/DataCenter":42,"./assets/framework/plugin_boosts/gamesys/PsSpawner":41,"./assets/framework/plugin_boosts/gamesys/PsFx":46,"./assets/framework/plugin_boosts/gamesys/PsFxPlayer":43,"./assets/framework/plugin_boosts/ui/DCToggle":52,"./assets/framework/plugin_boosts/ui/DCUI":53,"./assets/framework/plugin_boosts/misc/ClickAudio":57,"./assets/framework/plugin_boosts/ui/DCPandoraPoint":54,"./assets/framework/plugin_boosts/ui/MessageBoxManager":58,"./assets/framework/plugin_boosts/ui/DCLabel":59,"./assets/framework/plugin_boosts/ui/ToastComponent":62,"./assets/framework/plugin_boosts/ui/ToastManager":65,"./assets/framework/plugin_boosts/utils/Common":66,"./assets/framework/plugin_boosts/ui/MessageBoxComponent":60,"./assets/framework/plugin_boosts/ui/View":69,"./assets/framework/plugin_boosts/ui/DCSprite":71,"./assets/gameComon/scripts/roomGame":75,"./assets/framework/network/ConnectManager":100,"./assets/framework/network/MessageBase":97,"./assets/framework/network/Socket":101,"./assets/framework/network/MessageHandler":102,"./assets/gameComon/scripts/gameSceneManager":94,"./assets/framework/plugin_boosts/gamesys/LocalLifeSystem":103,"./assets/gameComon/scripts/model/appGame":85},"path":"preview-scripts/__qc_index__.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/libs/easing.js"},{"deps":{"./View":69},"path":"preview-scripts/assets/framework/plugin_boosts/ui/ViewManager.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/utils/Intersection.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/sign.js"},{"deps":{"../model/appGame":85},"path":"preview-scripts/assets/gameComon/scripts/ad/banner.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/model/util.js"},{"deps":{},"path":"preview-scripts/assets/Game/Scripts/hex-lines-game/base/com.js"},{"deps":{},"path":"preview-scripts/assets/framework/network/Message.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/gamesys/InfiniteBackground.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/ad/videoBanner.js"},{"deps":{"./Res":31,"./GridManager":24,"./HexonTile":33,"../../../framework/plugin_boosts/misc/InputSystem":45,"../Info":23,"./Animal":32,"../../../framework/plugin_boosts/ui/ViewManager":2,"../../../framework/Platform":12,"../../../framework/plugin_boosts/ui/ToastManager":65},"path":"preview-scripts/assets/Game/Scripts/hex-lines-game/Game.js"},{"deps":{},"path":"preview-scripts/assets/framework/Platform.js"},{"deps":{},"path":"preview-scripts/assets/Game/Scripts/g - 001.js"},{"deps":{},"path":"preview-scripts/assets/Game/Scripts/hex-lines-game/Consts.js"},{"deps":{"../../../framework/plugin_boosts/ui/DCUI":53},"path":"preview-scripts/assets/Game/Scripts/ui/DCBackground.js"},{"deps":{},"path":"preview-scripts/assets/Game/Scripts/hex-lines-game/ds/IntMap.js"},{"deps":{},"path":"preview-scripts/assets/migration/use_v2.0.x_cc.Toggle_event.js"},{"deps":{"./ClickAudio":57},"path":"preview-scripts/assets/framework/plugin_boosts/misc/ClickAudioManager.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/horn.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/ui/game/LevelSelector.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/model/androidHelper.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/audio/audioMgr.js"},{"deps":{"../../framework/plugin_boosts/misc/DataCenter":42,"./hex-lines-game/Res":31,"../../framework/plugin_boosts/gamesys/Device":44,"../../framework/plugin_boosts/ui/ToastManager":65},"path":"preview-scripts/assets/Game/Scripts/Info.js"},{"deps":{"./Res":31,"./ds/IntMap":16,"./Game":11},"path":"preview-scripts/assets/Game/Scripts/hex-lines-game/GridManager.js"},{"deps":{"../../../framework/Platform":12,"../Info":23,"../../../framework/plugin_boosts/ui/View":69},"path":"preview-scripts/assets/Game/Scripts/ui/DailyGetDialog.js"},{"deps":{"../../../framework/plugin_boosts/ui/game/LevelSelector":20,"../Info":23},"path":"preview-scripts/assets/Game/Scripts/ui/LevelDialog.js"},{"deps":{"../../../framework/plugin_boosts/ui/ViewManager":2,"../../../framework/plugin_boosts/ui/ToastManager":65,"../../../framework/Platform":12,"../../../framework/plugin_boosts/ui/UIFunctions":63,"../../../framework/plugin_boosts/ui/View":69,"../hex-lines-game/Res":31,"../Info":23,"../../../framework/plugin_boosts/gamesys/Device":44},"path":"preview-scripts/assets/Game/Scripts/ui/LuckyDialog.js"},{"deps":{"../../../framework/Platform":12,"../Info":23,"../../../framework/plugin_boosts/ui/View":69},"path":"preview-scripts/assets/Game/Scripts/ui/LevelupDialog.js"},{"deps":{"../../../framework/plugin_boosts/ui/View":69,"../../../framework/Platform":12,"../../../framework/plugin_boosts/ui/ViewManager":2,"../Info":23},"path":"preview-scripts/assets/Game/Scripts/ui/GetDialog.js"},{"deps":{"../../../framework/plugin_boosts/misc/Signal":48},"path":"preview-scripts/assets/Game/Scripts/ui/ShopItemTemplate.js"},{"deps":{},"path":"preview-scripts/assets/Game/Scripts/hex-lines-game/Res.js"},{"deps":{},"path":"preview-scripts/assets/Game/Scripts/hex-lines-game/Animal.js"},{"deps":{"./Res":31,"./Consts":14,"./Game":11},"path":"preview-scripts/assets/Game/Scripts/hex-lines-game/HexonTile.js"},{"deps":{"./ShopItemTemplate":30,"../../../framework/Platform":12,"../../../framework/plugin_boosts/misc/SpriteFrameCache":51,"../hex-lines-game/Res":31,"../../../framework/plugin_boosts/gamesys/Device":44,"../Main":38,"../../../framework/plugin_boosts/ui/ToastManager":65,"../Info":23},"path":"preview-scripts/assets/Game/Scripts/ui/ShopDialog.js"},{"deps":{"../../../framework/Platform":12,"../Info":23,"../../../framework/plugin_boosts/ui/ViewManager":2,"../hex-lines-game/Consts":14},"path":"preview-scripts/assets/Game/Scripts/ui/WinDialog.js"},{"deps":{"../../../framework/Platform":12,"../../../framework/plugin_boosts/ui/ToastManager":65,"../hex-lines-game/Res":31,"../../../framework/plugin_boosts/ui/ViewManager":2,"../Info":23,"../../../framework/plugin_boosts/ui/View":69,"../../../framework/plugin_boosts/gamesys/Device":44},"path":"preview-scripts/assets/Game/Scripts/ui/HbDialog.js"},{"deps":{"../../../framework/Platform":12},"path":"preview-scripts/assets/Game/Scripts/ui/PauseDialog.js"},{"deps":{"../../framework/plugin_boosts/ui/ViewManager":2,"../../framework/Platform":12,"./hex-lines-game/Res":31,"../../framework/plugin_boosts/gamesys/Device":44,"./Info":23,"../../framework/plugin_boosts/ui/ToastManager":65},"path":"preview-scripts/assets/Game/Scripts/Main.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/gamesys/PoolManager.js"},{"deps":{"../../../framework/plugin_boosts/ui/DCUI":53,"../Info":23},"path":"preview-scripts/assets/Game/Scripts/ui/DCParticleSystem.js"},{"deps":{"./PsFx":46,"./PoolManager":39},"path":"preview-scripts/assets/framework/plugin_boosts/gamesys/PsSpawner.js"},{"deps":{"../utils/EventManager":70},"path":"preview-scripts/assets/framework/plugin_boosts/misc/DataCenter.js"},{"deps":{"./Device":44,"./PsFx":46},"path":"preview-scripts/assets/framework/plugin_boosts/gamesys/PsFxPlayer.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/gamesys/Device.js"},{"deps":{"./JoyStick":49},"path":"preview-scripts/assets/framework/plugin_boosts/misc/InputSystem.js"},{"deps":{"./Device":44},"path":"preview-scripts/assets/framework/plugin_boosts/gamesys/PsFx.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/gamesys/LocalTimeSystem.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/misc/Signal.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/misc/JoyStick.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/misc/BoostsAction.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/misc/SpriteFrameCache.js"},{"deps":{"./DCUI":53},"path":"preview-scripts/assets/framework/plugin_boosts/ui/DCToggle.js"},{"deps":{"../misc/DataCenter":42},"path":"preview-scripts/assets/framework/plugin_boosts/ui/DCUI.js"},{"deps":{"./PandoraPoint":56,"./DCUI":53},"path":"preview-scripts/assets/framework/plugin_boosts/ui/DCPandoraPoint.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/misc/Net.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/ui/PandoraPoint.js"},{"deps":{"../gamesys/Device":44},"path":"preview-scripts/assets/framework/plugin_boosts/misc/ClickAudio.js"},{"deps":{"./ViewManager":2},"path":"preview-scripts/assets/framework/plugin_boosts/ui/MessageBoxManager.js"},{"deps":{"./DCUI":53},"path":"preview-scripts/assets/framework/plugin_boosts/ui/DCLabel.js"},{"deps":{"./View":69,"./MessageBoxManager":58},"path":"preview-scripts/assets/framework/plugin_boosts/ui/MessageBoxComponent.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/ui/LoadingManager.js"},{"deps":{"./UIFunctions":63},"path":"preview-scripts/assets/framework/plugin_boosts/ui/ToastComponent.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/ui/UIFunctions.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/ui/UIComponent.js"},{"deps":{"./ToastComponent":62},"path":"preview-scripts/assets/framework/plugin_boosts/ui/ToastManager.js"},{"deps":{"../misc/SpriteFrameCache":51},"path":"preview-scripts/assets/framework/plugin_boosts/utils/Common.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/gamesys/FSM.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/misc/FrameSwitch.js"},{"deps":{"./UIComponent":64,"./ViewManager":2,"./UIFunctions":63},"path":"preview-scripts/assets/framework/plugin_boosts/ui/View.js"},{"deps":{},"path":"preview-scripts/assets/framework/plugin_boosts/utils/EventManager.js"},{"deps":{"./DCUI":53,"../misc/SpriteFrameCache":51},"path":"preview-scripts/assets/framework/plugin_boosts/ui/DCSprite.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/loadTip.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/platformFun.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/result.js"},{"deps":{"room":81,"./model/consts":93},"path":"preview-scripts/assets/gameComon/scripts/roomGame.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/item.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/ad/nativeAd.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/screenrecord.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/revive.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/updateTime.js"},{"deps":{"emitter":90,"./model/consts":93},"path":"preview-scripts/assets/gameComon/scripts/room.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/dialogBox.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/ad/qqAppBox.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/ad/qqBlockAd.js"},{"deps":{"emitter":90,"consts":93,"httpUtils":91,"platformFun":73,"util":6,"androidHelper":21,"underscore":96,"async":89},"path":"preview-scripts/assets/gameComon/scripts/model/appGame.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/ad/wxnativeAd.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/ad/wxgridAd.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/ad/interstitialAd.js"},{"deps":{"C:/CocosDashboard_1.0.12/resources/.editors/Creator/2.4.4/resources/app.asar/node_modules/process/browser.js":104},"path":"preview-scripts/assets/gameComon/scripts/model/async.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/model/emitter.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/model/httpUtils.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/changeGame.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/model/consts.js"},{"deps":{"appGame":85,"videoBanner":10,"interstitialAd":88,"wxnativeAd":86,"wxgridAd":87,"qqAppBox":83,"qqBlockAd":84,"roomGame":75,"banner":5},"path":"preview-scripts/assets/gameComon/scripts/gameSceneManager.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/lucky.js"},{"deps":{},"path":"preview-scripts/assets/gameComon/scripts/model/underscore.js"},{"deps":{"./ConnectManager":100,"./Message":8,"./MessageType":99},"path":"preview-scripts/assets/framework/network/MessageBase.js"},{"deps":{},"path":"preview-scripts/assets/framework/network/MessageDispatch.js"},{"deps":{},"path":"preview-scripts/assets/framework/network/MessageType.js"},{"deps":{"./Socket":101},"path":"preview-scripts/assets/framework/network/ConnectManager.js"},{"deps":{"./MessageHandler":102,"./MessageType":99},"path":"preview-scripts/assets/framework/network/Socket.js"},{"deps":{"./Message":8,"./MessageDispatch":98,"./MessageType":99},"path":"preview-scripts/assets/framework/network/MessageHandler.js"},{"deps":{"../misc/Signal":48,"../utils/EventManager":70},"path":"preview-scripts/assets/framework/plugin_boosts/gamesys/LocalLifeSystem.js"},{"deps":{},"path":"preview-scripts/__node_modules/process/browser.js"}];
var entries = ["preview-scripts/__qc_index__.js"];
var bundleScript = 'preview-scripts/__qc_bundle__.js';

/**
 * Notice: This file can not use ES6 (for IE 11)
 */
var modules = {};
var name2path = {};

// Will generated by module.js plugin
// var scripts = ${scripts};
// var entries = ${entries};
// var bundleScript = ${bundleScript};

if (typeof global === 'undefined') {
    window.global = window;
}

var isJSB = typeof jsb !== 'undefined';

function getXMLHttpRequest () {
    return window.XMLHttpRequest ? new window.XMLHttpRequest() : new ActiveXObject('MSXML2.XMLHTTP');
}

function downloadText(url, callback) {
    if (isJSB) {
        var result = jsb.fileUtils.getStringFromFile(url);
        callback(null, result);
        return;
    }

    var xhr = getXMLHttpRequest(),
        errInfo = 'Load text file failed: ' + url;
    xhr.open('GET', url, true);
    if (xhr.overrideMimeType) xhr.overrideMimeType('text\/plain; charset=utf-8');
    xhr.onload = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200 || xhr.status === 0) {
                callback(null, xhr.responseText);
            }
            else {
                callback({status:xhr.status, errorMessage:errInfo + ', status: ' + xhr.status});
            }
        }
        else {
            callback({status:xhr.status, errorMessage:errInfo + '(wrong readyState)'});
        }
    };
    xhr.onerror = function(){
        callback({status:xhr.status, errorMessage:errInfo + '(error)'});
    };
    xhr.ontimeout = function(){
        callback({status:xhr.status, errorMessage:errInfo + '(time out)'});
    };
    xhr.send(null);
};

function loadScript (src, cb) {
    if (typeof require !== 'undefined') {
        require(src);
        return cb();
    }

    // var timer = 'load ' + src;
    // console.time(timer);

    var scriptElement = document.createElement('script');

    function done() {
        // console.timeEnd(timer);
        // deallocation immediate whatever
        scriptElement.remove();
    }

    scriptElement.onload = function () {
        done();
        cb();
    };
    scriptElement.onerror = function () {
        done();
        var error = 'Failed to load ' + src;
        console.error(error);
        cb(new Error(error));
    };
    scriptElement.setAttribute('type','text/javascript');
    scriptElement.setAttribute('charset', 'utf-8');
    scriptElement.setAttribute('src', src);

    document.head.appendChild(scriptElement);
}

function loadScripts (srcs, cb) {
    var n = srcs.length;

    srcs.forEach(function (src) {
        loadScript(src, function () {
            n--;
            if (n === 0) {
                cb();
            }
        });
    })
}

function formatPath (path) {
    let destPath = window.__quick_compile_project__.destPath;
    if (destPath) {
        let prefix = 'preview-scripts';
        if (destPath[destPath.length - 1] === '/') {
            prefix += '/';
        }
        path = path.replace(prefix, destPath);
    }
    return path;
}

window.__quick_compile_project__ = {
    destPath: '',

    registerModule: function (path, module) {
        path = formatPath(path);
        modules[path].module = module;
    },

    registerModuleFunc: function (path, func) {
        path = formatPath(path);
        modules[path].func = func;

        var sections = path.split('/');
        var name = sections[sections.length - 1];
        name = name.replace(/\.(?:js|ts|json)$/i, '');
        name2path[name] = path;
    },

    require: function (request, path) {
        var m, requestScript;

        path = formatPath(path);
        if (path) {
            m = modules[path];
            if (!m) {
                console.warn('Can not find module for path : ' + path);
                return null;
            }
        }

        if (m) {
            let depIndex = m.deps[request];
            // dependence script was excluded
            if (depIndex === -1) {
                return null;
            }
            else {
                requestScript = scripts[ m.deps[request] ];
            }
        }
        
        let requestPath = '';
        if (!requestScript) {
            // search from name2path when request is a dynamic module name
            if (/^[\w- .]*$/.test(request)) {
                requestPath = name2path[request];
            }

            if (!requestPath) {
                if (CC_JSB) {
                    return require(request);
                }
                else {
                    console.warn('Can not find deps [' + request + '] for path : ' + path);
                    return null;
                }
            }
        }
        else {
            requestPath = formatPath(requestScript.path);
        }

        let requestModule = modules[requestPath];
        if (!requestModule) {
            console.warn('Can not find request module for path : ' + requestPath);
            return null;
        }

        if (!requestModule.module && requestModule.func) {
            requestModule.func();
        }

        if (!requestModule.module) {
            console.warn('Can not find requestModule.module for path : ' + path);
            return null;
        }

        return requestModule.module.exports;
    },

    run: function () {
        entries.forEach(function (entry) {
            entry = formatPath(entry);
            var module = modules[entry];
            if (!module.module) {
                module.func();
            }
        });
    },

    load: function (cb) {
        var self = this;

        var srcs = scripts.map(function (script) {
            var path = formatPath(script.path);
            modules[path] = script;

            if (script.mtime) {
                path += ("?mtime=" + script.mtime);
            }
            return path;
        });

        console.time && console.time('load __quick_compile_project__');
        // jsb can not analysis sourcemap, so keep separate files.
        if (bundleScript && !isJSB) {
            downloadText(formatPath(bundleScript), function (err, bundleSource) {
                console.timeEnd && console.timeEnd('load __quick_compile_project__');
                if (err) {
                    console.error(err);
                    return;
                }

                let evalTime = 'eval __quick_compile_project__ : ' + srcs.length + ' files';
                console.time && console.time(evalTime);
                var sources = bundleSource.split('\n//------QC-SOURCE-SPLIT------\n');
                for (var i = 0; i < sources.length; i++) {
                    if (sources[i]) {
                        window.eval(sources[i]);
                        // not sure why new Function cannot set breakpoints precisely
                        // new Function(sources[i])()
                    }
                }
                self.run();
                console.timeEnd && console.timeEnd(evalTime);
                cb();
            })
        }
        else {
            loadScripts(srcs, function () {
                self.run();
                console.timeEnd && console.timeEnd('load __quick_compile_project__');
                cb();
            });
        }
    }
};

// Polyfill for IE 11
if (!('remove' in Element.prototype)) {
    Element.prototype.remove = function () {
        if (this.parentNode) {
            this.parentNode.removeChild(this);
        }
    };
}
})();
    
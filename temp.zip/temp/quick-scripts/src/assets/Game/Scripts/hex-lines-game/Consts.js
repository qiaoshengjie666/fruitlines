"use strict";
cc._RF.push(module, 'ccf28Nj1JdBbY/NtYiwJtcW', 'Consts');
// Game/Scripts/hex-lines-game/Consts.ts

Object.defineProperty(exports, "__esModule", { value: true });
var Consts = /** @class */ (function () {
    function Consts() {
    }
    Consts.CenterY = 0;
    Consts.CenterX = 0;
    Consts.ColSize = 84;
    Consts.RowSize = 61;
    Consts.StagePageCount = 3;
    Consts.FreeSkinId = 5;
    return Consts;
}());
exports.default = Consts;

cc._RF.pop();
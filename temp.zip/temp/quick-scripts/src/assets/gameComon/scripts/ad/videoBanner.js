"use strict";
cc._RF.push(module, '984cbg+bTFE9qHzstOIM3zd', 'videoBanner');
// gameComon/scripts/ad/videoBanner.js

"use strict";

var videoAdId = '';
var appId = '';
var boolsuccess = false;
var VideoBanner = cc.Class({
  properties: {},
  ctor: function ctor() {
    this.instance = null;
  },
  statics: {
    create: function create(data) {
      if (!this.instance) {
        this.instance = new VideoBanner();
        this.instance.initWithData(data);
        return this.instance;
      }
    }
  },
  initWithData: function initWithData(data) {
    this.isForce = false;
    this.callback = null;
    this.count = 1;

    if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
      //头条平台
      videoAdId = '1gr8f7hvpon3mb2llf';

      if (appGame.gameServerRoom.commonConfig && appGame.gameServerRoom.commonConfig.videoId && appGame.gameServerRoom.commonConfig.videoId.toutiao) {
        videoAdId = appGame.gameServerRoom.commonConfig.videoId.toutiao.adUnitId;
      }

      this.globalData = {
        videoAd: tt.createRewardedVideoAd({
          adUnitId: videoAdId
        })
      };
    } else if (cc.sys.platform == cc.sys.WECHAT_GAME && appGame.platform == 'WX') {
      //微信
      videoAdId = 'adunit-168ed0ed4d9f8fad';

      if (appGame.gameServerRoom.commonConfig && appGame.gameServerRoom.commonConfig.videoId && appGame.gameServerRoom.commonConfig.videoId.WX) {
        videoAdId = appGame.gameServerRoom.commonConfig.videoId.WX.adUnitId;
      }

      this.globalData = {
        videoAd: wx.createRewardedVideoAd({
          adUnitId: videoAdId
        })
      };
    } else if (cc.sys.platform == cc.sys.WECHAT_GAME && appGame.platform == 'QQ') {
      //qq
      videoAdId = '29ce1e526c81abd0e8ba8df8b62e0a9e';

      if (appGame.gameServerRoom.commonConfig && appGame.gameServerRoom.commonConfig.videoId && appGame.gameServerRoom.commonConfig.videoId.QQ) {
        videoAdId = appGame.gameServerRoom.commonConfig.videoId.QQ.adUnitId;
      }

      this.globalData = {
        videoAd: qq.createRewardedVideoAd({
          adUnitId: videoAdId
        })
      };
    } else if (cc.sys.platform == cc.sys.BAIDU_GAME) {
      //百度
      videoAdId = '7433930';

      if (appGame.gameServerRoom.commonConfig && appGame.gameServerRoom.commonConfig.videoId && appGame.gameServerRoom.commonConfig.videoId.baidu) {
        videoAdId = appGame.gameServerRoom.commonConfig.videoId.baidu.adUnitId;
      }

      if (appGame.gameServerRoom.commonConfig && appGame.gameServerRoom.commonConfig.videoId && appGame.gameServerRoom.commonConfig.videoId.baidu) {
        appId = appGame.gameServerRoom.commonConfig.videoId.baidu.appSid;
      }

      this.globalData = {
        videoAd: swan.createRewardedVideoAd({
          adUnitId: videoAdId,
          appSid: appId
        })
      };
    }

    httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
      title: '广告位激励视频',
      content: '创建成功+广告位+' + videoAdId
    }, function () {});

    if (cc.sys.platform != cc.sys.WECHAT_GAME) {
      if (this.globalData && this.globalData.videoAd) {
        this.globalData.videoAd.onClose(function (res) {
          if (res.isEnded) {
            console.log("看完视频关闭");
            httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
              title: '广告位激励视频',
              content: '点击关闭+广告位+' + videoAdId + "播放成功"
            }, function () {});
            this.callback && this.callback(1);
            appGame.audioMgr.getMusicStatus(function (onOff) {
              if (onOff) {
                appGame.audioMgr.setMusicOnOff(onOff);
              }
            }.bind(this));
          } else {
            httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
              title: '广告位激励视频',
              content: '点击关闭+广告位+' + videoAdId + "播放失败"
            }, function () {});
            console.log("未看完视频关闭==" + this.isForce);

            if (!this.isForce) {
              this.callback && this.callback(2);
              appGame.audioMgr.getMusicStatus(function (onOff) {
                if (onOff) {
                  appGame.audioMgr.setMusicOnOff(onOff);
                }
              }.bind(this));
            }
          }
        }.bind(this));
        this.globalData.videoAd.onError(function (listener) {
          console.log("播放视频广告出问题");
          httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
            title: '广告位激励视频',
            content: '展示失败+广告位+' + videoAdId + "原因+" + listener.errCode + listener.errMsg
          }, function () {});

          if (!this.isForce) {
            this.callback && this.callback(3);
            appGame.audioMgr.getMusicStatus(function (onOff) {
              if (onOff) {
                appGame.audioMgr.setMusicOnOff(onOff);
              }
            }.bind(this));
          }
        }.bind(this));
      }
    }
  },
  playVideoAd: function playVideoAd(sceneId, isForce, cb) {
    this.isForce = isForce;
    console.log("播放视频广告");
    this.count++;
    httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
      title: '广告位激励视频',
      content: '点击次数+' + this.count + '+广告位+' + videoAdId
    }, function () {});

    if (this.globalData && this.globalData.videoAd) {
      appGame.audioMgr.getMusicStatus(function (onOff) {
        if (onOff) {
          appGame.audioMgr.setMusicOnOff(onOff);
        }
      }.bind(this));
      var videoAd = this.globalData.videoAd;

      if (cc.sys.platform == cc.sys.WECHAT_GAME) {
        console.log("播放微信视频");

        if (_videoAd) {
          _videoAd.destroy();
        }

        var _videoAd = null;

        if (appGame.gameServerRoom.commonConfig && appGame.gameServerRoom.commonConfig.videoId && appGame.gameServerRoom.commonConfig.videoId.QQ) {
          videoAdId = appGame.gameServerRoom.commonConfig.videoId.QQ.adUnitId;
        }

        _videoAd = qq.createRewardedVideoAd({
          adUnitId: videoAdId
        });

        _videoAd.onError(function (res) {
          if (!this.isForce) {
            this.callback && this.callback(3);
            appGame.audioMgr.getMusicStatus(function (onOff) {
              if (onOff) {
                appGame.audioMgr.setMusicOnOff(onOff);
              }
            }.bind(this));
          }

          httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
            title: '广告位激励视频',
            content: '展示失败+广告位+' + videoAdId + "原因+" + res.errCode + res.errMsg
          }, function () {});
          console.log('videoAd onError', res);
        }.bind(this));

        _videoAd.onLoad(function (res) {
          console.log('videoAd onLoad', res);
        });

        _videoAd.onClose(function (res) {
          if (res.isEnded) {
            if (boolsuccess) {
              return;
            }

            boolsuccess = true;
            httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
              title: '广告位激励视频',
              content: '点击关闭+广告位+' + videoAdId + "播放成功"
            }, function () {});
            this.callback && this.callback(1);
            appGame.audioMgr.getMusicStatus(function (onOff) {
              if (onOff) {
                appGame.audioMgr.setMusicOnOff(onOff);
              }
            }.bind(this));
          } else {
            httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
              title: '广告位激励视频',
              content: '点击关闭+广告位+' + videoAdId + "播放失败"
            }, function () {});

            if (!this.isForce) {
              this.callback && this.callback(2);
              appGame.audioMgr.getMusicStatus(function (onOff) {
                if (onOff) {
                  appGame.audioMgr.setMusicOnOff(onOff);
                }
              }.bind(this));
            }
          }

          _videoAd.offClose();
        }.bind(this));

        _videoAd.load().then(function () {
          console.log('激励视频加载成功');

          _videoAd.show().then(function () {
            boolsuccess = false;
            httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
              title: '广告位激励视频',
              content: '展示成功+广告位+' + videoAdId + "场景" + sceneId
            }, function () {});
            console.log('激励视频 广告显示成功');
          })["catch"](function (err) {
            httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
              title: '广告位激励视频',
              content: '展示失败+广告位+' + videoAdId + "场景" + sceneId
            }, function () {});
            console.log('激励视频 广告显示失败');
          });
        })["catch"](function (err) {
          console.log('激励视频加载失败');
        });
      } else {
        videoAd.show().then(function () {
          httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
            title: '广告位激励视频',
            content: '展示成功+广告位+' + videoAdId + "场景" + sceneId
          }, function () {});
          console.log("广告显示成功");
        })["catch"](function (err) {
          httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
            title: '广告位激励视频',
            content: '展示失败+广告位+' + videoAdId + "场景" + sceneId
          }, function () {});
          console.log("广告组件出现问题", err); // 可以手动加载一次

          videoAd.load().then(function () {
            console.log("手动加载成功"); // 加载成功后需要再显示广告

            httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
              title: '广告位激励视频',
              content: '加载成功+广告位+' + videoAdId
            }, function () {});
            return videoAd.show();
          });
        });
        this.callback = cb;
      }
    } else {
      //没有激励视频的直接返回
      appGame.audioMgr.getMusicStatus(function (onOff) {
        if (onOff) {
          appGame.audioMgr.setMusicOnOff(onOff);
        }
      }.bind(this));
      cb(1);
    }
  }
});
module.exports = VideoBanner;

cc._RF.pop();
"use strict";
cc._RF.push(module, 'd8a0ccas05AxZHvKiQ9cgNJ', 'qqBlockAd');
// gameComon/scripts/ad/qqBlockAd.js

"use strict";

var videoId = '';
var adUnitId = "";
var BlockAd = cc.Class({
  "extends": cc.Component,
  properties: {},
  ctor: function ctor() {
    this.instance = null;
  },
  statics: {
    create: function create(data) {
      if (!this.instance) {
        this.instance = new BlockAd();
        this.instance.initWithData(data);
        return this.instance;
      }
    }
  },
  initWithData: function initWithData(data) {
    this.targetBannerAdWidth = 200;
  },
  playBlockad: function playBlockad(show) {
    if (cc.sys.platform == cc.sys.WECHAT_GAME && appGame.platform == 'QQ') {
      //QQ
      if (show) {
        if (this.globalData && this.globalData.blockAd) {
          this.globalData.blockAd.destroy();
        }

        var res = qq.getSystemInfoSync();
        this.width = res.windowWidth;
        this.height = res.windowHeight;
        var Version2 = util.compareVersion(res.SDKVersion, "1.15.0"); //if(Version2 > 0){

        videoId = "672c9551ab8b8b8284a73dde8cf1406a";

        if (appGame.gameServerRoom.gameConfigData && appGame.gameServerRoom.gameConfigData.blockId && appGame.gameServerRoom.gameConfigData.blockId.QQ) {
          videoId = appGame.gameServerRoom.gameConfigData.blockId.QQ.adUnitId;
        }

        this.globalData = {
          blockAd: qq.createBlockAd({
            adUnitId: videoId,
            size: 5,
            orientation: 'landscape',
            style: {
              //left: 16,
              //top: this.height - (this.targetBannerAdWidth / 16) * 9, // 根据系统约定尺寸计算出广告高度,
              // width: this.targetBannerAdWidth,
              left: 16,
              top: this.height - this.targetBannerAdWidth / 16 * 9 * 2
            }
          })
        };
        this.globalData.blockAd.onError(function (res) {
          console.log('globalData blockAd onError', res);
        });
        console.log('globalData blockAd onLoad', res);
        this.globalData.blockAd.show(function (res) {
          console.log('globalData blockAd show error', res);
        });
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
          title: '积木广告',
          content: '展示'
        }, function () {});
      } else {
        if (this.globalData && this.globalData.blockAd) {
          this.globalData.blockAd.destroy();
          httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
            title: '积木广告',
            content: '隐藏'
          }, function () {});
        }
      }
    }
  },
  refreshSize: function refreshSize() {
    var _this = this;

    if (this.globalData && this.globalData.bannerAd) {
      if (cc.sys.platform == cc.sys.WECHAT_GAME && appGame.platform == 'QQ') {
        //QQ
        this.globalData.blockAd.onResize(function (size) {
          console.log("积木广告 shezhi大小" + _this.height + "   " + _this.width);
          _this.globalData.blockAd.style.top = _this.height - size.height;
          _this.globalData.blockAd.style.left = (_this.width - size.width) / 2;
        });
      }
    }
  }
});
module.exports = BlockAd;

cc._RF.pop();
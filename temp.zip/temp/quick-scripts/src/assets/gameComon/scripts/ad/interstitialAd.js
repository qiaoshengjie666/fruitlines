"use strict";
cc._RF.push(module, '65bb3OPXhxMDIngU6dETA4S', 'interstitialAd');
// gameComon/scripts/ad/interstitialAd.js

"use strict";

var adUnitId = "";
var InterstitialAd = cc.Class({
  properties: {},
  ctor: function ctor() {
    this.instance = null;
  },
  statics: {
    create: function create(data) {
      if (!this.instance) {
        this.instance = new InterstitialAd();
        this.instance.initWithData(data);
        return this.instance;
      }
    }
  },
  initWithData: function initWithData(data) {
    this.adId = '';

    if (cc.sys.platform == cc.sys.WECHAT_GAME && appGame.platform == 'QQ') {
      //qq
      this.adId = 'd0cde0940f440d92729726f90c72d71a';

      if (appGame.gameServerRoom.commonConfig && appGame.gameServerRoom.commonConfig.interstitialId && appGame.gameServerRoom.commonConfig.interstitialId.QQ) {
        this.adId = appGame.gameServerRoom.commonConfig.interstitialId.QQ.adUnitId;
      }

      this.globalData = {
        interstitialAd: qq.createInterstitialAd({
          adUnitId: this.adId
        })
      };
      console.log("插屏广告==" + this.adId);
    } else if (cc.sys.platform == cc.sys.WECHAT_GAME && appGame.platform == 'WX') {
      //微信
      this.adId = 'c5b484afd6953432';

      if (appGame.gameServerRoom.commonConfig && appGame.gameServerRoom.commonConfig.interstitialId && appGame.gameServerRoom.commonConfig.interstitialId.WX) {
        this.adId = appGame.gameServerRoom.commonConfig.interstitialId.WX.adUnitId;
      }
    } else if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
      //字节
      this.adId = '15c24vd9ppqti8jgb3';

      if (appGame.gameServerRoom.commonConfig && appGame.gameServerRoom.commonConfig.interstitialId && appGame.gameServerRoom.commonConfig.interstitialId.toutiao) {
        this.adId = appGame.gameServerRoom.commonConfig.interstitialId.toutiao.adUnitId;
      }
    }
  },
  playAd: function playAd(sceneId) {
    var _this = this;

    console.log("播放插屏广告==");

    if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
      //头条平台
      if (this.globalData && this.globalData.interstitialAd) {
        this.globalData.interstitialAd.destroy();
        this.globalData.interstitialAd = null;
      }

      this.globalData = {
        interstitialAd: tt.createInterstitialAd({
          adUnitId: this.adId
        })
      };
      httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
        title: '广告位插屏',
        content: '创建成功+广告位+' + this.adId
      }, function () {});
      this.globalData.interstitialAd.load().then(function () {
        console.log("插屏显示成功");
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
          title: '插屏广告',
          content: '显示成功'
        }, function () {});
        return _this.globalData.interstitialAd.show();
      })["catch"](function (err) {
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
          title: '插屏广告',
          content: '显示失败'
        }, function () {});
        console.log("插屏组件出现问题", err);
      });
      this.globalData.interstitialAd.onError(function (listener) {
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
          title: '广告位插屏',
          content: '展示失败+广告位+' + _this.adId + "原因+" + listener.errMsg
        }, function () {});
      });
    } else if (cc.sys.platform == cc.sys.WECHAT_GAME) {
      console.log("播放插屏广告==");

      if (this.globalData && this.globalData.interstitialAd) {
        this.globalData.interstitialAd.destroy();
        this.globalData.interstitialAd = null;
      }

      if (appGame.gameServerRoom.commonConfig && appGame.gameServerRoom.commonConfig.interstitialId && appGame.gameServerRoom.commonConfig.interstitialId.QQ) {
        this.adId = appGame.gameServerRoom.commonConfig.interstitialId.QQ.adUnitId;
      }

      this.globalData = {
        interstitialAd: qq.createInterstitialAd({
          adUnitId: this.adId
        })
      };
      httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
        title: '广告位插屏',
        content: '创建成功+广告位+' + this.adId
      }, function () {}); // this.globalData.interstitialAd.show().catch((err) => {
      //     console.error('show',err)
      //   });

      this.globalData.interstitialAd.load().then(function () {
        console.log("插屏显示成功");
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
          title: '插屏广告',
          content: '场景:' + sceneId,
          desc: '显示成功'
        }, function () {});
        return _this.globalData.interstitialAd.show();
      })["catch"](function (err) {
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
          title: '插屏广告',
          content: '场景:' + sceneId,
          desc: '显示失败'
        }, function () {});
        console.log("插屏组件出现问题", err);
      });
      this.globalData.interstitialAd.onError(function (listener) {
        console.log("当前平台22 ==" + cc.sys.platform);
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
          title: '广告位插屏',
          content: '展示失败+广告位+' + interId + "原因+" + listener.errMsg
        }, function () {});
      });
    } else {
      console.log("插屏广告11id==" + this.adId);

      if (this.globalData && this.globalData.interstitialAd) {
        console.log("插屏广告22id==" + this.adId);
        var interstitialAd = this.globalData.interstitialAd;
        interstitialAd.load().then(function () {
          console.log("插屏显示成功");
          httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
            title: '广告位插屏',
            content: '加载成功+广告位+' + _this.adId
          }, function () {});
          httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
            title: '广告位插屏',
            content: '展示成功+广告位+' + _this.adId
          }, function () {});
          return interstitialAd.show();
        })["catch"](function (err) {
          httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
            title: '广告位插屏',
            content: '加载失败+广告位+' + _this.adId
          }, function () {});
          console.log("插屏组件出现问题", err);
        });
      }
    }
  }
});
module.exports = InterstitialAd;

cc._RF.pop();
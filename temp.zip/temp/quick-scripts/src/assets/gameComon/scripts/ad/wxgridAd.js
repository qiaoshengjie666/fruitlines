"use strict";
cc._RF.push(module, '27d3buB6l5GlarYvR/+7For', 'wxgridAd');
// gameComon/scripts/ad/wxgridAd.js

"use strict";

var targetBannerAdWidth = 200;
var width = 100;
var height = 100;
var adId = '2b0c0dgf20nf3qe2jj';
var GridAd = cc.Class({
  properties: {},
  ctor: function ctor() {
    this.instance = null;
  },
  statics: {
    create: function create(data) {
      if (!this.instance) {
        this.instance = new GridAd();
        this.instance.initWithData(data);
        return this.instance;
      }
    }
  },
  initWithData: function initWithData(data) {
    if (cc.sys.platform == cc.sys.WECHAT_GAME && appGame.platform == 'WX') {
      var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
          windowWidth = _wx$getSystemInfoSync.windowWidth,
          windowHeight = _wx$getSystemInfoSync.windowHeight;

      this.targetBannerAdWidth = 200;
      this.width = windowWidth;
      this.height = windowHeight;
      this.adId = 'adunit-144bcfc4f8f3cefe';
      console.log("banner 第一次创建");
      this.globalData = {
        gridAd: wx.createGridAd({
          adUnitId: this.adId,
          adTheme: 'white',
          gridCount: 5,
          style: {
            left: 0,
            top: 0,
            width: 330,
            opacity: 0.8
          }
        })
      };
      this.globalData.gridAd.onError(function (res) {
        console.log('盒子广告onError', res);
      });
    }
  },
  playGridAd: function playGridAd(isShow) {
    if (isShow) {
      if (this.globalData && this.globalData.gridAd) {
        console.log("播放盒子广告");
        this.globalData.gridAd.show().then(function () {
          console.log("盒子广告展示成功");
        });
      }
    } else {
      this.globalData.gridAd.hide();
    }
  }
});
module.exports = GridAd;

cc._RF.pop();
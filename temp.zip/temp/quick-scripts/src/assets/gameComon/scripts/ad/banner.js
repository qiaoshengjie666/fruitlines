"use strict";
cc._RF.push(module, '4d62c7SXMdKHaht/20V3tyM', 'banner');
// gameComon/scripts/ad/banner.js

"use strict";

var AppGame = require("../model/appGame");

var bannerAppSid = "";
var bannerAdUnitId = "";
var Banner = cc.Class({
  properties: {},
  ctor: function ctor() {
    this.instance = null;
  },
  statics: {
    create: function create(data) {
      if (!this.instance) {
        this.instance = new Banner();
        this.instance.initWithData(data);
        return this.instance;
      }
    }
  },
  initWithData: function initWithData(data) {
    this.targetBannerAdWidth = 200;

    if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
      //头条平台
      var _tt$getSystemInfoSync = tt.getSystemInfoSync(),
          windowWidth = _tt$getSystemInfoSync.windowWidth,
          windowHeight = _tt$getSystemInfoSync.windowHeight;

      this.width = windowWidth;
      this.height = windowHeight;
      this.adId = '3o8m16pp3e54cqcd5t';

      if (appGame.gameServerRoom.commonConfig && appGame.gameServerRoom.commonConfig.bannerId && appGame.gameServerRoom.commonConfig.bannerId.toutiao) {
        this.adId = appGame.gameServerRoom.commonConfig.bannerId.toutiao.adUnitId;
      }

      console.log("banner 第一次创建");
      this.globalData = {
        bannerAd: tt.createBannerAd({
          adUnitId: this.adId,
          //adIntervals:30,
          style: {
            width: this.targetBannerAdWidth,
            top: this.height - this.targetBannerAdWidth / 16 * 9,
            // 根据系统约定尺寸计算出广告高度
            left: (this.width - this.targetBannerAdWidth) / 2
          }
        })
      };
      this.refreshSize();
    } else if (cc.sys.platform == cc.sys.WECHAT_GAME && appGame.platform == 'QQ') {
      var _qq$getSystemInfoSync = qq.getSystemInfoSync(),
          _windowWidth = _qq$getSystemInfoSync.windowWidth,
          _windowHeight = _qq$getSystemInfoSync.windowHeight;

      this.targetBannerAdWidth = 200;
      this.width = _windowWidth;
      this.height = _windowHeight;
      this.adId = '4ef215ca5af9c3b454e9d22a676f7992';

      if (appGame.gameServerRoom.commonConfig && appGame.gameServerRoom.commonConfig.bannerId && appGame.gameServerRoom.commonConfig.bannerId.QQ) {
        this.adId = appGame.gameServerRoom.commonConfig.bannerId.QQ.adUnitId;
      }

      console.log("banner 第一次创建");
      this.globalData = {
        bannerAd: qq.createBannerAd({
          adUnitId: this.adId,
          style: {
            width: this.targetBannerAdWidth,
            top: this.height - this.targetBannerAdWidth / 16 * 9,
            // 根据系统约定尺寸计算出广告高度
            left: (this.width - this.targetBannerAdWidth) / 2
          }
        })
      };
      this.refreshSize();
    } else if (cc.sys.platform == cc.sys.BAIDU_GAME) {
      var _swan$getSystemInfoSy = swan.getSystemInfoSync(),
          _windowWidth2 = _swan$getSystemInfoSy.windowWidth,
          _windowHeight2 = _swan$getSystemInfoSy.windowHeight;

      this.targetBannerAdWidth = 200;
      this.width = _windowWidth2;
      this.height = _windowHeight2;
      bannerAdUnitId = '4ef215ca5af9c3b454e9d22a676f7992';
      bannerAppSid = "";

      if (appGame.gameServerRoom.gameConfigData && appGame.gameServerRoom.gameConfigData.bannerId && appGame.gameServerRoom.gameConfigData.bannerId.baidu) {
        bannerAdUnitId = appGame.gameServerRoom.gameConfigData.bannerId.baidu.adUnitId;
      }

      if (appGame.gameServerRoom.gameConfigData && appGame.gameServerRoom.gameConfigData.videoId && appGame.gameServerRoom.gameConfigData.videoId.baidu) {
        bannerAppSid = appGame.gameServerRoom.gameConfigData.bannerId.baidu.appSid;
      }

      var example = {
        adUnitId: bannerAdUnitId,
        appSid: bannerAppSid,
        style: {
          top: this.height - this.targetBannerAdWidth / 16 * 9,
          left: (this.width - this.targetBannerAdWidth) / 2,
          width: this.targetBannerAdWidth
        }
      };
      this.globalData = {
        bannerAd: swan.createBannerAd(example)
      };
    }
  },
  scheduleCallBack: function scheduleCallBack() {
    console.log("n秒后刷新");
    this.playBanner(3);
    this.playBanner(2);
  },

  /*
  *sceneId 1 普通的展示   2 N秒刷新展示   3 隐藏
  */
  playBanner: function playBanner(sceneId, refreshTime) {
    if (refreshTime === void 0) {
      refreshTime = 30;
    }

    cc.director.getScheduler().enableForTarget(this);

    if (sceneId != 3) {
      if (sceneId == 2) {
        cc.director.getScheduler().schedule(this.scheduleCallBack, this, refreshTime);
      } else {
        cc.director.getScheduler().unschedule(this.scheduleCallBack, this);
      }

      if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
        //头条平台
        if (this.globalData && this.globalData.bannerAd) {
          console.log("banner 隐藏");
        } else {
          console.log("banner 创建");
          this.globalData = {
            bannerAd: tt.createBannerAd({
              adUnitId: this.adId,
              //adIntervals:30,
              style: {
                width: this.targetBannerAdWidth,
                top: this.height - this.targetBannerAdWidth / 16 * 9,
                // 根据系统约定尺寸计算出广告高度
                left: (this.width - this.targetBannerAdWidth) / 2
              }
            })
          };
          this.refreshSize();
        }
      } else if (cc.sys.platform == cc.sys.BAIDU_GAME) {
        //百度
        if (this.globalData && this.globalData.bannerAd) {
          this.globalData.bannerAd.destroy();
          this.globalData.bannerAd = null;
        }

        var _swan$getSystemInfoSy2 = swan.getSystemInfoSync(),
            windowWidth = _swan$getSystemInfoSy2.windowWidth,
            windowHeight = _swan$getSystemInfoSy2.windowHeight;

        this.width = windowWidth;
        this.height = windowHeight;

        if (appGame.gameServerRoom.commonConfig && appGame.gameServerRoom.commonConfig.bannerId && appGame.gameServerRoom.commonConfig.bannerId.baidu) {
          this.adId = appGame.gameServerRoom.commonConfig.bannerId.baidu.adUnitId;
        }

        if (appGame.gameServerRoom.commonConfig && appGame.gameServerRoom.commonConfig.bannerId && appGame.gameServerRoom.commonConfig.bannerId.baidu) {
          this.appId = appGame.gameServerRoom.commonConfig.bannerId.baidu.appSid;
        }

        this.globalData = {
          bannerAd: swan.createBannerAd({
            adUnitId: this.adId,
            appSid: this.appId,
            style: {
              width: this.width,
              top: this.height - this.targetBannerAdWidth / 16 * 9,
              // 根据系统约定尺寸计算出广告高度
              left: (this.width - this.targetBannerAdWidth) / 2
            }
          })
        };
        this.refreshSize();
      } else if (cc.sys.platform == cc.sys.WECHAT_GAME) {
        //QQ
        if (this.globalData && this.globalData.bannerAd) {
          console.log("banner 隐藏");
          this.globalData.bannerAd.destroy();
        }

        bannerAdUnitId = '7466662';

        if (appGame.gameServerRoom.gameConfigData && appGame.gameServerRoom.gameConfigData.bannerId && appGame.gameServerRoom.gameConfigData.bannerId.QQ) {
          bannerAdUnitId = appGame.gameServerRoom.gameConfigData.bannerId.QQ.adUnitId;
        }

        var example = {
          adUnitId: bannerAdUnitId,
          style: {
            top: this.height - this.targetBannerAdWidth / 16 * 9,
            left: (this.width - this.targetBannerAdWidth) / 2,
            width: this.targetBannerAdWidth
          }
        };
        this.globalData = {
          bannerAd: qq.createBannerAd(example)
        };

        if (this.globalData) {
          console.log("banner创建成功");
        } else {
          console.log("banner创建失败");
        }
      }

      this.timebanner = setTimeout(function () {
        this.showBannerAd();
      }.bind(this), 500);
    } else {
      cc.director.getScheduler().unschedule(this.scheduleCallBack, this);

      if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
        //头条平台
        if (this.globalData && this.globalData.bannerAd) {
          this.globalData.bannerAd.hide();
          this.globalData.bannerAd.destroy();
          this.globalData.bannerAd = null;
          console.log("字节平台banner 销毁");
          this.globalData = {
            bannerAd: tt.createBannerAd({
              adUnitId: this.adId,
              //adIntervals:30,
              style: {
                width: this.targetBannerAdWidth,
                top: this.height - this.targetBannerAdWidth / 16 * 9,
                // 根据系统约定尺寸计算出广告高度
                left: (this.width - this.targetBannerAdWidth) / 2
              }
            })
          };
          this.refreshSize();
        }
      } else if (cc.sys.platform == cc.sys.WECHAT_GAME) {
        //微信平台
        if (this.globalData && this.globalData.bannerAd) {
          this.globalData.bannerAd.hide();
          this.globalData.bannerAd.destroy();
          this.globalData.bannerAd = null;
          console.log("banner 销毁");
          this.globalData = {
            bannerAd: wx.createBannerAd({
              adUnitId: this.adId,
              style: {
                width: this.targetBannerAdWidth,
                top: this.height - this.targetBannerAdWidth / 16 * 9,
                // 根据系统约定尺寸计算出广告高度
                left: (this.width - this.targetBannerAdWidth) / 2
              }
            })
          };
          this.refreshSize();
        }
      } else if (cc.sys.platform == cc.sys.BAIDU_GAME) {
        //百度
        if (this.globalData && this.globalData.bannerAd) {
          this.globalData.bannerAd.hide();
          this.globalData.bannerAd.destroy();
          this.globalData.bannerAd = null;
          console.log("banner 销毁");
          var _example = {
            adUnitId: '7466662',
            appSid: 'c736be0f',
            style: {
              top: this.height - this.targetBannerAdWidth / 16 * 9,
              left: (this.width - this.targetBannerAdWidth) / 2,
              width: this.targetBannerAdWidth
            }
          };
          this.globalData = {
            bannerAd: swan.createBannerAd(_example)
          };
        }
      }
    }
  },
  showBannerAd: function showBannerAd() {
    var _this = this;

    clearTimeout(this.timebanner);

    if (this.globalData && this.globalData.bannerAd) {
      console.log("播放banner广告");

      if (cc.sys.platform == cc.sys.WECHAT_GAME) {
        this.globalData.bannerAd.show();
      } else {
        this.globalData.bannerAd.show().then(function () {
          console.log("展示成功");
          httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
            title: '广告位banner',
            content: '展示成功+广告位+' + _this.adId
          }, function () {});
        })["catch"](function (err) {
          console.log("展示失败");
          httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
            title: '广告位banner',
            content: '展示失败+广告位+' + _this.adId
          }, function () {});
        });
      }
    }
  },
  refreshSize: function refreshSize() {
    var _this2 = this;

    // 尺寸调整时会触发回调，通过回调拿到的广告真实宽高再进行定位适配处理
    // 注意：如果在回调里再次调整尺寸，要确保不要触发死循环！！！
    if (this.globalData && this.globalData.bannerAd) {
      if (cc.sys.platform == cc.sys.BYTEDANCE_GAME || cc.sys.platform == cc.sys.WECHAT_GAME || cc.sys.platform == cc.sys.BAIDU_GAME) {
        //头条平台
        this.globalData.bannerAd.onResize(function (size) {
          console.log("banner shezhi大小" + _this2.height + "   " + _this2.width);
          _this2.globalData.bannerAd.style.top = _this2.height - size.height;
          _this2.globalData.bannerAd.style.left = (_this2.width - size.width) / 2; //this.globalData.bannerAd.offResize();
        });
      }

      this.globalData.bannerAd.onError(function (listener) {
        console.log("banner 出错");
        httpUtils.httpPost(consts.HTTP_RECORD_SERVER, {
          title: '广告位banner',
          content: '展示失败+广告位+' + _this2.adId + "原因+" + listener.errMsg
        }, function () {}); // appGame.emitter.emit(consts.LOCAL_EVENT_POPUP_LOADTIP, {
        //     content: listener.errCode+"==="+listener.errMsg
        //  });
        //this.globalData.bannerAd.offError();
      });
    }
  }
});
module.exports = Banner;

cc._RF.pop();
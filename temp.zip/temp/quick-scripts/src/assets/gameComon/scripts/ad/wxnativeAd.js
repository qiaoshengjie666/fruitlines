"use strict";
cc._RF.push(module, '9a169f/Cs9NFp08r0mXOa8e', 'wxnativeAd');
// gameComon/scripts/ad/wxnativeAd.js

"use strict";

var WXNativeAd = cc.Class({
  properties: {},
  ctor: function ctor() {
    this.instance = null;
  },
  statics: {
    create: function create(data) {
      if (!this.instance) {
        this.instance = new WXNativeAd();
        this.instance.initWithData(data);
        return this.instance;
      }
    }
  },
  initWithData: function initWithData(data) {
    if (cc.sys.platform == cc.sys.OPPO_GAME) {
      //oppo
      this.globalData = {
        nativeAd: qg.createNativeAd({
          adUnitId: '236300'
        })
      };
    } else if (cc.sys.platform == cc.sys.WECHAT_GAME && appGame.platform == 'WX') {
      //微信平台 
      var _wx$getSystemInfoSync = wx.getSystemInfoSync(),
          windowWidth = _wx$getSystemInfoSync.windowWidth,
          windowHeight = _wx$getSystemInfoSync.windowHeight;

      this.targetBannerAdWidth = 200;
      this.width = windowWidth;
      this.height = windowHeight;
      console.log("原生广告111111111111");
      this.globalData = {
        nativeAd: wx.createCustomAd({
          adUnitId: 'adunit-48fb335e928d3b4d',
          style: {
            left: 20,
            top: this.height - this.targetBannerAdWidth / 16 * 9
          }
        })
      };
    }

    if (this.globalData && this.globalData.nativeAd) {
      // 设置原生广告加载成功回调
      // 设置原生广告出错回调
      this.globalData.nativeAd.onError(function (err) {
        console.log("\u8BBE\u7F6E\u539F\u751F\u5E7F\u544A\u51FA\u9519\uFF1A" + JSON.stringify(err));
      });
    }
  },
  playAd: function playAd(isShow) {
    if (cc.sys.platform == cc.sys.WECHAT_GAME && appGame.platform == 'WX') {
      if (isShow) {
        var nativeAd = this.globalData.nativeAd;
        nativeAd.show();
      } else {
        console.log("播放原生广告==");
        this.globalData.nativeAd.hide();
      }
    } else {
      if (this.globalData && this.globalData.nativeAd) {
        var _nativeAd = this.globalData.nativeAd;

        _nativeAd.load().then(function () {
          console.log("原生广告显示成功");
        })["catch"](function (err) {
          console.log("原生广告出现问题", err);
        });

        _nativeAd.onLoad(function (res) {
          console.log("\u52A0\u8F7D\u539F\u751F\u5E7F\u544A\u6210\u529F", "\uFF1A" + JSON.stringify(res));
          res.adList && res.adList.length > 0 && (appGame.nativeAdData = res.adList[0]);
          appGame.gameServerRoom.emit(consts.LOCAL_GAME_RESULT_NATIVE_AD, {});
        });
      }
    }
  }
});
module.exports = WXNativeAd;

cc._RF.pop();
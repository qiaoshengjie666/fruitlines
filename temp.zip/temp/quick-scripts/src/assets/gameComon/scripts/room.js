"use strict";
cc._RF.push(module, '690ef7tcntLt4eCVVAMIQ0O', 'room');
// gameComon/scripts/room.js

"use strict";

/*中台配置文件获取*/
var Emitter = require('emitter');

var consts = require('./model/consts');

var Room = cc.Class({
  "extends": Emitter,
  initWithData: function initWithData(data) {
    this.commonConfig = {};
    this.configSuccess1 = false;
    this.isHadWord = false;
    var url = consts.HTTP_GET_PAAS_DATA_SERVER + "?gameId=" + consts.GAME_ID + "&plat=" + appGame.platform + "&version=" + appGame.packageVersion + "&brand=" + '' + "&from=MiddleDesk";
    console.log("room url===" + url); //url = 'https://cs.snmi.cn/game/GetGameValue?gameId=1&plat=toutiao&version=1.0.4&brand=&from=MiddleDesk'

    httpUtils.httpSendRequest(url, function (res) {
      console.log("room ==" + JSON.stringify(res));

      if (res && res.Code == 200) {
        var detailparse = JSON.parse(res.Detail);

        if (detailparse) {
          if (detailparse.word) {
            this.isHadWord = true;
            util.spreadWordFun();
          }

          this.commonConfig = detailparse;
          this.configSuccess1 = true;
        }

        appGame.emitter.emit(consts.HTTP_EVENT_MIDDLE_DESK_CONFIG, {});

        if (this.configSuccess2 && this.configSuccess1) {
          appGame.gameServerRoom.emit(consts.CLIENT_GAME_START, {});
        }
      } else {
        util.loadJSONData("comJson", 'comConfig', function (data) {
          if (data) {
            this.commonConfig = data;
            this.configSuccess1 = true;

            if (data.word) {
              this.isHadWord = true;
              util.spreadWordFun();
            }
          }

          appGame.emitter.emit(consts.HTTP_EVENT_MIDDLE_DESK_CONFIG, {});

          if (this.configSuccess2 && this.configSuccess1) {
            appGame.gameServerRoom.emit(consts.CLIENT_GAME_START, {});
          }
        }.bind(this));
      }
    }.bind(this)); // util.loadJSONData("comJson",'comConfig',function(data){
    //     if(data){
    //         this.commonConfig = data;
    //         this.configSuccess1 = true;
    //     }
    //     appGame.emitter.emit(consts.HTTP_EVENT_MIDDLE_DESK_CONFIG,{});
    //     if(this.configSuccess2 && this.configSuccess1){
    //         appGame.gameServerRoom.emit(consts.CLIENT_GAME_START,{});
    //     }
    // }.bind(this));
  }
});
module.exports = Room;

cc._RF.pop();
"use strict";
cc._RF.push(module, '4bca2MgtetMQYn5yd8otlgf', 'screenrecord');
// gameComon/scripts/screenrecord.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var recorder;
var videoPathGame;
cc.Class({
  "extends": cc.Component,
  properties: {
    screenBtn: cc.Node,
    recordBtn: cc.Node
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.screenBtn.on(cc.Node.EventType.TOUCH_END, this.screenBtnCallBack, this);
    this.recordBtn.on(cc.Node.EventType.TOUCH_END, this.recordBtnCallBack, this);
    appGame.gameServerRoom.on(consts.CLIENT_GAME_PLAY_VIDEO, this.onPlayVideo, this);
    appGame.gameServerRoom.on(consts.CLIENT_GAME_RESULT_VIDEO_SHOW, this.onGameResultShowVideo, this);
    this.screenBtn.active = false;
    this.initRefreshUI();
  },
  onDestroy: function onDestroy() {
    appGame.gameServerRoom.off(consts.CLIENT_GAME_PLAY_VIDEO, this.onPlayVideo, this);
    appGame.gameServerRoom.off(consts.CLIENT_GAME_RESULT_VIDEO_SHOW, this.onGameResultShowVideo, this);
  },
  initRefreshUI: function initRefreshUI() {
    this.isScreening = false;

    if (this.isScreening) {
      this.screenBtn.getChildByName('Background').getChildByName('Label').getComponent(cc.Label).string = "录屏中";
    } else {
      this.screenBtn.getChildByName('Background').getChildByName('Label').getComponent(cc.Label).string = "录屏";
    }
  },
  onPlayVideo: function onPlayVideo(data) {
    appGame.gameServerRoom.screenTime = new Date().getTime();
    this.screenBtn.active = false;
    this.isScreening = true; //this.initRefreshUI();

    console.log('平台====' + cc.sys.platform);

    if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
      //头条平台
      if (!recorder) recorder = tt.getGameRecorderManager();
      recorder.start({
        duration: 300
      });
      recorder.onStart(function (res) {
        console.log('开始录屏');
      });
      recorder.onStop(function (res) {
        console.log(res.videoPath);
        appGame.gameServerRoom.videoPath = res.videoPath;
        console.log('录屏结束');
      }, this);
    }
  },
  onGameResultShowVideo: function onGameResultShowVideo(data) {
    appGame.gameServerRoom.screenTime = new Date().getTime() - appGame.gameServerRoom.screenTime;
    this.screenBtn.active = false;
    this.screenBtn.getChildByName('Background').getChildByName('Label').getComponent(cc.Label).string = "录屏";
    console.log('11自动停止录屏===');

    if (this.isScreening) {
      if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
        //头条平台
        if (!recorder) recorder = tt.getGameRecorderManager();
        recorder.stop();
        recorder.onStop(function (res) {
          appGame.gameServerRoom.videoPath = res.videoPath;
          appGame.gameServerRoom.emit(consts.CLIENT_GAME_VIDEO_SHOW, {});
          console.log('22自动停止录屏===' + res.videoPath);
        });
      }
    }
  },
  screenBtnCallBack: function screenBtnCallBack(event) {
    this.isScreening = !this.isScreening;

    if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
      //头条平台
      if (!recorder) recorder = tt.getGameRecorderManager();

      if (this.isScreening) {
        this.screenBtn.getChildByName('Background').getChildByName('Label').getComponent(cc.Label).string = "录屏中";
        recorder.start({
          duration: 100000
        });
        recorder.onStart(function (res) {
          console.log('开始录屏');
        });
        recorder.onStop(function (res) {
          console.log(res.videoPath);
          appGame.gameServerRoom.videoPath = res.videoPath;
          console.log('录屏结束');
        }, this);
      } else {
        this.screenBtn.getChildByName('Background').getChildByName('Label').getComponent(cc.Label).string = "录屏";
        recorder.stop();
        recorder.onStop(function (res) {
          appGame.gameServerRoom.videoPath = res.videoPath;
          console.log('手动停止录屏===' + res.videoPath);
        });
      }
    }
  },
  recordBtnCallBack: function recordBtnCallBack(event) {
    if (videoPathGame == null) {
      return;
    }

    if (cc.sys.platform == cc.sys.BYTEDANCE_GAME) {
      //头条平台
      tt.shareAppMessage({
        channel: 'video',
        title: '分享视频',
        imageUrl: '',
        query: '',
        extra: {
          videoPath: videoPathGame,
          // 可用录屏得到的视频地址
          videoTopics: ['测试话题']
        },
        success: function success() {
          console.log('分享视频成功');
        },
        fail: function fail(e) {
          console.log('分享视频失败');
        }
      });
    }
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();